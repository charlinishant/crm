import React from "react";
import MasterLayout from "../masterLayout/MasterLayout";
import Breadcrumb from "../components/Breadcrumb";
import DashBoardLayerEleven from "../components/DashBoardLayerEleven";
import PaymentHistoryOne from "../components/child/PaymentHistoryOne";

const HomePageEleven = () => {
  return (
    <>
      {/* MasterLayout */}
      <MasterLayout>
        {/* Breadcrumb */}
        <Breadcrumb title='Dashboard' />

        {/* DashBoardLayerEleven */}
        <DashBoardLayerEleven />
    
      </MasterLayout>
    </>
  );
};

export default HomePageEleven;
