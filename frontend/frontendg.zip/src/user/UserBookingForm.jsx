import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  FaCheckCircle,
  FaEllipsisV,
  FaEnvelope,
  FaPen,
  FaPrint,
  FaRegFilePdf,
  FaTimes,
  FaWhatsapp,
} from "react-icons/fa";

const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000";

const defaultSteps = [
  "Filter Project",
  "Select Unit",
  "Booking Confirmation",
];

const chipGroups = {
  unitType: ["Residential", "Commercial"],
};

const unitSeed = [
  { name: "3001", floor: 30, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "3002", floor: 30, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "3003", floor: 30, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "3004", floor: 30, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "3005", floor: 30, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "3006", floor: 30, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "2901", floor: 29, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "2902", floor: 29, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "2903", floor: 29, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "2904", floor: 29, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "2905", floor: 29, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2906", floor: 29, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2801", floor: 28, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "2802", floor: 28, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "2804", floor: 28, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "2805", floor: 28, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2806", floor: 28, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2803", floor: 28, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2701", floor: 27, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "2702", floor: 27, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2703", floor: 27, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "2704", floor: 27, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2705", floor: 27, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2706", floor: 27, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2601", floor: 26, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "2602", floor: 26, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2603", floor: 26, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2604", floor: 26, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2605", floor: 26, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "2606", floor: 26, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2501", floor: 25, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "unavailable" },
  { name: "2502", floor: 25, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2503", floor: 25, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2504", floor: 25, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2505", floor: 25, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2506", floor: 25, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 3, status: "available" },
  { name: "2401", floor: 24, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 2, status: "unavailable" },
  { name: "2402", floor: 24, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 2, status: "available" },
  { name: "2403", floor: 24, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 2, status: "selected" },
  { name: "2404", floor: 24, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 2, status: "available" },
  { name: "2405", floor: 24, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 2, status: "available" },
  { name: "2406", floor: 24, carpet: 1372, saleable: 2150, bedrooms: 3, bathrooms: 2, status: "available" },
];

const emptySelectedUnit = {
  ...unitSeed[0],
  name: "-",
  floor: "-",
  carpet: "-",
  saleable: "-",
  bedrooms: "-",
  bathrooms: "-",
  status: "available",
};

const paymentRows = [
  { name: "Agreement", milestone: "Agreement", percentage: 80, amount: 14326000, taxes: 0, tds: 0, grandTotal: 14326000 },
  { name: "Possession", milestone: "Possession", percentage: 20, amount: 3581500, taxes: 0, tds: 0, grandTotal: 3581500 },
];

const costCurrency = (value) =>
  `₹ ${Number(value || 0).toLocaleString("en-IN", {
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
  })}`;
const costNumber = (value) =>
  Number(value || 0).toLocaleString("en-IN", {
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
    useGrouping: false,
  });
const toNumber = (value, fallback = 0) => {
  if (typeof value === "number") return Number.isFinite(value) ? value : fallback;
  const parsed = Number(String(value || "").replace(/[^\d.-]/g, ""));
  return Number.isFinite(parsed) ? parsed : fallback;
};
const firstNumber = (...values) => {
  for (const value of values) {
    if (value !== undefined && value !== null && value !== "") {
      return toNumber(value, 0);
    }
  }
  return 0;
};
const getFloorSortValue = (value) => {
  const number = Number(value);
  return Number.isNaN(number) ? Number.NEGATIVE_INFINITY : number;
};
const getUnitPositionSortValue = (unit) => {
  const value = unit.unitIndex ?? unit.position ?? unit.name;
  const number = Number(value);
  return Number.isNaN(number) ? Number.MAX_SAFE_INTEGER : number;
};
const getRateBasisArea = ({ rateBasis, carpet, builtupArea, saleable }) => {
  if (rateBasis === "On Built-up") return toNumber(builtupArea, 0);
  if (rateBasis === "On Saleable") return toNumber(saleable, 0);
  return toNumber(carpet, 0);
};
const calculateBasePriceForRateBasis = ({ baseRate, rateBasis, carpet, builtupArea, saleable }) => {
  const rate = toNumber(baseRate, 0);
  const area = getRateBasisArea({ rateBasis, carpet, builtupArea, saleable });
  if (!rate || !area) return 0;
  return rate * area;
};
const calculateCostNewValue = (row) => {
  const original = toNumber(row.originalValue, 0);
  const input = toNumber(row.inputField, 0);
  return row.costType === "AdHoc Cost" ? original + input : Math.max(original - input, 0);
};
const confirmCurrency = (value) => `₹ ${Number(value || 0).toLocaleString("en-IN")}`;
const formatDisplayDate = (value) => {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString("en-GB");
};
const isPlaceholderProjectName = (value) => {
  const normalized = String(value || "").trim().toLowerCase();
  return ["no", "none", "na", "n/a", "null", "undefined", "-"].includes(normalized);
};
const compactCurrency = (value) => {
  const amount = Number(value || 0);
  if (amount >= 10000000) {
    return `₹ ${(amount / 10000000).toFixed(1).replace(/\.0$/, "")}Cr (${amount.toLocaleString("en-IN")})`;
  }
  if (amount >= 100000) {
    return `₹ ${(amount / 100000).toFixed(1).replace(/\.0$/, "")}L (${amount.toLocaleString("en-IN")})`;
  }
  return confirmCurrency(amount);
};
const escapeHtml = (value) =>
  String(value ?? "-")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");

const getProjectName = (project) =>
  project?.name || project?.projectName || project?.project_name || project?.title || "";

const getUserName = (user) =>
  [user?.firstName, user?.lastName].filter(Boolean).join(" ") ||
  user?.username ||
  user?.email ||
  `User #${user?.id}`;

const sourceOptions = ["Direct", "Bulk Marketing", "Referral", "Channel Partner"];

const normalizeBookingSource = (value) => {
  const source = String(value || "").trim();
  if (!source) return "Direct";
  if (source.toLowerCase() === "channel_partner") return "Channel Partner";
  return source;
};

const isChannelPartnerSource = (value) => normalizeBookingSource(value) === "Channel Partner";

const normalizeProjectTypeValue = (value) =>
  String(value || "")
    .toLowerCase()
    .replace(/[_-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

const matchesProjectTypeFilter = (unit, selectedType, project) => {
  if (!selectedType) return true;
  const selected = normalizeProjectTypeValue(selectedType);
  const projectType = normalizeProjectTypeValue(project?.projectType || unit?.projectType);
  const unitType = normalizeProjectTypeValue(unit?.unitType || unit?.type);

  if (projectType.includes("residential") && projectType.includes("commercial")) return true;
  if (projectType) return projectType === selected;
  if (unitType) return unitType === selected;
  return true;
};

const normalizeUnitPurpose = (value) =>
  String(value || "")
    .toLowerCase()
    .replace(/[_-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

const isRehabUnit = (unit) =>
  normalizeUnitPurpose(unit?.propertyPurpose || unit?.unitStream || unit?.floorPlanUnitStream).includes("rehab");

const getImageSource = (value) => {
  if (!value) return "";

  if (typeof value === "string") return value;

  if (Array.isArray(value)) {
    return value.map(getImageSource).find(Boolean) || "";
  }

  if (typeof value === "object") {
    return (
      value.dataUrl ||
      value.url ||
      value.src ||
      value.preview ||
      value.path ||
      value.image ||
      value.file ||
      ""
    );
  }

  return "";
};

const flattenDatabaseUnits = (unitGroups = []) =>
  unitGroups.flatMap((group) => {
    const directUnit = group?.unit || {};
    const floorPlan = group?.floor || directUnit?.floor || {};
    const models = Array.isArray(group?.unitList) && group.unitList.length ? group.unitList : [group];
    return models.map((unit, index) => ({
      id: unit?.id || group?.id || unit?.name,
      groupId: group?.id || directUnit?.id || unit?.unitId,
      unitItemId: unit?.id || "",
      unitId: group?.id || directUnit?.id || unit?.unitId || "",
      name: unit?.name || group?.name || `Unit ${index + 1}`,
      floor: unit?.floor || floorPlan?.name || group?.floor || "-",
      unitIndex: unit?.unitIndex,
      carpet: floorPlan?.carpet ?? "-",
      builtupArea: floorPlan?.builtupArea ?? "",
      saleable: floorPlan?.saleable ?? "-",
      rateBasis: floorPlan?.rateBasis || "On Carpet",
      bedrooms: floorPlan?.bedrooms ?? "-",
      bathrooms: floorPlan?.bathrooms ?? "-",
      baseRate: unit?.pricing?.baseRate ?? unit?.baseRate ?? group?.baseRate ?? "",
      basePrice: unit?.pricing?.finalPrice ?? unit?.finalPrice ?? unit?.basePrice ?? group?.basePrice ?? "",
      floorRise: unit?.pricing?.floorRiseAmount ?? unit?.floorRiseAmount ?? unit?.floorRise ?? group?.floorRise ?? "",
      floorRiseRate: unit?.pricing?.floorRisePerSqft ?? unit?.floorRisePerSqft ?? floorPlan?.floorRisePerSqft ?? "",
      floorRiseSteps: unit?.pricing?.floorRiseSteps ?? unit?.floorRiseSteps ?? "",
      riseFromFloor: unit?.pricing?.riseFromFloor ?? floorPlan?.baseFloorForFloorRise ?? "",
      reraArea: unit?.pricing?.reraArea ?? unit?.reraArea ?? floorPlan?.carpet ?? "",
      pricing: unit?.pricing || null,
      guidelineValue: unit?.guidelineValue || group?.guidelineValue || unit?.guideline_value || group?.guideline_value || "",
      developmentInvoice: unit?.developmentInvoice || group?.developmentInvoice || unit?.development_invoice || group?.development_invoice || "",
      agreementValue: unit?.agreementValue || group?.agreementValue || unit?.agreement_value || group?.agreement_value || "",
      totalPrice: unit?.totalPrice || group?.totalPrice || unit?.total_price || group?.total_price || "",
      propertyPurpose:
        unit?.propertyPurpose ||
        group?.propertyPurpose ||
        directUnit?.propertyPurpose ||
        floorPlan?.unitStream ||
        "",
      unitStream: floorPlan?.unitStream || group?.unitStream || "",
      legalDocumentationFee:
        unit?.legalDocumentationFee || group?.legalDocumentationFee || unit?.legal_documentation_fee || group?.legal_documentation_fee || "",
      electricityInfrastructureCharges:
        unit?.electricityInfrastructureCharges ||
        group?.electricityInfrastructureCharges ||
        unit?.electricity_infrastructure_charges ||
        group?.electricity_infrastructure_charges ||
        "",
      khataRegistrationCharges:
        unit?.khataRegistrationCharges || group?.khataRegistrationCharges || unit?.khata_registration_charges || group?.khata_registration_charges || "",
      maintenanceAdvance: unit?.maintenanceAdvance || group?.maintenanceAdvance || unit?.maintenance_advance || group?.maintenance_advance || "",
      stampDuty: unit?.stampDuty || group?.stampDuty || unit?.stamp_duty || group?.stamp_duty || "",
      projectId: group?.project?.id || directUnit?.project?.id || floorPlan?.project?.id || group?.projectId || "",
      projectName: getProjectName(group?.project || directUnit?.project || floorPlan?.project),
      towerId: group?.tower?.id || directUnit?.tower?.id || floorPlan?.tower?.id || group?.towerId || "",
      towerName: group?.tower?.name || directUnit?.tower?.name || floorPlan?.tower?.name || group?.towerName || "Tower",
      type: floorPlan?.type || group?.type || "",
      projectType: group?.project?.projectType || group?.projectType || "",
      image: getImageSource(
        unit?.image ||
          unit?.unitImage ||
          unit?.images ||
          group?.image ||
          group?.unitImage ||
          group?.images ||
          group?.floor?.floorPlanImages
      ),
      status:
        String(unit?.status || group?.status || unit?.unitStatus || group?.unitStatus || "")
          .toLowerCase()
          .replace(/\s+/g, "-") || "available",
    }));
  });

const normalizeUnitStatus = (status, unit) => {
  if (isRehabUnit(unit)) return "rehab";

  const value = String(status || "available").toLowerCase();
  if (["booked", "sold", "unavailable"].includes(value)) return "booked";
  if (["blocked", "block"].includes(value)) return "blocked";
  if (value === "refuge") return "refuge";
  if (value === "investor") return "investor";
  if (value === "selected") return "selected";
  return "available";
};

const UserBookingForm = ({
  isOpen,
  bookingSteps = defaultSteps,
  bookingStepIndex = 0,
  bookingMessage,
  bookingProjectMessage,
  bookingForm = {},
  leadName,
  isSavingBooking,
  isLoadingBookingProject,
  bookingSuccess = false,
  onClose,
  onSubmit,
  onPrevious,
  onMarkInterested,
  onFieldChange,
}) => {
  const [interestedUnits, setInterestedUnits] = useState(new Set());
  const [filters, setFilters] = useState({
    unitType: "",
  });
  const [completionActionMessage, setCompletionActionMessage] = useState("");
  const [bookingProjects, setBookingProjects] = useState([]);
  const [projectTowers, setProjectTowers] = useState([]);
  const [databaseUnitGroups, setDatabaseUnitGroups] = useState([]);
  const [channelPartners, setChannelPartners] = useState([]);
  const [isLoadingCatalog, setIsLoadingCatalog] = useState(false);
  const [isProjectMenuOpen, setIsProjectMenuOpen] = useState(false);
  const [projectSearch, setProjectSearch] = useState("");
  const [editableCostRows, setEditableCostRows] = useState([]);
  const [selectedTowerId, setSelectedTowerId] = useState("");
  const projectSelectRef = useRef(null);
  const selectedProjectId = bookingForm.projectId ? String(bookingForm.projectId) : "";
  const selectedProjectName = String(bookingForm.projectDetails || "").toLowerCase();

  useEffect(() => {
    if (!isOpen) return undefined;
    const previousBodyOverflow = document.body.style.overflow;
    const previousHtmlOverflow = document.documentElement.style.overflow;
    document.body.style.overflow = "hidden";
    document.documentElement.style.overflow = "hidden";

    return () => {
      document.body.style.overflow = previousBodyOverflow;
      document.documentElement.style.overflow = previousHtmlOverflow;
    };
  }, [isOpen]);

  useEffect(() => {
    if (!isProjectMenuOpen) return undefined;

    const closeProjectMenu = (event) => {
      if (projectSelectRef.current?.contains(event.target)) return;
      setIsProjectMenuOpen(false);
    };

    document.addEventListener("mousedown", closeProjectMenu);
    return () => document.removeEventListener("mousedown", closeProjectMenu);
  }, [isProjectMenuOpen]);

  useEffect(() => {
    if (!isOpen) return undefined;

    let isMounted = true;

    const loadBookingCatalog = async () => {
      setIsLoadingCatalog(true);

      try {
        const [projectsResponse, unitsResponse, usersResponse] = await Promise.all([
          fetch(`${API_URL}/projects`),
          fetch(`${API_URL}/unit?limit=1000`),
          fetch(`${API_URL}/users?limit=1000`),
        ]);

        const projectsResult = projectsResponse.ok ? await projectsResponse.json() : [];
        const unitsResult = unitsResponse.ok ? await unitsResponse.json() : {};
        const usersResult = usersResponse.ok ? await usersResponse.json() : {};

        if (!isMounted) return;

        setBookingProjects(Array.isArray(projectsResult) ? projectsResult : projectsResult?.data || []);
        setDatabaseUnitGroups(Array.isArray(unitsResult) ? unitsResult : unitsResult?.items || unitsResult?.data || []);
        setChannelPartners((Array.isArray(usersResult) ? usersResult : usersResult?.data || []).filter(
          (user) => String(user?.role || "").toUpperCase() === "CHANNEL_PARTNER"
        ));
      } catch (error) {
        console.error("Unable to load booking project catalog:", error);
        if (isMounted) {
          setBookingProjects([]);
          setDatabaseUnitGroups([]);
          setChannelPartners([]);
        }
      } finally {
        if (isMounted) setIsLoadingCatalog(false);
      }
    };

    loadBookingCatalog();

    return () => {
      isMounted = false;
    };
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen || !selectedProjectId) return undefined;

    let isMounted = true;

    const loadProjectInventory = async () => {
      setIsLoadingCatalog(true);
      setSelectedTowerId("");

      try {
        const [towerResponse, unitResponse] = await Promise.all([
          fetch(`${API_URL}/tower/list?projectId=${selectedProjectId}`),
          fetch(`${API_URL}/unit?limit=1000&projectId=${selectedProjectId}`),
        ]);

        const towerResult = towerResponse.ok ? await towerResponse.json() : [];
        const unitResult = unitResponse.ok ? await unitResponse.json() : {};

        if (!isMounted) return;

        setProjectTowers(
          Array.isArray(towerResult)
            ? towerResult
            : Array.isArray(towerResult?.data)
              ? towerResult.data
              : Array.isArray(towerResult?.towers)
                ? towerResult.towers
                : []
        );
        setDatabaseUnitGroups(Array.isArray(unitResult) ? unitResult : unitResult?.items || unitResult?.data || []);
      } catch (error) {
        console.error("Unable to load project towers and units:", error);
        if (isMounted) {
          setProjectTowers([]);
          setDatabaseUnitGroups([]);
        }
      } finally {
        if (isMounted) setIsLoadingCatalog(false);
      }
    };

    loadProjectInventory();

    return () => {
      isMounted = false;
    };
  }, [API_URL, isOpen, selectedProjectId]);

  const databaseUnits = useMemo(() => flattenDatabaseUnits(databaseUnitGroups), [databaseUnitGroups]);
  const catalogUnits = useMemo(() => {
    const realUnits = databaseUnits.filter((unit) => {
      if (selectedProjectId) return String(unit.projectId) === selectedProjectId;
      if (selectedProjectName) return String(unit.projectName || "").toLowerCase() === selectedProjectName;
      return true;
    });

    return realUnits;
  }, [databaseUnits, selectedProjectId, selectedProjectName]);
  const towerOptions = useMemo(
    () => {
      if (projectTowers.length) {
        return projectTowers.map((tower) => ({
          id: String(tower.id),
          name: tower.name || `Tower ${tower.id}`,
        }));
      }

      const towerMap = new Map();
      catalogUnits.forEach((unit) => {
        const id = String(unit.towerId || unit.towerName || "Tower");
        if (!towerMap.has(id)) {
          towerMap.set(id, {
            id,
            name: unit.towerName || "Tower",
          });
        }
      });

      return Array.from(towerMap.values());
    },
    [catalogUnits, projectTowers]
  );
  const filteredCatalogUnits = useMemo(() => {
    const selectedProject = bookingProjects.find((project) => String(project.id) === selectedProjectId);

    return catalogUnits.filter((unit) => {
      const towerMatches =
        !selectedTowerId ||
        String(unit.towerId || unit.towerName || "Tower") === selectedTowerId;
      const typeMatches = matchesProjectTypeFilter(unit, filters.unitType, selectedProject);

      return towerMatches && typeMatches;
    });
  }, [bookingProjects, catalogUnits, filters.unitType, selectedProjectId, selectedTowerId]);
  const selectedTowerName =
    towerOptions.find((tower) => String(tower.id) === String(selectedTowerId))?.name || "";

  const selectedUnit = useMemo(() => {
    return (
      filteredCatalogUnits.find((unit) => unit.name === bookingForm.unit) ||
      filteredCatalogUnits.find((unit) => unit.status === "selected") ||
      filteredCatalogUnits[0] ||
      emptySelectedUnit
    );
  }, [bookingForm.unit, filteredCatalogUnits]);

  useEffect(() => {
    if (!selectedTowerId) return;
    if (towerOptions.some((tower) => String(tower.id) === String(selectedTowerId))) return;
    setSelectedTowerId("");
  }, [selectedTowerId, towerOptions]);

  useEffect(() => {
    setEditableCostRows([]);
  }, [bookingForm.customerName, bookingForm.phone, bookingForm.projectId, bookingForm.projectDetails, bookingForm.unit, bookingForm.unitId]);

  const updateField = (name, value) => {
    if (!onFieldChange) return;
    onFieldChange({ target: { name, value } });
  };

  const selectProjectOption = (value) => {
    setIsProjectMenuOpen(false);
    setProjectSearch("");

    if (value === "__lead_project__") {
      updateField("projectId", "");
      return;
    }

    const project = bookingProjects.find((item) => String(item.id) === String(value));
    updateField("projectId", value);
    updateField("projectDetails", getProjectName(project));
    updateField("unit", "");
    updateField("unitId", "");
    updateField("unitItemId", "");
    setSelectedTowerId("");
  };

  const selectUnit = (unit) => {
    if (["booked", "blocked", "refuge", "investor", "rehab"].includes(normalizeUnitStatus(unit.status, unit))) return;
    updateField("unit", unit.name);
    updateField("unitId", unit.unitId || unit.groupId || "");
    updateField("unitItemId", unit.unitItemId || unit.id || "");
    updateField("saleableArea", unit.saleable);
    updateField("carpetArea", unit.carpet);
    updateField("builtupArea", unit.builtupArea || "");
    updateField("rateBasis", unit.rateBasis || "On Carpet");
    const nextBaseRate = unit.baseRate || bookingForm.baseRate || "";
    updateField("baseRate", nextBaseRate);
    updateField("closingBaseRate", unit.closingBaseRate || nextBaseRate || bookingForm.closingBaseRate || "");
    updateField("floorRise", unit.floorRise || "");
    updateField("floorRiseRate", unit.floorRiseRate || "");
    updateField("floorRiseSteps", unit.floorRiseSteps ?? "");
    updateField("riseFromFloor", unit.riseFromFloor || "");
    updateField("reraArea", unit.reraArea || unit.carpet || "");
    const calculatedBasePrice =
      unit.basePrice ||
      unit.pricing?.finalPrice ||
      calculateBasePriceForRateBasis({
        baseRate: unit.baseRate || bookingForm.baseRate,
        rateBasis: unit.rateBasis || bookingForm.rateBasis,
        carpet: unit.carpet,
        builtupArea: unit.builtupArea,
        saleable: unit.saleable,
      }) ||
      bookingForm.basePrice ||
      "";
    updateField("basePrice", calculatedBasePrice);
    updateField("agreementValue", unit.agreementValue || calculatedBasePrice || bookingForm.agreementValue || "");
    updateField("totalPrice", unit.totalPrice || unit.agreementValue || calculatedBasePrice || bookingForm.totalPrice || "");
  };

  const markInterested = () => {
    if (bookingForm.unit) {
      setInterestedUnits((current) => new Set(current).add(bookingForm.unit));
    }
    onMarkInterested?.();
  };

  const submitLabel = isSavingBooking
    ? "Saving..."
    : isLoadingBookingProject
      ? "Loading..."
      : bookingStepIndex === 0
        ? "Next"
        : bookingStepIndex === 1
          ? "Continue to Confirmation"
          : "Confirm Booking";

  const isSubmitDisabled =
    isSavingBooking ||
    isLoadingBookingProject ||
    (bookingStepIndex === 0 && !bookingForm.projectDetails) ||
    (bookingStepIndex === 1 && !bookingForm.unit) ||
    (bookingStepIndex === 2 && !bookingForm.customerName && !leadName);

  const allFloorGroups = useMemo(() => {
    const groups = new Map();

    filteredCatalogUnits.forEach((unit) => {
      const floor = unit.floor ?? "-";
      if (!groups.has(floor)) {
        groups.set(floor, {
          floor,
          units: [],
        });
      }
      groups.get(floor).units.push(unit);
    });

    return Array.from(groups.values())
      .sort((a, b) => {
        const floorDiff = getFloorSortValue(b.floor) - getFloorSortValue(a.floor);
        if (floorDiff) return floorDiff;
        return String(b.floor).localeCompare(String(a.floor));
      })
      .map((group) => ({
        ...group,
        units: group.units.slice().sort((a, b) => {
          const positionDiff = getUnitPositionSortValue(a) - getUnitPositionSortValue(b);
          if (positionDiff) return positionDiff;
          return String(a.name || "").localeCompare(String(b.name || ""));
        }),
      }));
  }, [filteredCatalogUnits]);
  const quotationName = [
    bookingForm.projectDetails || selectedUnit.projectName,
    selectedTowerName || selectedUnit.towerName,
    selectedUnit.name,
  ].filter(Boolean).join(" - ");
  const baseRateValue = toNumber(bookingForm.baseRate, toNumber(selectedUnit.baseRate, 7750));
  const closingBaseRateValue = firstNumber(bookingForm.closingBaseRate, selectedUnit.closingBaseRate, baseRateValue);
  const saleableValue = toNumber(bookingForm.saleableArea, toNumber(selectedUnit.saleable, 0));
  const carpetValue = toNumber(bookingForm.carpetArea, toNumber(selectedUnit.carpet, 0));
  const builtupValue = toNumber(bookingForm.builtupArea, toNumber(selectedUnit.builtupArea, 0));
  const rateBasisValue = bookingForm.rateBasis || selectedUnit.rateBasis || "On Carpet";
  const floorRiseRateValue = firstNumber(bookingForm.floorRiseRate, selectedUnit.floorRiseRate, 0);
  const floorRiseStepsValue = firstNumber(bookingForm.floorRiseSteps, selectedUnit.floorRiseSteps, 0);
  const riseFromFloorValue = firstNumber(bookingForm.riseFromFloor, selectedUnit.riseFromFloor, 0);
  const reraAreaValue = firstNumber(bookingForm.reraArea, selectedUnit.reraArea, carpetValue, 0);
  const floorRisePerSqftTotal = floorRiseRateValue * floorRiseStepsValue;
  const floorRiseValue = (reraAreaValue && floorRisePerSqftTotal)
    ? (reraAreaValue * floorRisePerSqftTotal)
    : firstNumber(bookingForm.floorRise, selectedUnit.floorRise, 0);
  const effectiveRate = closingBaseRateValue + floorRisePerSqftTotal;
  const fallbackBasePriceValue = reraAreaValue ? (closingBaseRateValue * reraAreaValue) : calculateBasePriceForRateBasis({
    baseRate: closingBaseRateValue,
    rateBasis: rateBasisValue,
    carpet: carpetValue,
    builtupArea: builtupValue,
    saleable: saleableValue,
  });
  const basePriceValue = (reraAreaValue && effectiveRate)
    ? (reraAreaValue * effectiveRate)
    : (firstNumber(bookingForm.basePrice, selectedUnit.basePrice) || fallbackBasePriceValue);
  const guidelineValue = firstNumber(bookingForm.guidelineValue, selectedUnit.guidelineValue);
  const developmentInvoiceValue = firstNumber(bookingForm.developmentInvoice, selectedUnit.developmentInvoice);
  const agreementOriginalValue =
    firstNumber(bookingForm.agreementValue, selectedUnit.agreementValue) ||
    basePriceValue + guidelineValue + developmentInvoiceValue;
  const defaultCostRows = useMemo(
    () => [
      { type: "section", serial: "1.", name: "Basic Details" },
      { serial: "1.a", name: "Base Rate", originalValue: baseRateValue, costType: "Discount", inputField: 0, highlight: true },
      { serial: "1.b", name: "Floor Rise Rate", originalValue: floorRiseRateValue, costType: "Discount", inputField: 0 },
      { serial: "1.c", name: "Floor Rise Steps", originalValue: floorRiseStepsValue, costType: "Discount", inputField: 0 },
      { serial: "1.d", name: "Floor Rise Amount", originalValue: floorRiseValue, costType: "Discount", inputField: 0 },
      { type: "section", serial: "2.", name: "Agreement Value Details" },
      { serial: "2.a", name: "Base Price", originalValue: basePriceValue, costType: "Discount", inputField: 0 },
      { serial: "2.b", name: "Guideline Value", originalValue: guidelineValue, costType: "Discount", inputField: 0 },
      { serial: "2.c", name: "Development Invoice", originalValue: developmentInvoiceValue, costType: "Discount", inputField: 0 },
      { serial: "2.d", name: "Agreement Value", originalValue: agreementOriginalValue, costType: "Discount", inputField: 0, highlight: true },
      { type: "section", serial: "3.", name: "Additional Details" },
      {
        serial: "3.a",
        name: "Legal Documentation Fee",
        originalValue: firstNumber(bookingForm.legalDocumentationFee, selectedUnit.legalDocumentationFee),
        costType: "Discount",
        inputField: 0,
      },
      {
        serial: "3.b",
        name: "Electricity Infrastructure Charges",
        originalValue: firstNumber(bookingForm.electricityInfrastructureCharges, selectedUnit.electricityInfrastructureCharges),
        costType: "Discount",
        inputField: 0,
      },
      {
        serial: "3.c",
        name: "Khata Registration Charges",
        originalValue: firstNumber(bookingForm.khataRegistrationCharges, selectedUnit.khataRegistrationCharges),
        costType: "Discount",
        inputField: 0,
      },
      {
        serial: "3.d",
        name: "Maintenance Advance",
        originalValue: firstNumber(bookingForm.maintenanceAdvance, selectedUnit.maintenanceAdvance),
        costType: "Discount",
        inputField: 0,
      },
      {
        serial: "3.e",
        name: "Stamp Duty",
        originalValue: firstNumber(bookingForm.stampDuty, selectedUnit.stampDuty),
        costType: "Discount",
        inputField: 0,
      },
      { type: "section", serial: "4.", name: "Total Price Details" },
      {
        serial: "4.a",
        name: "Total Price",
        originalValue: firstNumber(bookingForm.totalPrice, selectedUnit.totalPrice) || agreementOriginalValue,
        costType: "Discount",
        inputField: 0,
        highlight: true,
      },
    ],
    [
      agreementOriginalValue,
      basePriceValue,
      baseRateValue,
      bookingForm.closingBaseRate,
      bookingForm.electricityInfrastructureCharges,
      bookingForm.khataRegistrationCharges,
      bookingForm.legalDocumentationFee,
      bookingForm.maintenanceAdvance,
      bookingForm.stampDuty,
      bookingForm.totalPrice,
      developmentInvoiceValue,
      floorRiseValue,
      floorRiseRateValue,
      floorRiseStepsValue,
      guidelineValue,
      selectedUnit.closingBaseRate,
      selectedUnit.electricityInfrastructureCharges,
      selectedUnit.khataRegistrationCharges,
      selectedUnit.legalDocumentationFee,
      selectedUnit.maintenanceAdvance,
      selectedUnit.stampDuty,
      selectedUnit.totalPrice,
    ]
  );
  const quoteCostRows = editableCostRows.length ? editableCostRows : defaultCostRows;
  const quoteLineRows = quoteCostRows
    .filter((row) => row.type !== "section")
    .map((row) => ({ ...row, newValue: calculateCostNewValue(row) }));
  const agreementValue =
    toNumber(quoteLineRows.find((row) => row.name === "Agreement Value")?.newValue, 0) ||
    agreementOriginalValue ||
    basePriceValue;
  const allInclusiveValue =
    toNumber(quoteLineRows.find((row) => row.name === "Total Price")?.newValue, 0) ||
    quoteLineRows
      .filter((row) => !["Base Rate", "Floor Rise", "Floor Rise Rate", "Floor Rise Steps", "Floor Rise Amount", "Total Price"].includes(row.name))
      .reduce((total, row) => total + toNumber(row.newValue, 0), 0) ||
    agreementValue;
  const unitStatusCounts = filteredCatalogUnits.reduce(
    (counts, unit) => {
      const status = normalizeUnitStatus(unit.status, unit);
      counts[status] = (counts[status] || 0) + 1;
      return counts;
    },
    { all: filteredCatalogUnits.length, available: 0, booked: 0, blocked: 0, refuge: 0, investor: 0, rehab: 0 }
  );
  const selectedProject = bookingProjects.find((project) => String(project.id) === selectedProjectId);
  const leadProjectDetails = isPlaceholderProjectName(bookingForm.projectDetails) ? "" : bookingForm.projectDetails;
  const hasLeadProjectOption =
    leadProjectDetails && !bookingProjects.some((project) => getProjectName(project) === leadProjectDetails);
  const projectSelectLabel = isLoadingCatalog
    ? "Loading projects..."
    : selectedProjectId
      ? getProjectName(selectedProject) || leadProjectDetails || "Select Project"
      : leadProjectDetails || (bookingProjects.length ? "Select Project" : "No projects found");
  const projectSearchQuery = projectSearch.trim().toLowerCase();
  const filteredBookingProjects = projectSearchQuery
    ? bookingProjects.filter((project) => getProjectName(project).toLowerCase().includes(projectSearchQuery))
    : bookingProjects;
  const shouldShowLeadProjectOption =
    hasLeadProjectOption && (!projectSearchQuery || leadProjectDetails.toLowerCase().includes(projectSearchQuery));

  const syncCostSheetFields = (rows) => {
    const lineRows = rows
      .filter((row) => row.type !== "section")
      .map((row) => ({ ...row, newValue: calculateCostNewValue(row) }));
    const nextAgreementValue =
      toNumber(lineRows.find((row) => row.name === "Agreement Value")?.newValue, 0) ||
      agreementOriginalValue ||
      basePriceValue;
    const nextTotalPrice =
      toNumber(lineRows.find((row) => row.name === "Total Price")?.newValue, 0) ||
      lineRows
        .filter((row) => !["Base Rate", "Floor Rise", "Floor Rise Rate", "Floor Rise Steps", "Floor Rise Amount", "Total Price"].includes(row.name))
        .reduce((total, row) => total + toNumber(row.newValue, 0), 0) ||
      nextAgreementValue;

    updateField("agreementValue", nextAgreementValue);
    updateField("totalPrice", nextTotalPrice);
    updateField(
      "costSheet",
      lineRows.map((row) => ({
        fieldName: row.name,
        originalValue: toNumber(row.originalValue, 0),
        costType: row.costType || "Discount",
        inputField: toNumber(row.inputField, 0),
        newValue: toNumber(row.newValue, 0),
      }))
    );
  };

  const handleCostRowChange = (serial, field, value) => {
    const nextRows = (editableCostRows.length ? editableCostRows : defaultCostRows).map((row) =>
      row.serial === serial ? { ...row, [field]: value } : row
    );
    setEditableCostRows(nextRows);
    syncCostSheetFields(nextRows);
  };

  if (!isOpen) return null;

  const renderUnitGallery = () => (
    <aside className="ubf-side-panel">
      <h6>Unit Gallery</h6>
      <div className="ubf-gallery">
        {selectedUnit.image ? (
          <img className="ubf-unit-gallery-image" src={selectedUnit.image} alt={`${selectedUnit.name} floor plan`} />
        ) : (
          <div className="ubf-floorplan" aria-label="No unit image available">
            <span />
            <span />
            <span />
            <span />
          </div>
        )}
        <div className="ubf-building-shot" />
      </div>
      <h6>Unit Details Card</h6>
      <div className="ubf-unit-card">
        {selectedUnit.image && (
          <img className="ubf-unit-card-image" src={selectedUnit.image} alt={`${selectedUnit.name} preview`} />
        )}
        <strong>{selectedUnit.name}</strong>
        <div><span>Floor</span><b>{selectedUnit.floor}</b></div>
        <div><span>Carpet Area</span><b>{selectedUnit.carpet} Sq. Ft.</b></div>
        <div><span>Saleable Area</span><b>{selectedUnit.saleable} Sq. Ft.</b></div>
        <div><span>Bedrooms</span><b>{selectedUnit.bedrooms}</b></div>
        <div><span>Bathrooms</span><b>{selectedUnit.bathrooms}</b></div>
      </div>
    </aside>
  );

  const renderStepOne = () => (
    <div className="ubf-step ubf-start-step">
      <section className="ubf-start-choice">
        {/* <div className="ubf-start-art ubf-search-art" aria-hidden="true">
          <div className="ubf-person" />
          <div className="ubf-magnifier" />
          <div className="ubf-skyline" />
          <div className="ubf-start-house" />
        </div> */}
        <h6>Select Project For Booking</h6>
        <p>Start by selecting a project that you like and we will guide you further</p>
        <label className="ubf-field ubf-project-select" ref={projectSelectRef}>
          <span>Select Project</span>
          <button
            type="button"
            className="ubf-project-select-button"
            disabled={isLoadingCatalog || (!bookingProjects.length && !bookingForm.projectDetails)}
            onClick={() => setIsProjectMenuOpen((current) => !current)}
          >
            {projectSelectLabel}
          </button>
          {isProjectMenuOpen && (
            <div className="ubf-project-select-menu" role="listbox">
              <div className="ubf-project-search-wrap">
                <input
                  autoFocus
                  className="ubf-project-search"
                  type="search"
                  value={projectSearch}
                  onChange={(event) => setProjectSearch(event.target.value)}
                  placeholder="Search project..."
                  aria-label="Search project"
                />
              </div>
            {filteredBookingProjects.map((project) => (
              <button
                type="button"
                className={String(project.id) === selectedProjectId ? "active" : ""}
                key={project.id}
                onClick={() => selectProjectOption(project.id)}
                role="option"
                aria-selected={String(project.id) === selectedProjectId}
              >
                {getProjectName(project)}
              </button>
            ))}
            {shouldShowLeadProjectOption && (
              <button
                type="button"
                className={!selectedProjectId ? "active" : ""}
                onClick={() => selectProjectOption("__lead_project__")}
                role="option"
                aria-selected={!selectedProjectId}
              >
                {bookingForm.projectDetails}
              </button>
            )}
            {!filteredBookingProjects.length && !shouldShowLeadProjectOption && (
              <div className="ubf-project-empty">No matching projects found.</div>
            )}
            </div>
          )}
        </label>
      </section>

      
{/* 
      <section className="ubf-start-choice">
        {renderProjectIllustration()}
        <h3>Quick Unit Selection</h3>
        <p>Know your unit? Select it here and proceed to book directly.</p>
        <label className="ubf-field">
          <span>Select Unit</span>
          <select value={bookingForm.unit || ""} onChange={(event) => {
            const unit = catalogUnits.find((item) => item.name === event.target.value);
            if (unit) {
              if (unit.projectId) updateField("projectId", unit.projectId);
              if (unit.projectName) updateField("projectDetails", unit.projectName);
              selectUnit(unit);
            }
          }}>
            <option value="">{isLoadingCatalog ? "Loading units..." : "Search Units"}</option>
            {catalogUnits.filter((unit) => unit.status !== "unavailable").map((unit) => (
              <option key={`${unit.id}-${unit.name}`} value={unit.name}>
                {unit.name} {unit.projectName ? `- ${unit.projectName}` : ""}
              </option>
            ))}
          </select>
        </label>
      </section> */}
    </div>
  );

  const renderStepTwo = () => (
    <div className="ubf-step ubf-unit-step">
      <aside className="ubf-filter-rail">
        <h6>Filters By</h6>
        {Object.entries(chipGroups).map(([key, values]) => (
          <div className="ubf-chip-block compact" key={key}>
            <span>{key === "unitType" ? "Project Type" : key.replace(/([A-Z])/g, " $1")}</span>
            <div className="ubf-chip-row">
              {values.map((value) => (
                <button
                  type="button"
                  key={value}
                  className={filters[key] === value ? "active" : ""}
                  onClick={() => setFilters((current) => ({ ...current, [key]: value }))}
                >
                  {value}
                </button>
              ))}
            </div>
          </div>
        ))}
      </aside>

      <section className="ubf-unit-board">
        <div className="ubf-unit-toolbar">
          <div>
            <h6>Select Unit</h6>
            <strong>{selectedTowerName || "All Towers"}</strong>
          </div>
          <div className="ubf-unit-actions">
            <label className="ubf-tower-select">
              <span>Select Tower</span>
              <select
                value={selectedTowerId}
                onChange={(event) => {
                  setSelectedTowerId(event.target.value);
                  updateField("unit", "");
                  updateField("unitId", "");
                  updateField("unitItemId", "");
                }}
              >
                <option value="">
                  {towerOptions.length ? "All Towers" : "No towers found"}
                </option>
                {towerOptions.map((tower) => (
                  <option key={tower.id} value={tower.id}>
                    {tower.name}
                  </option>
                ))}
              </select>
            </label>
          </div>
        </div>
        <div className="ubf-status-counters">
          {[
            ["all", "All"],
            ["available", "Available"],
            ["booked", "Booked"],
            ["blocked", "Blocked"],
            ["refuge", "Refuge"],
            ["investor", "Investor"],
            ["rehab", "Rehab"],
          ].map(([key, label]) => (
            <span key={key}>
              <b>{unitStatusCounts[key] || 0}</b> {label}
            </span>
          ))}
        </div>

        <div className="ubf-floor-grid">
          {filteredCatalogUnits.length === 0 && (
            <div className="ubf-unit-empty">No units found for this project tower.</div>
          )}
          {allFloorGroups.map(({ floor, units }) => (
            <React.Fragment key={floor}>
              <div className="ubf-floor-label">Floor {floor}</div>
              <div className="ubf-units-line">
                {units.map((unit) => {
                  const status = normalizeUnitStatus(unit.status, unit);
                  const tone = bookingForm.unit === unit.name ? "selected" : interestedUnits.has(unit.name) ? "interested" : status;
                  const isLocked = ["booked", "blocked", "refuge", "investor", "rehab"].includes(status);
                  return (
                    <button
                      type="button"
                      key={`${unit.id}-${unit.name}`}
                      className={`ubf-unit-cell ${tone}`}
                      onClick={() => selectUnit(unit)}
                      disabled={isLocked}
                      title={`Flat no: ${unit.name}${isRehabUnit(unit) ? " - Rehab Unit" : ""}`}
                    >
                      {unit.image ? (
                        <img src={unit.image} alt="" />
                      ) : (
                        <span className="ubf-unit-plan" aria-hidden="true">
                          <i />
                          <i />
                          <i />
                          <i />
                        </span>
                      )}
                      <b>Flat no : {unit.name}</b>
                      <small>{unit.basePrice ? compactCurrency(unit.basePrice) : ""}</small>
                      <FaEllipsisV aria-hidden="true" />
                    </button>
                  );
                })}
              </div>
            </React.Fragment>
          ))}
        </div>
      </section>

      {renderUnitGallery()}
    </div>
  );

  // eslint-disable-next-line no-unused-vars
  const renderCostSheet = () => (
    <div className="ubf-cost-table">
      <h6>Cost Sheet</h6>
      <div className="ubf-cost-head">
        <span>Sr. No.</span>
        <span>Field Name</span>
        <span>Original Value</span>
        <span>Discount Or AdHoc Cost</span>
        <span>Input Field</span>
        <span>New Value</span>
      </div>
      {quoteCostRows.map((row) =>
        row.type === "section" ? (
          <div className="ubf-cost-section" key={row.serial}>{row.serial} {row.name}</div>
        ) : (
          <div className={`ubf-cost-row${row.highlight ? " highlight" : ""}`} key={row.serial}>
            <span>{row.serial}</span>
            <strong>{row.name}</strong>
            <span className="ubf-cost-money">{costCurrency(row.originalValue)}</span>
            <div className="ubf-cost-select-cell">
              <select
                value={row.costType || "Discount"}
                onChange={(event) => handleCostRowChange(row.serial, "costType", event.target.value)}
              >
                <option value="Discount">Discount</option>
                <option value="AdHoc Cost">AdHoc Cost</option>
              </select>
            </div>
            <label className="ubf-money-input">
              <span>₹</span>
              <input
                type="number"
                min="0"
                value={row.inputField ?? 0}
                onChange={(event) => handleCostRowChange(row.serial, "inputField", event.target.value)}
              />
            </label>
            <label className="ubf-money-input readonly">
              <span>₹</span>
              <input type="text" value={costNumber(calculateCostNewValue(row))} readOnly />
            </label>
          </div>
        )
      )}
    </div>
  );

  // eslint-disable-next-line no-unused-vars
  const renderPaymentSchedule = () => {
    const totalPercentage = paymentRows.reduce((sum, row) => sum + row.percentage, 0);
    const totalAmount = paymentRows.reduce((sum, row) => sum + row.amount, 0);
    const totalTaxes = paymentRows.reduce((sum, row) => sum + row.taxes, 0);
    const totalTds = paymentRows.reduce((sum, row) => sum + row.tds, 0);
    const totalGrand = paymentRows.reduce((sum, row) => sum + row.grandTotal, 0);

    return (
      <div className="ubf-payment-schedule">
        <h6>Payment Schedule</h6>
        <p>Payment Schedule for Agreement Value</p>
        <div className="ubf-payment-table">
          <div className="ubf-payment-head">
            <span>Name/Date</span>
            <span>Tower Milestone</span>
            <span>Value (In Percentage %)</span>
            <span>Amount</span>
            <span>Taxes <small>i</small></span>
            <span>TDS <small>i</small></span>
            <span>Grand Total</span>
          </div>
          {paymentRows.map((row) => (
            <div className="ubf-payment-row" key={row.name}>
              <div className="ubf-payment-name">
                <button type="button" aria-label={`Add ${row.name} schedule row`}>+</button>
                <span>{row.name}</span>
                <FaPen />
              </div>
              <div className="ubf-payment-control">
                <select defaultValue={row.milestone}>
                  <option>Agreement</option>
                  <option>Possession</option>
                </select>
              </div>
              <div className="ubf-payment-control">
                <input type="number" defaultValue={row.percentage} />
              </div>
              <label className="ubf-money-input">
                <span>₹</span>
                <input type="text" value={costNumber(row.amount)} readOnly />
              </label>
              <span className="ubf-payment-money">{costCurrency(row.taxes)}</span>
              <span className="ubf-payment-money">{costCurrency(row.tds)}</span>
              <span className="ubf-payment-money">{costCurrency(row.grandTotal)}</span>
            </div>
          ))}
          <div className="ubf-payment-row total">
            <strong>Total Agreement Value</strong>
            <span>-</span>
            <span>{totalPercentage}%</span>
            <span>{costCurrency(totalAmount)}</span>
            <span>{costCurrency(totalTaxes)}</span>
            <span>{costCurrency(totalTds)}</span>
            <span>{costCurrency(totalGrand)}</span>
          </div>
        </div>
      </div>
    );
  };

  const renderConfirmField = ({ label, name, value, type = "input", options = [], placeholder = "", disabled = false, clearable = false }) => (
    <label className="ubf-confirm-field" key={name || label}>
      <span>
        {label}
        {clearable && (
          <button type="button" onClick={() => updateField(name, "")}>
            clear value
          </button>
        )}
      </span>
      {type === "select" ? (
        <select value={bookingForm[name] || value || ""} onChange={(event) => updateField(name, event.target.value)}>
          {options.map((option, index) => (
            <option key={`${option}-${index}`} value={option}>
              {option}
            </option>
          ))}
        </select>
      ) : (
        <input
          disabled={disabled}
          placeholder={placeholder}
          value={bookingForm[name] || value || ""}
          onChange={(event) => updateField(name, event.target.value)}
        />
      )}
    </label>
  );

  const renderPricingField = ({ label, name, value }) => (
    <label className="ubf-confirm-fact ubf-price-edit" key={name}>
      <span>{label}</span>
      <input
        type="number"
        min="0"
        step="0.01"
        value={bookingForm[name] ?? value ?? ""}
        onChange={(event) => updateField(name, event.target.value)}
        onWheel={(event) => event.currentTarget.blur()}
      />
      <small>{confirmCurrency(bookingForm[name] ?? value)}</small>
    </label>
  );

  const renderConfirmSection = (title, children, className = "") => (
    <section className={`ubf-confirm-section ${className}`}>
      <h3>{title}</h3>
      <div className="ubf-confirm-section-body">{children}</div>
    </section>
  );

  const renderStepFour = () => {
    const bookingDate = bookingForm.bookingDate || new Date().toLocaleDateString("en-GB");
    const applicantName = bookingForm.customerName || leadName || "-";
    const applicantEmail = bookingForm.email || "-";
    const applicantPhone = bookingForm.phone || "-";
    return (
      <div className="ubf-step ubf-confirm-step">
        <h4 className="ubf-confirm-title">Booking Confirmation</h4>

        {renderConfirmSection(
          "Unit Details",
          <div className="ubf-confirm-unit-grid">
            {[
              ["Name", selectedUnit.name],
              ["Status", selectedUnit.status === "unavailable" ? "Unavailable" : "Available"],
              ["Floor", selectedUnit.floor],
              ["Project Tower Name", selectedTowerName || selectedUnit.towerName || "Tower"],
              ["Bedrooms", selectedUnit.bedrooms],
              ["Bathrooms", selectedUnit.bathrooms],
              ["Carpet", carpetValue.toLocaleString("en-IN")],
              ["Saleable", `${saleableValue.toLocaleString("en-IN")} sq_ft`],
              ["RERA Area", `${reraAreaValue.toLocaleString("en-IN")} sq_ft`],
              ["Base Rate", `₹ ${(baseRateValue / 1000).toFixed(1).replace(/\.0$/, "")}K (${baseRateValue.toLocaleString("en-IN")})`],
              ["Floor Rise Rate", floorRiseRateValue.toLocaleString("en-IN")],
              ["Rise From Floor", riseFromFloorValue || "-"],
              ["Rise Steps", floorRiseStepsValue.toLocaleString("en-IN")],
              ["Floor Rise Amount", confirmCurrency(floorRiseValue)],
              ["Effective Rate", effectiveRate.toLocaleString("en-IN")],
              ["Total Price", compactCurrency(allInclusiveValue)],
              ["Agreement Value", compactCurrency(agreementValue)],
            ]
              .filter(([label]) => !["Base Rate", "Total Price", "Agreement Value"].includes(label))
              .map(([label, value]) => (
              <div className="ubf-confirm-fact" key={label}>
                <span>{label}</span>
                <strong>{value}</strong>
              </div>
            ))}
            {renderPricingField({ label: "Base Rate", name: "baseRate", value: baseRateValue })}
            {renderPricingField({ label: "Closing Base Rate", name: "closingBaseRate", value: closingBaseRateValue })}
            {renderPricingField({ label: "Total Price", name: "totalPrice", value: allInclusiveValue })}
            {renderPricingField({ label: "Agreement Value", name: "agreementValue", value: agreementValue })}
            {renderConfirmField({ label: "Booking Name", name: "bookingName", value: applicantName })}
            {renderConfirmField({ label: "Booking Date", name: "bookingDate", value: bookingDate })}
          </div>
        )}

        {renderConfirmSection(
          "Applicant Details",
          <>
            <div className="ubf-applicant-grid">
              {[
                ["Name", applicantName],
                ["Lead Name", leadName || applicantName],
                ["Phone", applicantPhone],
                ["DOB", formatDisplayDate(bookingForm.dob)],
                ["PAN Number", bookingForm.panNumber || "-"],
                ["Aadhaar Number", bookingForm.aadhaarNumber || "-"],
                ["Email", applicantEmail],
              ].map(([label, value]) => (
                <div className="ubf-confirm-fact" key={label}>
                  <span>{label}</span>
                  <strong>{value}</strong>
                </div>
              ))}
              <button type="button" className="ubf-section-menu" aria-label="Applicant actions">
                <FaEllipsisV />
              </button>
            </div>
          </>
        )}

        {renderConfirmSection(
          "Hold/Book Unit",
          <div className="ubf-confirm-form-grid">
            {renderConfirmField({
              label: "Select Booking Stage *",
              name: "bookingStage",
              type: "select",
              value: bookingForm.bookingStage || "Tentative",
              options: ["Tentative", "Confirmed"],
            })}
            {renderConfirmField({
              label: "Select Project Unit Status *",
              name: "projectUnitStatus",
              type: "select",
              value: bookingForm.projectUnitStatus || "Booked",
              options: ["Booked", "Hold", "Available"],
            })}
          </div>
        )}

        {renderConfirmSection(
          "Campaign Info",
          <div className="ubf-confirm-form-grid">
            {renderConfirmField({
              label: "Campaign",
              name: "campaign",
              type: "select",
              value: bookingForm.campaign || "walkin",  
              options: ["walkin", "Site Visit", "Digital"],
            })}
            <label className="ubf-confirm-field">
              <span>Source</span>
              <select
                value={normalizeBookingSource(bookingForm.source)}
                onChange={(event) => {
                  const source = normalizeBookingSource(event.target.value);
                  updateField("source", source);
                  if (!isChannelPartnerSource(source)) {
                    updateField("channelPartnerId", "");
                    updateField("channelPartner", "");
                  }
                }}
              >
                {[...sourceOptions, !sourceOptions.includes(normalizeBookingSource(bookingForm.source)) ? normalizeBookingSource(bookingForm.source) : ""].filter(Boolean).map((option, index) => (
                  <option key={`${option}-${index}`} value={option}>{option}</option>
                ))}
              </select>
            </label>
            <label className="ubf-confirm-field">
              <span>Channel Partner</span>
              <select
                value={bookingForm.channelPartnerId || ""}
                onChange={(event) => {
                  const selected = channelPartners.find((user) => String(user.id) === event.target.value);
                  updateField("channelPartnerId", event.target.value);
                  updateField("channelPartner", selected ? getUserName(selected) : "");
                  if (selected) {
                    const rera = selected.reraNumber || selected.cpReraNumber || selected.rera || selected.reraNo || "";
                    updateField("cpReraNumber", rera);
                  }
                }}
                disabled={!isChannelPartnerSource(bookingForm.source)}
              >
                <option value="">Select Channel Partner</option>
                {channelPartners.map((user) => (
                  <option key={user.id} value={user.id}>{getUserName(user)}</option>
                ))}
              </select>
            </label>
            {isChannelPartnerSource(bookingForm.source) && (
              <label className="ubf-confirm-field">
                <span>CP RERA Number</span>
                <input
                  type="text"
                  placeholder="e.g. P52100012345"
                  value={bookingForm.cpReraNumber || ""}
                  onChange={(event) => updateField("cpReraNumber", event.target.value)}
                />
              </label>
            )}
          </div>,
          "campaign"
        )}

        <div className="ubf-price-summary-card" style={{ background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: "10px", padding: "18px", marginTop: "16px", boxShadow: "0 2px 8px rgba(15,23,42,0.04)" }}>
          <h6 style={{ margin: "0 0 14px", fontSize: "16px", fontWeight: "700", color: "#0f172a" }}>PRICE SUMMARY</h6>
          <div style={{ display: "flex", flexDirection: "column", gap: "10px", fontSize: "13.5px", color: "#334155" }}>
            <div style={{ display: "flex", justifyContent: "space-between" }}><span>Base Rate ({confirmCurrency(closingBaseRateValue)}/sq.ft)</span><strong>{confirmCurrency(closingBaseRateValue * reraAreaValue)}</strong></div>
            <div style={{ display: "flex", justifyContent: "space-between" }}><span>Floor Rise ({confirmCurrency(floorRiseRateValue)} × {floorRiseStepsValue} steps/sq.ft)</span><strong>{confirmCurrency(floorRiseValue)}</strong></div>
            <div style={{ display: "flex", justifyContent: "space-between" }}><span>Effective Rate ({confirmCurrency(effectiveRate)}/sq.ft)</span><strong>{confirmCurrency(effectiveRate * reraAreaValue)}</strong></div>
            <div style={{ display: "flex", justifyContent: "space-between", borderTop: "1px solid #e2e8f0", paddingTop: "10px", fontWeight: "700", fontSize: "15px", color: "#0f172a" }}>
              <span>Agreement Value</span>
              <strong>{confirmCurrency(agreementValue)}</strong>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", fontWeight: "700", fontSize: "16px", color: "#1e40af" }}>
              <span>Final Sold Price</span>
              <strong>{confirmCurrency(allInclusiveValue || agreementValue)}</strong>
            </div>
            {isChannelPartnerSource(bookingForm.source) && (
              <div style={{ display: "flex", justifyContent: "space-between", color: "#2563eb", borderTop: "1px dashed #cbd5e1", paddingTop: "8px", fontSize: "13px", fontWeight: "600" }}>
                <span>Estimated CP Brokerage (2%)</span>
                <strong>{confirmCurrency((agreementValue * 2) / 100)}</strong>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  const getBookingDocumentData = () => {
    const bookingReference = bookingForm.bookingName || quotationName || `BKG-${bookingForm.id || Date.now()}`;
    const customerName = bookingForm.customerName || leadName || "-";
    const projectName = bookingForm.projectDetails || selectedUnit.projectName || "-";
    const towerName = selectedTowerName || selectedUnit.towerName || "-";
    const unitName = bookingForm.unit || selectedUnit.name || "-";
    const bookingDate = bookingForm.bookedOn || bookingForm.bookingDate || new Date().toLocaleDateString("en-IN");
    const finalPrice = bookingForm.soldPrice || bookingForm.totalPrice || bookingForm.basePrice || allInclusiveValue || "";
    const rows = [
      ["Booking Reference", bookingReference],
      ["Customer", customerName],
      ["Project", projectName],
      ["Tower", towerName],
      ["Unit", unitName],
      ["Floor", selectedUnit.floor || "-"],
      ["Booking Date", bookingDate],
      ["Saleable Area", bookingForm.saleableArea || selectedUnit.saleable || "-"],
      ["Carpet Area", bookingForm.carpetArea || selectedUnit.carpet || "-"],
      ["Base Rate", bookingForm.baseRate || selectedUnit.baseRate || "-"],
      ["Closing Base Rate", bookingForm.closingBaseRate || selectedUnit.closingBaseRate || bookingForm.baseRate || selectedUnit.baseRate || "-"],
      ["Agreement Value", bookingForm.agreementValue ? confirmCurrency(bookingForm.agreementValue) : "-"],
      ["Final Sold Price", finalPrice ? confirmCurrency(finalPrice) : "-"],
    ];

    return { bookingReference, customerName, projectName, towerName, unitName, bookingDate, finalPrice, rows };
  };

  const getBookingDocumentHtml = () => {
    const { bookingReference, customerName, projectName, unitName, bookingDate, rows } = getBookingDocumentData();

    return `<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Booking Confirmation</title>
  <style>
    body { color: #172033; font-family: Arial, sans-serif; margin: 0; background: #f6f8fc; }
    .page { background: #fff; margin: 24px auto; max-width: 860px; padding: 52px 56px; }
    .top { align-items: flex-start; display: flex; justify-content: space-between; gap: 24px; }
    .brand { color: #1d2a57; font-size: 34px; font-weight: 900; letter-spacing: .02em; }
    .sub { color: #64748b; font-size: 12px; letter-spacing: .12em; margin-top: 8px; text-transform: uppercase; }
    .ref { color: #0f172a; font-size: 14px; line-height: 1.7; text-align: right; }
    .ref strong { display: block; font-size: 18px; }
    .rule { background: #2458e6; height: 3px; margin: 28px 0 34px; }
    h1 { border-left: 4px solid #2458e6; color: #0f172a; font-size: 26px; margin: 0 0 24px; padding-left: 16px; text-transform: uppercase; }
    .hero { background: #dbeafe; border: 1px solid #a9c7ff; border-radius: 8px; color: #2563eb; margin-bottom: 28px; padding: 24px; text-align: center; }
    .hero strong { display: block; font-size: 28px; margin-bottom: 10px; }
    p { color: #1f2a44; font-size: 15px; line-height: 1.7; margin: 0 0 20px; }
    table { border-collapse: collapse; margin: 24px 0; width: 100%; }
    td { border: 1px solid #d7dde7; padding: 12px 14px; }
    td:first-child { background: #f4f7fb; color: #526070; font-weight: 700; width: 34%; }
    .signature { margin-top: 42px; }
    .signature strong { display: block; margin-top: 42px; }
  </style>
</head>
<body>
  <main class="page">
    <section class="top">
      <div>
        <div class="brand">SWAMI</div>
        <div class="sub">Premium Real Estate CRM · Sales Division</div>
      </div>
      <div class="ref"><strong>${escapeHtml(bookingReference)}</strong>Date: ${escapeHtml(bookingDate)}</div>
    </section>
    <div class="rule"></div>
    <h1>Booking Confirmation Letter</h1>
    <div class="hero"><strong>Your Booking is Confirmed!</strong>Unit selected · Pricing confirmed · Booking recorded</div>
    <p>Dear <strong>${escapeHtml(customerName)}</strong>,</p>
    <p>We are pleased to confirm your booking for unit <strong>${escapeHtml(unitName)}</strong> at <strong>${escapeHtml(projectName)}</strong>. This document records the booking details captured in SWAMI CRM.</p>
    <table>${rows.map(([label, value]) => `<tr><td>${escapeHtml(label)}</td><td>${escapeHtml(value)}</td></tr>`).join("")}</table>
    <p>Please keep this booking confirmation for your records. The project team will coordinate the next documentation and payment steps as per the agreed booking terms.</p>
    <div class="signature">
      <span>For SWAMI Real Estate CRM</span>
      <strong>Authorized Signatory</strong>
      <span>Sales Team</span>
    </div>
  </main>
</body>
</html>`;
  };

  const escapePdfText = (value) => String(value ?? "-").replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");

  const getBookingPdfBlob = () => {
    const { bookingReference, customerName, projectName, unitName, bookingDate, rows } = getBookingDocumentData();
    const detailLines = rows.map(([label, value]) => `${label}: ${value}`);
    const bodyLines = [
      `Dear ${customerName},`,
      `Your booking for unit ${unitName} at ${projectName} is confirmed.`,
      "Please keep this document for your records.",
    ];
    const stream = [];
    const text = (content, x, y, size = 11) => {
      stream.push("BT", `/F1 ${size} Tf`, `${x} ${y} Td`, `(${escapePdfText(content)}) Tj`, "ET");
    };
    const rect = (x, y, width, height, color = "0.96 0.98 1") => {
      stream.push(`${color} rg`, `${x} ${y} ${width} ${height} re f`, "0 0 0 rg");
    };
    rect(0, 0, 595, 842, "1 1 1");
    text("SWAMI", 58, 748, 28);
    text("PREMIUM REAL ESTATE CRM - SALES DIVISION", 58, 728, 9);
    text(bookingReference, 420, 748, 13);
    text(`Date: ${bookingDate}`, 420, 728, 10);
    rect(58, 704, 480, 3, "0.14 0.35 0.9");
    text("BOOKING CONFIRMATION LETTER", 74, 662, 20);
    rect(58, 592, 480, 58, "0.86 0.93 1");
    text("Your Booking is Confirmed!", 170, 626, 20);
    text("Unit selected - Pricing confirmed - Booking recorded", 150, 606, 10);
    bodyLines.forEach((line, index) => text(line, 58, 560 - index * 18, 11));
    let y = 482;
    detailLines.forEach((line, index) => {
      if (index % 2 === 0) rect(58, y - 7, 480, 22, "0.96 0.98 1");
      text(line, 72, y, 10);
      y -= 26;
    });
    text("For SWAMI Real Estate CRM", 58, 128, 11);
    text("Authorized Signatory", 58, 86, 12);
    text("Sales Team", 58, 70, 9);
    const content = [
      "q",
      ...stream,
      "Q",
    ].join("\n");
    const objects = [
      "<< /Type /Catalog /Pages 2 0 R >>",
      "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
      "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
      "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
      `<< /Length ${content.length} >>\nstream\n${content}\nendstream`,
    ];
    let pdf = "%PDF-1.4\n";
    const offsets = [0];
    objects.forEach((object, index) => {
      offsets.push(pdf.length);
      pdf += `${index + 1} 0 obj\n${object}\nendobj\n`;
    });
    const xrefOffset = pdf.length;
    pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
    offsets.slice(1).forEach((offset) => {
      pdf += `${String(offset).padStart(10, "0")} 00000 n \n`;
    });
    pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
    return new Blob([pdf], { type: "application/pdf" });
  };

  const downloadBookingPdf = () => {
    setCompletionActionMessage("");
    const blob = getBookingPdfBlob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `booking-${bookingForm.unit || selectedUnit.name || Date.now()}.pdf`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  const printBooking = () => {
    setCompletionActionMessage("");
    const printWindow = window.open("", "_blank", "noopener,noreferrer");
    if (!printWindow) return;
    printWindow.document.write(getBookingDocumentHtml());
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  };

  const showDeferredAction = (channel) => {
    setCompletionActionMessage(`${channel} API will be connected later.`);
  };

  const renderSuccess = () => (
    <div className="ubf-success">
      <div className="ubf-success-illustration">
        <FaCheckCircle />
      </div>
      <h3>Booking Completed</h3>
      <p>Booking Confirmed Successfully</p>
      <div className="sales-sold-price-card">
        <span className="sales-sold-price-label">Final Sold Price</span>
        <strong className="sales-sold-price-value">
          {confirmCurrency(bookingForm.soldPrice || bookingForm.totalPrice || allInclusiveValue)}
        </strong>
        <small>
          Agreement Value: {confirmCurrency(bookingForm.agreementValue || agreementValue)}
        </small>
      </div>
      <div className="ubf-success-actions">
        <button type="button" onClick={downloadBookingPdf}><FaRegFilePdf /> Download Booking PDF</button>
        <button type="button" onClick={printBooking}><FaPrint /> Print Booking</button>
        <button type="button" onClick={() => showDeferredAction("WhatsApp")}><FaWhatsapp /> Send WhatsApp</button>
        <button type="button" onClick={() => showDeferredAction("Email")}><FaEnvelope /> Send Email</button>
        <button type="button" className="primary" onClick={onClose}>Close</button>
      </div>
      {completionActionMessage && <div className="ubf-success-note">{completionActionMessage}</div>}
    </div>
  );

  const stepContent = [
    renderStepOne,
    renderStepTwo,
    renderStepFour,
  ][bookingStepIndex] || renderStepOne;

  return (
    <div className="ubf-backdrop" role="dialog" aria-modal="true" aria-labelledby="ubf-title">
      <form className="ubf-modal" onSubmit={onSubmit}>
        <header className="ubf-header">
          <h2 id="ubf-title">Booking Details</h2>
          <button type="button" className="ubf-close" onClick={onClose} aria-label="Close booking details">
            <FaTimes />
          </button>
        </header>

        {!bookingSuccess && (
          <div className="sales-booking-stepper" aria-label="Booking progress">
            {["01 FILTER PROJECT", "02 SELECT UNIT", "03 BOOKING CONFIRMATION"].map((stepText, index) => {
              const isComplete = index < bookingStepIndex;
              const isActive = index === bookingStepIndex;
              return (
                <div className={`sales-booking-step${isComplete ? " is-complete" : ""}${isActive ? " is-active" : ""}`} key={stepText}>
                  <div className="sales-booking-step-line" />
                  <div className="sales-booking-step-dot">{isComplete ? "✓" : index + 1}</div>
                  <div className="sales-booking-step-label">{stepText}</div>
                </div>
              );
            })}
          </div>
        )}

        {(bookingMessage || bookingProjectMessage) && !bookingSuccess && (
          <div className="ubf-alert">{bookingMessage || bookingProjectMessage}</div>
        )}

        <main className="ubf-body">
          {bookingSuccess ? renderSuccess() : stepContent()}
        </main>

        {!bookingSuccess && (
          <footer className="sales-sticky-booking-footer">
            <div className="sales-booking-footer-lead">
              Booking for <strong>{leadName}</strong>
            </div>
            <div className="ubf-footer-actions" style={{ display: "flex", gap: "10px" }}>
              {bookingStepIndex > 0 ? (
                <button
                  type="button"
                  className="sales-btn secondary"
                  style={{ padding: "8px 18px", borderRadius: "6px", fontWeight: "600" }}
                  onClick={onPrevious}
                >
                  ← Previous
                </button>
              ) : (
                <button
                  type="button"
                  className="sales-btn secondary"
                  style={{ padding: "8px 18px", borderRadius: "6px", fontWeight: "600" }}
                  onClick={onClose}
                >
                  Cancel
                </button>
              )}
              <button
                type="submit"
                className="sales-btn primary"
                style={{ padding: "8px 22px", borderRadius: "6px", fontWeight: "600", backgroundColor: "#2563eb", color: "#fff", border: "none" }}
                disabled={isSubmitDisabled}
              >
                {bookingStepIndex === 0 ? "Next →" : bookingStepIndex === 1 ? "Next →" : "Confirm Booking"}
              </button>
            </div>
          </footer>
        )}
      </form>
    </div>
  );
};

export default UserBookingForm;
