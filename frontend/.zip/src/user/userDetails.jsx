import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  FaArrowLeft,
  FaCalendarAlt,
  FaCheckCircle,
  FaClock,
  FaCommentAlt,
  FaExchangeAlt,
  FaEdit,
  FaEllipsisV,
  FaEnvelope,
  FaHistory,
  FaLock,
  FaMapMarkerAlt,
  FaPhoneAlt,
  FaPlus,
  FaRegStickyNote,
  FaSave,
  FaStar,
  FaTimes,
  FaTrash,
  FaUserTie,
  FaWhatsapp,
} from "react-icons/fa";
import {
  getLeadFollowupContext,
  markFollowupDone,
  rescheduleFollowup,
  updateLeadStatus as updateSalesLeadStatus,
} from "../services/followupApi";
import {
  dedupeActivityNotifications,
  getActivityNotificationDedupeKey,
} from "../utils/activityNotifications";

const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000";

const crmStatuses = [
  "New",
  "Qualified",
  "In sourcing",
  "In closing",
  "Nurture",
  "Booked",
  "Unqualified",
];

const backendStatusMap = {
  All: "New",
  New: "New",
  Qualified: "Qualified",
  "In sourcing": "In_sourcing",
  "In closing": "In_closing",
  Booked: "Booked",
  Nurture: "Nurture",
  Unqualified: "Unqualified",
  "Image pending": "Image_pending",
  "Image received": "Image_received",
  "Image shared": "Image_shared",
};

const tabs = [
  "Activity",
  "Notes",
  "Calls",
  "Site Visits",
  "Follow-ups",
  "Emails",
  "SMS",
  "WhatsApp",
  "History",
];

const fallbackLead = {
  id: 10702,
  firstName: "Chetan",
  lastName: "Agrawal",
  status: "New",
  source: "channel_partner",
  interestedProjects: "Binghatti Hills",
  tags: "channel_partner",
};

const getStoredLead = () => {
  try {
    return (
      JSON.parse(window.sessionStorage.getItem("selectedLeadDetails") || "null") ||
      JSON.parse(window.sessionStorage.getItem("selectedLeadPreview") || "null")
    );
  } catch {
    return null;
  }
};

const getCurrentUserName = () => {
  try {
    const user = JSON.parse(localStorage.getItem("authUser") || "null");
    return (
      [user?.firstName, user?.lastName].filter(Boolean).join(" ") ||
      user?.username ||
      user?.email ||
      "User"
    );
  } catch {
    return "User";
  }
};

const getCurrentUserRole = () => {
  try {
    const user = JSON.parse(localStorage.getItem("authUser") || "null");
    return String(user?.role || "").trim().toUpperCase();
  } catch {
    return "";
  }
};

const salesRoles = new Set(["SALES", "PRE_SALES", "POST_SALES"]);

const getLeadId = (lead) => lead?.id || lead?._id || lead?.lead_id || "";

const getLeadName = (lead) =>
  [lead?.firstName, lead?.lastName].filter(Boolean).join(" ") ||
  lead?.name ||
  lead?.full_name ||
  lead?.customer_name ||
  lead?.companyName ||
  (getLeadId(lead) ? `Lead #${getLeadId(lead)}` : "Lead");

const getContactValue = (value, keys = ["value", "email", "phone", "number"]) => {
  if (!value) return "";
  if (typeof value === "string") return value;
  if (Array.isArray(value)) {
    for (const item of value) {
      const result = getContactValue(item, keys);
      if (result) return result;
    }
    return "";
  }
  if (typeof value === "object") {
    for (const key of keys) {
      if (value[key]) return value[key];
    }
  }
  return "";
};

const displayValue = (value, fallback = "-") => {
  if (value === undefined || value === null || value === "") return fallback;
  if (typeof value === "string" || typeof value === "number") return String(value);
  if (Array.isArray(value)) return value.map((item) => displayValue(item, "")).find(Boolean) || fallback;
  if (typeof value === "object") {
    return (
      value.name ||
      value.unitName ||
      value.unitNo ||
      value.number ||
      value.label ||
      value.title ||
      value.project?.name ||
      value.description ||
      value.type ||
      value.category ||
      (value.id ? `#${value.id}` : fallback)
    );
  }
  return fallback;
};

const valueOf = (lead, keys, fallback = "-") => {
  for (const key of keys) {
    const value = lead?.[key];
    if (value !== undefined && value !== null && value !== "") return displayValue(value, fallback);
  }
  return fallback;
};

const toDate = (value) => {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

const formatDateTime = (value, fallback = "-") => {
  const date = toDate(value);
  if (!date) return fallback;
  return date.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
};

const formatDateOnly = (value, fallback = "-") => {
  const date = toDate(value);
  if (!date) return fallback;
  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

const normalizeApiFollowup = (item) => ({
  ...item,
  title: item.notes || `${item.type || "Call"} follow-up`,
  dueAt: item.followUpDate && item.followUpTime
    ? `${String(item.followUpDate).slice(0, 10)}T${item.followUpTime}`
    : item.followUpDate,
  status: item.effectiveStatus || item.status || "Pending",
});

const formatMoney = (value) => {
  const amount = Number(value);
  if (!Number.isFinite(amount) || amount <= 0) return "-";
  return new Intl.NumberFormat("en-IN", {
    currency: "INR",
    maximumFractionDigits: 0,
    style: "currency",
  }).format(amount);
};

const formatNumber = (value, fallback = "-") => {
  if (value === undefined || value === null || value === "") return fallback;
  const amount = Number(String(value ?? "").replace(/[^\d.-]/g, ""));
  if (!Number.isFinite(amount)) return fallback;
  return amount.toLocaleString("en-IN");
};


const formatArea = (value) => {
  const formatted = formatNumber(value);
  return formatted === "-" ? "-" : `${formatted} sq_ft`;
};

const formatCompactMoney = (value) => {
  const amount = Number(String(value ?? "").replace(/[^\d.-]/g, ""));
  if (!Number.isFinite(amount) || amount <= 0) return "-";
  if (amount >= 10000000) {
    return `₹ ${(amount / 10000000).toFixed(1).replace(/\.0$/, "")}Cr (${amount.toLocaleString("en-IN")})`;
  }
  if (amount >= 100000) {
    return `₹ ${(amount / 100000).toFixed(1).replace(/\.0$/, "")}L (${amount.toLocaleString("en-IN")})`;
  }
  return formatMoney(amount);
};

const normalizeText = (value) => String(value || "").toLowerCase();

const isActivityForTab = (activity, tab) => {
  if (!activity) return false;
  if (tab === "Activity") return true;

  const type = normalizeText(activity.type || "");
  const title = normalizeText(activity.title || "");
  const desc = normalizeText(activity.description || "");

  switch (tab) {
    case "Notes":
      return activity.type === "Notes" || type.includes("note") || title.includes("note");
    case "Calls":
      return (
        activity.type === "Calls" ||
        type.includes("call") ||
        title.includes("call") ||
        type.includes("mcube") ||
        desc.includes("call")
      );
    case "Site Visits":
      return activity.type === "Site Visits" || type.includes("visit") || title.includes("visit");
    case "Follow-ups":
      return activity.type === "Follow-ups" || type.includes("follow") || title.includes("follow");
    case "Emails":
      return activity.type === "Emails" || type.includes("email") || title.includes("email") || type.includes("mail");
    case "SMS":
      return activity.type === "SMS" || type.includes("sms") || title.includes("sms");
    case "WhatsApp":
      return activity.type === "WhatsApp" || type.includes("whatsapp") || title.includes("whatsapp");
    case "History":
      return (
        activity.type === "History" ||
        type.includes("status") ||
        title.includes("status") ||
        type.includes("created") ||
        title.includes("created") ||
        type.includes("booking") ||
        title.includes("booking") ||
        type.includes("stage") ||
        type.includes("assign")
      );
    default:
      return activity.type === tab;
  }
};

const getCrmStatusFromLead = (lead) => {
  const rawStatus = String(valueOf(lead, ["crmStatus", "status", "lead_status", "stage"], "New"));
  if (crmStatuses.includes(rawStatus)) return rawStatus;
  if (rawStatus === "In_sourcing") return "In sourcing";
  if (rawStatus === "In_closing") return "In closing";
  if (rawStatus === "Image_pending") return "Image pending";
  if (rawStatus === "Image_received") return "Image received";
  if (rawStatus === "Image_shared") return "Image shared";
  if (rawStatus === "Nurture" || rawStatus === "Follow-up") return "Qualified";
  if (rawStatus === "Lost" || rawStatus === "Junk") return "Unqualified";
  if (rawStatus === "Fresh_Lead" || rawStatus === "Prospect") return "New";
  if (rawStatus === "Registered") return "In closing";
  return "New";
};

const getStatusScore = (status) => {
  const statusScores = {
    All: 0,
    New: 15,
    Qualified: 35,
    "In sourcing": 55,
    "In closing": 75,
    Booked: 100,
    Unqualified: 0,
  };

  return statusScores[status] ?? 0;
};


const getOwnerName = (lead) => {
  const team = lead?.team;
  return (
    valueOf(lead, ["owner", "assigned_to", "sales"], "") ||
    [team?.firstName, team?.lastName].filter(Boolean).join(" ") ||
    team?.username ||
    team?.email ||
    "Unassigned"
  );
};



const getActivityDay = (value) => {
  const date = toDate(value);
  if (!date) return "Older";
  const today = new Date();
  const startToday = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
  const startDate = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  const diff = Math.round((startToday - startDate) / 86400000);
  if (diff === 0) return "Today";
  if (diff === 1) return "Yesterday";
  return formatDateOnly(date);
};

const getStoredActivityNotifications = () => {
  return [];
};

const saveActivityNotifications = () => {
  window.dispatchEvent(new Event("crmActivityNotificationsChanged"));
};

const publishSalesActivityNotification = ({
  id,
  leadId,
  leadName,
  title,
  description,
  meta,
  type,
  createdAt = new Date().toISOString(),
  syncToServer = true,
}) => {
  if (!leadId || !salesRoles.has(getCurrentUserRole())) return;

  const actorName = getCurrentUserName();
  const token = localStorage.getItem("authToken");
  const notification = {
    id: id || `${leadId}-${type || "Activity"}-${createdAt}-${Math.random().toString(36).slice(2, 8)}`,
    leadId,
    leadName,
    title,
    description,
    meta: meta || `Done by ${actorName}`,
    type: type || "Activity",
    actorName,
    actorRole: getCurrentUserRole(),
    createdAt,
  };
  const notifications = [
    notification,
    ...getStoredActivityNotifications().filter(
      (item) =>
        item.id !== notification.id &&
        getActivityNotificationDedupeKey(item) !== getActivityNotificationDedupeKey(notification)
    ),
  ]
    .sort((first, second) => {
      const firstTime = toDate(first.createdAt)?.getTime() || 0;
      const secondTime = toDate(second.createdAt)?.getTime() || 0;
      return secondTime - firstTime;
    })
    .slice(0, 100);

  saveActivityNotifications(notifications);

  if (token && syncToServer) {
    fetch(`${API_URL}/lead-activities`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        leadId: Number(leadId),
        type: title || type || "Activity",
        title,
        description,
        message: description,
      }),
    }).catch((error) => {
      console.error("Unable to publish admin notification:", error);
    });
  }
};

const UserDetails = ({
  context = "auto",
  embedded = false,
  onOpenCallLead,
  onOpenWhatsAppLead,
  onScheduleVisitLead,
}) => {
  const location = useLocation();
  const navigate = useNavigate();
  const noteInputRef = useRef(null);
  const token = localStorage.getItem("authToken");
  const leadIdFromUrl = useMemo(
    () => new URLSearchParams(location.search).get("leadId"),
    [location.search]
  );

  const initialLead = useMemo(() => {
    if (location.state?.lead && (!leadIdFromUrl || String(getLeadId(location.state.lead)) === String(leadIdFromUrl))) {
      return location.state.lead;
    }
    const stored = getStoredLead();
    if (stored && (!leadIdFromUrl || String(getLeadId(stored)) === String(leadIdFromUrl))) {
      return stored;
    }
    if (leadIdFromUrl) {
      return { id: Number(leadIdFromUrl) || leadIdFromUrl };
    }
    return fallbackLead;
  }, [leadIdFromUrl, location.state]);

  const [lead, setLead] = useState(initialLead);
  const [notes, setNotes] = useState([]);
  const [backendActivities, setBackendActivities] = useState([]);
  const [calls, setCalls] = useState([]);
  const [visits, setVisits] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [activeTab, setActiveTab] = useState("Activity");
  const [selectedStatus, setSelectedStatus] = useState(getCrmStatusFromLead(lead));
  const [statusMessage, setStatusMessage] = useState("");
  const [noteDraft, setNoteDraft] = useState("");
  const [editingNoteId, setEditingNoteId] = useState(null);
  const [isSavingNote, setIsSavingNote] = useState(false);
  const [isSavingStatus, setIsSavingStatus] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [followups, setFollowups] = useState([]);
  const [emails, setEmails] = useState([]);
  const [whatsappMessages, setWhatsappMessages] = useState([]);
  const [activityPage, setActivityPage] = useState(1);
  const ACTIVITY_PAGE_SIZE = 10;

  const leadId = leadIdFromUrl || getLeadId(lead);

  useEffect(() => {
    if (leadIdFromUrl && String(getLeadId(lead)) !== String(leadIdFromUrl)) {
      setLead({ id: Number(leadIdFromUrl) || leadIdFromUrl });
      setNotes([]);
      setBackendActivities([]);
      setCalls([]);
      setVisits([]);
      setBookings([]);
      setFollowups([]);
      setEmails([]);
      setWhatsappMessages([]);
      setSelectedStatus("New");
    }
  }, [leadIdFromUrl]);
  const leadName = getLeadName(lead);
  const primaryPhone =
    getContactValue(lead?.phones, ["phone", "number", "value"]) ||
    valueOf(lead, ["phone", "mobile", "primaryPhone"], "");
  const primaryEmail =
    getContactValue(lead?.emails, ["email", "value"]) ||
    valueOf(lead, ["email", "primaryEmail"], "");
  const projectInterest = valueOf(
    lead,
    ["interestedProjects", "projectName", "project_name", "siteVisitProject", "propertyType"],
    "-"
  );
  const source = valueOf(lead, ["source", "channelPartner", "tags"], "-");
  const owner = getOwnerName(lead);
  const persistedLeadStatus = getCrmStatusFromLead(lead);
  const currentStatus = selectedStatus || persistedLeadStatus;
  const isBookedStatusLocked = persistedLeadStatus === "Booked";
  const isBookedSelectedBeforeBooking = !isBookedStatusLocked && selectedStatus === "Booked";
  const leadScoreNumber = getStatusScore(currentStatus);
  const createdDate = valueOf(lead, ["createdAt", "created_at", "received_on"], "");
  const isSalesContext =
    context === "sales" || (context !== "admin" && location.pathname.startsWith("/user/sales"));
  const isAdminContext = context === "admin" || !isSalesContext;
  const detailsBackPath = isAdminContext ? "/leads" : "/user/sales";
  const statusOptions = crmStatuses;
  const stageStatusValue = statusOptions.includes(selectedStatus) ? selectedStatus : "";
  const authHeaders = useMemo(() => token ? { Authorization: `Bearer ${token}` } : {}, [token]);

  const openSalesCallPage = () => {
    if (onOpenCallLead) {
      onOpenCallLead(lead);
      return;
    }

    navigate(`/user/sales/calls${leadId ? `?leadId=${leadId}` : ""}`, {
      state: { lead },
    });
  };

  const openSalesWhatsAppPage = () => {
    if (onOpenWhatsAppLead) {
      onOpenWhatsAppLead(lead);
      return;
    }

    navigate(`/user/sales/whatsapp${leadId ? `?leadId=${leadId}` : ""}`, {
      state: { lead },
    });
  };

  const openSalesFollowupPage = () => {
    if (isAdminContext) {
      navigate(`/follow-up${leadId ? `?leadId=${leadId}` : ""}`, {
        state: { lead },
      });
      return;
    }

    navigate(`/user/sales/followups${leadId ? `?leadId=${leadId}` : ""}`, {
      state: { lead },
    });
  };

  const openSalesSiteVisitPage = (status = "") => {
    if (onScheduleVisitLead) {
      onScheduleVisitLead(lead, status);
      return;
    }

    const params = new URLSearchParams();
    if (leadId) params.set("leadId", leadId);
    if (status) params.set("status", status);
    navigate(`/user/sales/site-visit${params.toString() ? `?${params.toString()}` : ""}`, {
      state: { lead, status },
    });
  };

  const fetchLead = useCallback(async () => {
    const nextLeadId = leadIdFromUrl || leadId;
    if (!nextLeadId) return;

    try {
      const response = await fetch(`${API_URL}/leads/${nextLeadId}`);
      if (!response.ok) return;
      const result = await response.json();
      setLead(result);
      setSelectedStatus(getCrmStatusFromLead(result));
      window.sessionStorage.setItem("selectedLeadDetails", JSON.stringify(result));
    } catch (error) {
      console.error("Unable to load lead details:", error);
    }
  }, [leadId, leadIdFromUrl]);

  const fetchNotes = useCallback(async () => {
    if (!leadId) {
      setNotes([]);
      return;
    }
    try {
      const response = await fetch(`${API_URL}/lead-notes/${leadId}`, {
        headers: authHeaders,
      });
      if (!response.ok) return;
      const result = await response.json();
      const rows = (Array.isArray(result) ? result : []).filter(
        (note) => !note.leadId || String(note.leadId) === String(leadId)
      );
      setNotes(rows);
    } catch (error) {
      console.error("Unable to load notes:", error);
    }
  }, [authHeaders, leadId]);

  const fetchLeadActivities = useCallback(async () => {
    if (!leadId || !token) {
      setBackendActivities([]);
      return;
    }

    try {
      const response = await fetch(`${API_URL}/lead-activities?leadId=${encodeURIComponent(leadId)}&limit=100`, {
        headers: authHeaders,
      });
      if (!response.ok) return;
      const result = await response.json();
      const rows = (Array.isArray(result) ? result : []).filter(
        (activity) => String(activity.leadId) === String(leadId)
      );
      setBackendActivities(rows);
    } catch (error) {
      console.error("Unable to load lead activities:", error);
    }
  }, [authHeaders, leadId, token]);

  const fetchCalls = useCallback(async () => {
    if (!leadId || !token) {
      setCalls([]);
      return;
    }
    try {
      const response = await fetch(`${API_URL}/calls/lead/${leadId}?limit=100`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!response.ok) return;
      const result = await response.json();
      const rows = (Array.isArray(result?.data) ? result.data : []).filter(
        (call) => !call.leadId || String(call.leadId) === String(leadId)
      );
      setCalls(rows);
    } catch (error) {
      console.error("Unable to load calls:", error);
    }
  }, [leadId, token]);

  const fetchVisits = useCallback(async () => {
    if (!leadId) {
      setVisits([]);
      return;
    }
    try {
      const response = await fetch(`${API_URL}/schedule-visits`);
      if (!response.ok) return;
      const result = await response.json();
      const rows = (Array.isArray(result) ? result : result?.data || []).filter(
        (visit) => String(visit.leadId || visit.lead?.id) === String(leadId)
      );
      setVisits(rows);
    } catch (error) {
      console.error("Unable to load site visits:", error);
    }
  }, [leadId]);

  const fetchBookings = useCallback(async () => {
    if (!leadId) {
      setBookings([]);
      return;
    }
    try {
      const response = await fetch(`${API_URL}/bookings?leadId=${leadId}&limit=100`);
      if (!response.ok) return;
      const result = await response.json();
      const rows = (Array.isArray(result) ? result : result?.data || []).filter(
        (booking) => !booking.leadId || String(booking.leadId) === String(leadId)
      );
      setBookings(rows);
    } catch (error) {
      console.error("Unable to load bookings:", error);
    }
  }, [leadId]);

  const fetchFollowups = useCallback(async () => {
    if (!leadId) {
      setFollowups([]);
      return;
    }

    try {
      const result = await getLeadFollowupContext(leadId);
      const rows = (result?.followUps || [])
        .filter((f) => (!f.leadId && !f.lead_id ? true : String(f.leadId || f.lead_id) === String(leadId)))
        .map(normalizeApiFollowup);
      setFollowups(rows);
    } catch (error) {
      console.error("Unable to load follow-ups:", error);
      setFollowups([]);
    }
  }, [leadId]);

  const fetchEmails = useCallback(async () => {
    if (!leadId) {
      setEmails([]);
      return;
    }
    try {
      const response = await fetch(`${API_URL}/api/email/logs`, { headers: authHeaders });
      if (!response.ok) return;
      const result = await response.json();
      const logs = (Array.isArray(result?.data) ? result.data : []).filter(
        (item) => String(item.leadId) === String(leadId)
      );
      setEmails(logs);
    } catch (error) {
      console.error("Unable to load emails:", error);
    }
  }, [authHeaders, leadId]);

  const fetchWhatsapp = useCallback(async () => {
    if (!leadId || !token) {
      setWhatsappMessages([]);
      return;
    }
    try {
      const response = await fetch(`${API_URL}/api/whatsapp/lead/${leadId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!response.ok) return;
      const result = await response.json();
      const rows = (Array.isArray(result?.data) ? result.data : Array.isArray(result) ? result : []).filter(
        (wa) => !wa.leadId || String(wa.leadId) === String(leadId)
      );
      setWhatsappMessages(rows);
    } catch (error) {
      console.error("Unable to load WhatsApp messages:", error);
    }
  }, [leadId, token]);

  useEffect(() => {
    fetchLead();
  }, [fetchLead]);

  useEffect(() => {
    fetchNotes();
    fetchLeadActivities();
    fetchCalls();
    fetchVisits();
    fetchBookings();
    fetchFollowups();
    fetchEmails();
    fetchWhatsapp();
  }, [fetchBookings, fetchCalls, fetchEmails, fetchFollowups, fetchLeadActivities, fetchNotes, fetchVisits, fetchWhatsapp]);

  const saveStatus = async (status) => {
    if (!leadId) return false;
    if (status === "Booked") {
      setStatusMessage("Use Book Unit to mark a lead as Booked after booking confirmation.");
      return false;
    }
    if (isBookedStatusLocked && status !== "Booked") {
      setStatusMessage("Booked lead status cannot be changed.");
      return false;
    }
    setIsSavingStatus(true);
    setStatusMessage("");
    const backendStatus = backendStatusMap[status] || String(status || "New").replace(/\s+/g, "_");
    const nextScore = getStatusScore(status);

    try {
      const result = await updateSalesLeadStatus(leadId, { status: backendStatus, score: nextScore });

      const updatedLead = { ...lead, ...result, status, crmStatus: status, score: nextScore };
      setLead(updatedLead);
      setSelectedStatus(status);
      window.sessionStorage.setItem("selectedLeadDetails", JSON.stringify(updatedLead));
      setStatusMessage(`Status saved as ${status}`);
      publishSalesActivityNotification({
        leadId,
        leadName,
        title: "Lead Status Updated",
        description: `${leadName} status changed to ${status}`,
        meta: `Done by ${getCurrentUserName()}`,
        type: "History",
      });
      return true;
    } catch (error) {
      console.error("Unable to update lead status:", error);
      setStatusMessage("Status could not be saved.");
      return false;
    } finally {
      setIsSavingStatus(false);
    }
  };

  const handleStatusChange = (nextStatus) => {
    setSelectedStatus(nextStatus);
    setStatusMessage("");
  };

  const reassignLead = async () => {
    if (!leadId) return;
    const nextOwnerId = window.prompt("Enter sales user ID to reassign this lead:");
    if (!nextOwnerId) return;

    const normalizedOwnerId = Number.parseInt(nextOwnerId, 10);
    if (!Number.isFinite(normalizedOwnerId)) {
      alert("Please enter a valid sales user ID.");
      return;
    }

    try {
      const response = await fetch(`${API_URL}/leads/${leadId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ teamId: normalizedOwnerId, leadReassigned: true }),
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result?.message || "Unable to reassign lead");

      const updatedLead = { ...lead, ...result };
      setLead(updatedLead);
      window.sessionStorage.setItem("selectedLeadDetails", JSON.stringify(updatedLead));
      setStatusMessage("Lead reassigned successfully.");
    } catch (error) {
      alert(error.message || "Unable to reassign lead");
    }
  };

  const saveNote = async () => {
    const text = noteDraft.trim();
    if (!text || !leadId) return;

    setIsSavingNote(true);
    try {
      if (editingNoteId) {
        const response = await fetch(`${API_URL}/lead-notes/${editingNoteId}`, {
          method: "PATCH",
          headers: { ...authHeaders, "Content-Type": "application/json" },
          body: JSON.stringify({ note: text }),
        });
        if (!response.ok) throw new Error("Unable to update note");
        const saved = await response.json();
        setNotes((current) =>
          current.map((note) =>
            String(note.id) === String(editingNoteId)
              ? saved
              : note
          )
        );
      } else {
        const response = await fetch(`${API_URL}/lead-notes`, {
          method: "POST",
          headers: { ...authHeaders, "Content-Type": "application/json" },
          body: JSON.stringify({
            leadId: Number(leadId),
            note: text,
            owner: getCurrentUserName(),
          }),
        });
        if (!response.ok) throw new Error("Unable to save note");
        const saved = await response.json();
        setNotes((current) => [{ ...saved, pinned: false }, ...current]);
        fetchLeadActivities();
        publishSalesActivityNotification({
          id: `${leadId}-note-${saved.id || Date.now()}`,
          leadId,
          leadName,
          title: "Note Added",
          description: text,
          meta: `Done by ${getCurrentUserName()}`,
          type: "Notes",
          createdAt: saved.createdAt || new Date().toISOString(),
          syncToServer: false,
        });
      }

      setNoteDraft("");
      setEditingNoteId(null);
      noteInputRef.current?.focus();
    } catch (error) {
      alert(error.message || "Unable to save note");
    } finally {
      setIsSavingNote(false);
    }
  };

  const editNote = (note) => {
    setActiveTab("Notes");
    setEditingNoteId(note.id);
    setNoteDraft(note.note || "");
    setTimeout(() => noteInputRef.current?.focus(), 0);
  };

  const deleteNote = async (note) => {
    if (!window.confirm("Delete this note from this page?")) return;
    const response = await fetch(`${API_URL}/lead-notes/${note.id}`, {
      method: "DELETE",
      headers: authHeaders,
    });
    if (response.ok) setNotes((current) => current.filter((item) => String(item.id) !== String(note.id)));
  };

  const togglePinNote = async (note) => {
    const pinned = !note.pinned;
    const response = await fetch(`${API_URL}/lead-notes/${note.id}`, {
      method: "PATCH",
      headers: { ...authHeaders, "Content-Type": "application/json" },
      body: JSON.stringify({ pinned }),
    });
    if (response.ok) {
      const saved = await response.json();
      setNotes((current) => current.map((item) => (String(item.id) === String(note.id) ? saved : item)));
    }
  };

  const updateFollowupStatus = async (item, status) => {
    try {
      if (status === "Done" || status === "Completed") {
        await markFollowupDone(item.id);
      } else if (status === "Rescheduled") {
        const nextDate = window.prompt("New follow-up date and time (YYYY-MM-DDTHH:mm)", item.dueAt || "");
        if (!nextDate) return;
        const [followUpDate, followUpTime = "09:00"] = nextDate.split("T");
        await rescheduleFollowup(item.id, {
          followUpDate,
          followUpTime,
          notes: item.notes || item.title,
          priority: item.priority || "Medium",
        });
      }
      publishSalesActivityNotification({
        id: `${leadId}-followup-${item.id}-${status}`,
        leadId,
        leadName,
        title: `Follow-up ${status}`,
        description: item.notes || item.title || "Follow-up updated",
        meta: `Done by ${getCurrentUserName()}`,
        type: "Follow-ups",
      });
      fetchFollowups();
    } catch (error) {
      alert(error.message || "Unable to update follow-up");
    }
  };

  const activities = useMemo(() => {
    const noteActivities = notes.map((note) => ({
      id: `note-${note.id}`,
      type: "Notes",
      icon: <FaRegStickyNote />,
      title: note.pinned ? "Pinned Note" : "Note Added",
      description: note.note,
      meta: `Created by ${note.owner || "User"}`,
      createdAt: note.updatedAt || note.createdAt,
      source: note,
    }));

    const callActivities = calls.map((call) => ({
      id: `call-${call.id}`,
      type: "Calls",
      icon: <FaPhoneAlt />,
      title: normalizeText(call.status).includes("connected") || normalizeText(call.status).includes("completed")
        ? "Call Connected"
        : "Call Attempted",
      description: `${call.phone || primaryPhone || "-"}${call.duration ? `, ${call.duration}s` : ""}`,
      meta: call.disposition || call.provider || "Call log",
      createdAt: call.startedAt || call.createdAt,
      source: call,
    }));

    const visitActivities = visits.map((visit) => ({
      id: `visit-${visit.id}`,
      type: "Site Visits",
      icon: <FaMapMarkerAlt />,
      title: `Site Visit ${visit.status || "Scheduled"}`,
      description: displayValue(visit.project || projectInterest),
      meta: visit.meetingPoint || visit.salesExecutive || "Site visit",
      createdAt: visit.scheduledOn || visit.updatedAt || visit.createdAt,
      source: visit,
    }));

    const followupActivities = followups.map((item) => ({
      id: `followup-${item.id}`,
      type: "Follow-ups",
      icon: <FaClock />,
      title: `Follow-up ${item.status || "Scheduled"}`,
      description: item.title,
      meta: formatDateTime(item.dueAt),
      createdAt: item.updatedAt || item.dueAt || item.createdAt,
      source: item,
    }));

    const noteTexts = new Set(notes.map((note) => normalizeText(note.note)));
    const apiActivities = backendActivities
      .filter((activity) => {
        if (activity.leadId && String(activity.leadId) !== String(leadId)) return false;
        if (activity.type === "Note Added" && noteTexts.has(normalizeText(activity.description || activity.message))) return false;
        return true;
      })
      .map((activity) => {
        const rawType = normalizeText(activity.type || "");
        const rawTitle = normalizeText(activity.title || "");
        const rawMsg = normalizeText(activity.description || activity.message || "");
        let tabType = "History";
        let icon = <FaHistory />;

        if (rawType.includes("note") || rawTitle.includes("note")) {
          tabType = "Notes";
          icon = <FaRegStickyNote />;
        } else if (rawType.includes("call") || rawTitle.includes("call") || rawType.includes("mcube") || rawMsg.includes("call")) {
          tabType = "Calls";
          icon = <FaPhoneAlt />;
        } else if (rawType.includes("visit") || rawTitle.includes("visit")) {
          tabType = "Site Visits";
          icon = <FaMapMarkerAlt />;
        } else if (rawType.includes("follow") || rawTitle.includes("follow")) {
          tabType = "Follow-ups";
          icon = <FaClock />;
        } else if (rawType.includes("email") || rawTitle.includes("email") || rawType.includes("mail")) {
          tabType = "Emails";
          icon = <FaEnvelope />;
        } else if (rawType.includes("sms") || rawTitle.includes("sms")) {
          tabType = "SMS";
          icon = <FaCommentAlt />;
        } else if (rawType.includes("whatsapp") || rawTitle.includes("whatsapp")) {
          tabType = "WhatsApp";
          icon = <FaWhatsapp />;
        }

        return {
          id: `backend-${activity.id}`,
          type: tabType,
          icon,
          title: activity.title || activity.type || "Activity",
          description: activity.description || activity.message || "",
          meta: activity.meta || `Done by ${activity.actorName || "Sales User"}`,
          createdAt: activity.createdAt,
          source: activity,
        };
      });

    const emailList = [...emails, ...(lead?.emailLogs || lead?.emails || [])]
      .filter((email) => !email.leadId || String(email.leadId) === String(leadId));
    const emailActivities = emailList.map((email, idx) => ({
      id: `email-${email.id || idx}`,
      type: "Emails",
      icon: <FaEnvelope />,
      title: email.subject || "Email Sent",
      description: email.body || email.message || `Sent to ${email.to || primaryEmail || lead?.email || "-"}`,
      meta: email.status || (email.success ? "Sent successfully" : "Email"),
      createdAt: email.createdAt || email.sentAt,
      source: email,
    }));

    const smsActivities = (lead?.smsLogs || lead?.sms || [])
      .filter((sms) => !sms.leadId || String(sms.leadId) === String(leadId))
      .map((sms, idx) => ({
        id: `sms-${sms.id || idx}`,
        type: "SMS",
        icon: <FaCommentAlt />,
        title: sms.title || "SMS Sent",
        description: sms.text || sms.message || `Sent to ${primaryPhone || "-"}`,
        meta: sms.status || "SMS",
        createdAt: sms.sentAt || sms.createdAt,
        source: sms,
      }));

    const waList = [...whatsappMessages, ...(lead?.whatsappLogs || lead?.whatsappMessages || [])]
      .filter((wa) => !wa.leadId || String(wa.leadId) === String(leadId));
    const whatsappActivities = waList.map((wa, idx) => ({
      id: `wa-${wa.id || idx}`,
      type: "WhatsApp",
      icon: <FaWhatsapp />,
      title: wa.title || "WhatsApp Message",
      description: wa.body || wa.message || wa.text || `Message to ${wa.to || primaryPhone || "-"}`,
      meta: wa.status || (wa.sent ? "Delivered" : "WhatsApp"),
      createdAt: wa.createdAt || wa.sentAt,
      source: wa,
    }));

    const bookingActivities = bookings
      .filter((booking) => !booking.leadId || String(booking.leadId) === String(leadId))
      .map((booking) => ({
        id: `booking-${booking.id}`,
        type: "History",
        icon: <FaCheckCircle />,
        title: "Booking Created",
        description: displayValue(booking.projectDetails || booking.customerName, "Booking"),
        meta: `${formatMoney(booking.basePrice)} ${booking.stage || ""}`.trim(),
        createdAt: booking.bookedOn || booking.createdAt,
        source: booking,
      }));

    const hasStatusInBackend = apiActivities.some(
      (a) => normalizeText(a.type).includes("status") || normalizeText(a.title).includes("status")
    );
    const statusActivity = hasStatusInBackend ? null : {
      id: `status-${leadId}`,
      type: "History",
      icon: <FaHistory />,
      title: "Lead Status",
      description: currentStatus,
      meta: "Current workflow state",
      createdAt: valueOf(lead, ["updatedAt", "createdAt"], new Date().toISOString()),
      source: lead,
    };

    const hasCreatedInBackend = apiActivities.some(
      (a) => normalizeText(a.type).includes("created") || normalizeText(a.title).includes("created")
    );
    const createdActivity = hasCreatedInBackend ? null : {
      id: `created-${leadId}`,
      type: "History",
      icon: <FaPlus />,
      title: "Lead Created",
      description: `${leadName} entered CRM`,
      meta: source,
      createdAt: createdDate || new Date().toISOString(),
      source: lead,
    };

    const sortedActivities = [
      ...noteActivities,
      ...callActivities,
      ...visitActivities,
      ...followupActivities,
      ...apiActivities,
      ...emailActivities,
      ...smsActivities,
      ...whatsappActivities,
      ...bookingActivities,
      ...(statusActivity ? [statusActivity] : []),
      ...(createdActivity ? [createdActivity] : []),
    ].sort((first, second) => {
      const firstTime = toDate(first.createdAt)?.getTime() || 0;
      const secondTime = toDate(second.createdAt)?.getTime() || 0;
      return secondTime - firstTime;
    });

    const seen = new Set();
    return sortedActivities.filter((activity) => {
      const key = [
        activity.type,
        normalizeText(activity.title),
        normalizeText(activity.description),
        toDate(activity.createdAt)?.getTime() || "",
      ].join("|");
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }, [
    backendActivities,
    bookings,
    calls,
    createdDate,
    currentStatus,
    emails,
    followups,
    lead,
    leadId,
    leadName,
    notes,
    primaryEmail,
    primaryPhone,
    projectInterest,
    source,
    visits,
    whatsappMessages,
  ]);

  const filteredActivities = useMemo(() => {
    if (activeTab === "Activity") return activities;
    return activities.filter((activity) => isActivityForTab(activity, activeTab));
  }, [activeTab, activities]);

  const tabCounts = useMemo(() => {
    return tabs.reduce((acc, tab) => {
      acc[tab] = tab === "Activity" ? activities.length : activities.filter((a) => isActivityForTab(a, tab)).length;
      return acc;
    }, {});
  }, [activities]);

  useEffect(() => {
    setActivityPage(1);
  }, [activeTab, leadId]);

  const totalActivityPages = Math.max(1, Math.ceil(filteredActivities.length / ACTIVITY_PAGE_SIZE));
  const currentActivityPage = Math.min(activityPage, totalActivityPages);

  const paginatedActivities = useMemo(() => {
    const startIndex = (currentActivityPage - 1) * ACTIVITY_PAGE_SIZE;
    return filteredActivities.slice(startIndex, startIndex + ACTIVITY_PAGE_SIZE);
  }, [filteredActivities, currentActivityPage]);

  const groupedActivities = useMemo(() => {
    return paginatedActivities.reduce((groups, activity) => {
      const day = getActivityDay(activity.createdAt);
      return { ...groups, [day]: [...(groups[day] || []), activity] };
    }, {});
  }, [paginatedActivities]);

  const getActivityPageNumbers = (current, total) => {
    if (total <= 7) {
      return Array.from({ length: total }, (_, i) => i + 1);
    }
    const pages = [1];
    let start = Math.max(2, current - 1);
    let end = Math.min(total - 1, current + 1);

    if (current <= 3) {
      start = 2;
      end = 4;
    } else if (current >= total - 2) {
      start = total - 3;
      end = total - 1;
    }

    if (start > 2) pages.push("...");
    for (let i = start; i <= end; i++) pages.push(i);
    if (end < total - 1) pages.push("...");
    pages.push(total);
    return pages;
  };

  const overview = useMemo(() => {
    const connectedCalls = calls.filter((call) =>
      ["connected", "completed", "answered"].some((status) => normalizeText(call.status).includes(status))
    ).length;
    const missedCalls = calls.filter((call) =>
      ["missed", "no-answer", "failed", "busy"].some((status) => normalizeText(call.status).includes(status))
    ).length;

    return [
      ["Total Calls", calls.length],
      ["Connected Calls", connectedCalls],
      ["Missed Calls", missedCalls],
      ["Follow-ups", followups.length],
      ["Site Visits", visits.length],
      ["Bookings", bookings.length],
      ["Notes", notes.length],
    ];
  }, [bookings.length, calls, followups.length, notes.length, visits.length]);

  const upcomingFollowups = followups.filter((item) => item.status !== "Completed" && new Date(item.dueAt) >= new Date());
  const overdueFollowups = followups.filter((item) => item.status !== "Completed" && new Date(item.dueAt) < new Date());
  const completedVisits = visits.filter((visit) => normalizeText(visit.status).includes("done") || normalizeText(visit.status).includes("completed"));
  const cancelledVisits = visits.filter((visit) => normalizeText(visit.status).includes("cancel"));
  const scheduledVisits = visits.filter((visit) => !completedVisits.includes(visit) && !cancelledVisits.includes(visit));
  const lastActivity = activities[0]?.createdAt || createdDate;
  const latestBooking = useMemo(() => {
    const bookingRows = bookings.length ? bookings : lead?.bookings || [];
    return [...bookingRows].sort((first, second) => {
      const firstTime = toDate(first?.bookedOn || first?.createdAt)?.getTime() || 0;
      const secondTime = toDate(second?.bookedOn || second?.createdAt)?.getTime() || 0;
      return secondTime - firstTime;
    })[0];
  }, [bookings, lead?.bookings]);
  const existingBooking = latestBooking?.id ? latestBooking : null;
  const hasBookedStatusWithoutBooking = isBookedStatusLocked && !existingBooking;
  const openBookingFlow = () => {
    if (!leadId) return;
    const params = new URLSearchParams();
    params.set("leadId", leadId);
    params.set("startBooking", "1");
    params.set("returnTo", `${location.pathname}${location.search || ""}`);
    navigate(`/user/sales/bookings?${params.toString()}`, {
      state: { lead, startBooking: true, returnTo: `${location.pathname}${location.search || ""}` },
    });
  };
  const openExistingBooking = () => {
    if (!existingBooking?.id) return;
    const params = new URLSearchParams();
    params.set("bookingId", existingBooking.id);
    if (leadId) params.set("leadId", leadId);
    navigate(`/user/sales/bookings?${params.toString()}`, {
      state: { lead, booking: existingBooking, returnTo: `${location.pathname}${location.search || ""}` },
    });
  };
  const bookingUnitFields = latestBooking
    ? [
        ["Name", valueOf(latestBooking, ["unit", "unitName", "name"], "-")],
        ["Status", valueOf(latestBooking, ["unitStatus", "projectUnitStatus", "status"], "Available")],
        ["Floor", valueOf(latestBooking, ["floor", "floorName"], "-")],
        ["Project Tower Name", valueOf(latestBooking, ["towerName", "projectTowerName", "tower"], "-")],
        ["Bedrooms", valueOf(latestBooking, ["bedrooms", "bedroom"], "-")],
        ["Bathrooms", valueOf(latestBooking, ["bathrooms", "bathroom"], "-")],
        ["Carpet", formatNumber(valueOf(latestBooking, ["carpetArea", "carpet"], ""))],
        ["Saleable", formatArea(valueOf(latestBooking, ["saleableArea", "saleable"], ""))],
        ["Base Rate", formatCompactMoney(valueOf(latestBooking, ["baseRate"], ""))],
        ["Floor Rise", valueOf(latestBooking, ["floorRise"], "0")],
        ["Effective Rate", formatNumber(valueOf(latestBooking, ["effectiveRate", "baseRate"], ""))],
        ["Total Price", formatCompactMoney(valueOf(latestBooking, ["totalPrice", "totalAmount", "basePrice"], ""))],
        ["Final Sold Price", formatMoney(valueOf(latestBooking, ["soldPrice", "totalPrice", "agreementValue"], ""))],
        ["Agreement Value", formatCompactMoney(valueOf(latestBooking, ["agreementValue", "basePrice"], ""))],
        ["Booking Name", valueOf(latestBooking, ["bookingName", "customerName"], leadName)],
        ["Booking Date", formatDateOnly(valueOf(latestBooking, ["bookingDate", "bookedOn", "createdAt"], ""))],
      ]
    : [];
  const bookingApplicantFields = latestBooking
    ? [
        ["Name", valueOf(latestBooking, ["customerName", "bookingName"], leadName)],
        ["Lead Name", leadName],
        ["Phone", valueOf(latestBooking, ["phone", "mobile"], primaryPhone || "-")],
        ["DOB", valueOf(latestBooking, ["dob", "dateOfBirth"], valueOf(lead, ["birthday", "dob", "dateOfBirth"], "-"))],
        ["PAN Number", valueOf(latestBooking, ["panNumber", "pan"], valueOf(lead, ["panNumber", "pan"], "-"))],
        ["Aadhaar Number", valueOf(latestBooking, ["aadhaarNumber", "aadharNumber", "aadhaar", "aadhar"], valueOf(lead, ["aadhaarNumber", "aadharNumber", "aadhaar", "aadhar"], "-"))],
        ["Email", valueOf(latestBooking, ["email"], primaryEmail || "-")],
      ]
    : [];

  return (
    <>
      <style>{`
        .crm-details {
          background: var(--neutral-50, #f5f6fa);
          color: var(--neutral-800, #1f2937);
          min-height: ${embedded ? "calc(100vh - 40px)" : "100vh"};
          padding: ${embedded ? "0" : "22px"};
        }

        .crm-details-shell {
          display: grid;
          gap: 18px;
          margin: 0 auto;
          max-width: 1500px;
        }

        .crm-lead-header,
        .crm-panel,
        .crm-card {
          background: var(--white, #ffffff);
          border: 1px solid var(--neutral-200, #ebecef);
          border-radius: var(--rounded-8, 8px);
          box-shadow: var(--shadow-4, 4px 8px 24px 0 rgba(182, 182, 182, 0.2));
        }

        .crm-lead-header {
          display: grid;
          gap: 16px;
          padding: 18px;
        }

        .crm-header-top {
          align-items: flex-start;
          display: flex;
          gap: 16px;
          justify-content: space-between;
        }

        .crm-lead-title h1 {
          color: var(--neutral-900, #111827);
          font-size: 24px;
          font-weight: 700;
          line-height: 1.2;
          margin: 0 0 6px;
        }

        .crm-lead-title p {
          color: var(--neutral-500, #6b7280);
          margin: 0;
        }

        .crm-status-badge {
          background: var(--primary-50, #e4f1ff);
          border: 1px solid var(--primary-100, #bfdcff);
          border-radius: 999px;
          color: var(--primary-600, #487fff);
          display: inline-flex;
          font-size: 13px;
          font-weight: 700;
          padding: 7px 12px;
          white-space: nowrap;
        }

        .crm-header-grid,
        .crm-overview-grid {
          display: grid;
          gap: 10px;
          grid-template-columns: repeat(4, minmax(0, 1fr));
        }

        .crm-header-grid {
          grid-template-columns: repeat(3, minmax(0, 1fr)) minmax(140px, 0.7fr);
        }

        .crm-header-field,
        .crm-overview-card {
          background: var(--neutral-50, #f5f6fa);
          border: 1px solid var(--neutral-200, #ebecef);
          border-radius: var(--rounded-6, 6px);
          padding: 11px 12px;
        }

        .crm-score-field {
          align-items: center;
          display: flex;
          gap: 12px;
          min-height: 86px;
        }

        .crm-score-circle {
          --score: 0;
          align-items: center;
          background: conic-gradient(var(--primary-600, #487fff) calc(var(--score) * 1%), var(--neutral-200, #ebecef) 0);
          border-radius: 50%;
          display: inline-flex;
          flex: 0 0 66px;
          height: 66px;
          justify-content: center;
          position: relative;
          width: 66px;
        }

        .crm-score-circle::before {
          background: var(--white, #ffffff);
          border-radius: 50%;
          content: "";
          inset: 7px;
          position: absolute;
        }

        .crm-score-circle strong {
          color: var(--neutral-900, #111827);
          font-size: 16px;
          line-height: 1;
          position: relative;
          z-index: 1;
        }

        .crm-label {
          color: var(--neutral-500, #6b7280);
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.04em;
          margin-bottom: 4px;
          text-transform: uppercase;
        }

        .crm-value {
          color: var(--neutral-800, #1f2937);
          font-size: 14px;
          font-weight: 600;
          min-width: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .crm-action-bar {
          align-items: center;
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          overflow-x: visible;
        }

        .crm-status-control {
          align-items: center;
          display: flex;
          gap: 8px;
          margin-left: auto;
        }

        .crm-action-btn,
        .crm-small-btn {
          align-items: center;
          background: var(--white, #ffffff);
          border: 1px solid var(--neutral-300, #d1d5db);
          border-radius: var(--rounded-6, 6px);
          color: var(--neutral-700, #374151);
          cursor: pointer;
          display: inline-flex;
          font-size: 13px;
          font-weight: 700;
          gap: 8px;
          min-height: 36px;
          padding: 0 12px;
        }

        .crm-action-btn:hover,
        .crm-small-btn:hover {
          background: var(--primary-50, #e4f1ff);
          border-color: var(--primary-200, #95c7ff);
          color: var(--primary-700, #486cea);
        }

        .crm-action-btn.primary,
        .crm-small-btn.primary {
          background: var(--primary-600, #487fff);
          border-color: var(--primary-600, #487fff);
          color: var(--white, #ffffff);
        }

        .crm-action-btn.primary:hover,
        .crm-small-btn.primary:hover {
          background: var(--primary-700, #486cea);
          border-color: var(--primary-700, #486cea);
          color: var(--white, #ffffff);
        }

        .crm-action-btn.danger,
        .crm-small-btn.danger {
          color: var(--danger-700, #b91c1c);
        }

        .crm-status-select {
          border: 1px solid var(--neutral-300, #d1d5db);
          border-radius: var(--rounded-6, 6px);
          color: var(--neutral-700, #374151);
          height: 36px;
          min-width: 174px;
          padding: 0 10px;
        }

        .crm-status-save {
          min-width: 92px;
        }

        .crm-status-readonly {
          align-items: center;
          background: var(--primary-50, #e4f1ff);
          border: 1px solid var(--primary-100, #bfdcff);
          border-radius: var(--rounded-6, 6px);
          color: var(--primary-700, #486cea);
          display: inline-flex;
          font-size: 13px;
          font-weight: 700;
          min-height: 36px;
          padding: 0 12px;
          white-space: nowrap;
        }

        .crm-warning-inline {
          color: #b45309;
          font-size: 12px;
          font-weight: 600;
          line-height: 1.4;
        }

        .crm-more-wrap {
          position: relative;
        }

        .crm-more-menu {
          background: var(--white, #ffffff);
          border: 1px solid var(--neutral-200, #ebecef);
          border-radius: var(--rounded-8, 8px);
          box-shadow: var(--shadow-4, 4px 8px 24px 0 rgba(182, 182, 182, 0.2));
          display: grid;
          min-width: 210px;
          padding: 6px;
          position: absolute;
          right: 0;
          top: 42px;
          z-index: 20;
        }

        .crm-more-menu button {
          align-items: center;
          background: transparent;
          border: 0;
          border-radius: var(--rounded-6, 6px);
          color: var(--neutral-700, #374151);
          cursor: pointer;
          display: flex;
          font: inherit;
          gap: 9px;
          padding: 9px 10px;
          text-align: left;
        }

        .crm-more-menu button:hover {
          background: var(--primary-50, #e4f1ff);
          color: var(--primary-700, #486cea);
        }

        .crm-more-field {
          display: grid;
          gap: 6px;
          padding: 8px;
        }

        .crm-more-field .crm-status-select {
          min-width: 190px;
          width: 100%;
        }

        .crm-main-grid {
          align-items: start;
          display: grid;
          gap: 18px;
          grid-template-columns: minmax(280px, 0.42fr) minmax(0, 1fr);
        }

        .crm-panel {
          overflow: hidden;
        }

        .crm-panel-head {
          align-items: center;
          border-bottom: 1px solid var(--neutral-200, #ebecef);
          display: flex;
          justify-content: space-between;
          padding: 14px 16px;
        }

        .crm-panel-head h2 {
          color: var(--neutral-800, #1f2937);
          font-size: 16px;
          font-weight: 700;
          margin: 0;
        }

        .crm-panel-body {
          display: grid;
          gap: 12px;
          padding: 16px;
        }

        .crm-info-row,
        .crm-list-row {
          border-bottom: 1px solid var(--neutral-200, #ebecef);
          display: grid;
          gap: 5px;
          padding-bottom: 10px;
        }

        .crm-info-row:last-child,
        .crm-list-row:last-child {
          border-bottom: 0;
          padding-bottom: 0;
        }

        .crm-overview-card strong {
          display: block;
          font-size: 22px;
          line-height: 1;
          margin-top: 4px;
        }

        .crm-workspace {
          display: grid;
          gap: 18px;
        }

        .crm-note-box,
        .crm-followup-form,
        .crm-visit-link-panel {
          display: grid;
          gap: 10px;
        }

        .crm-note-box textarea,
        .crm-followup-form input {
          border: 1px solid var(--neutral-300, #d1d5db);
          border-radius: var(--rounded-6, 6px);
          color: var(--neutral-700, #374151);
          min-height: 38px;
          padding: 9px 10px;
          width: 100%;
        }

        .crm-note-box textarea {
          min-height: 92px;
          resize: vertical;
        }

        .crm-form-actions {
          align-items: center;
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }

        .crm-note-save,
        .crm-back-btn {
          justify-content: center;
          width: max-content;
        }

        .crm-note-save {
          min-width: 122px;
        }

        .crm-back-btn {
          min-width: 92px;
        }

        .crm-visit-link-panel {
          background: var(--neutral-50, #f5f6fa);
          border: 1px solid var(--neutral-200, #ebecef);
          border-radius: var(--rounded-8, 8px);
          padding: 14px;
        }

        .crm-visit-link-panel p {
          color: var(--neutral-500, #6b7280);
          margin: 0;
        }

        .crm-status-control {
          align-items: center;
          display: flex;
          flex: 0 0 auto;
          gap: 8px;
          margin-left: 0;
        }

        .crm-action-bar > .crm-status-control {
          margin-left: auto;
        }

        .crm-status-field {
          align-items: center;
          display: flex;
          gap: 8px;
        }

        .crm-status-select {
          background: var(--white, #ffffff);
          border: 1px solid var(--neutral-300, #d1d5db);
          border-radius: var(--rounded-6, 6px);
          color: var(--neutral-900, #111827);
          font-size: 14px;
          font-weight: 600;
          height: 46px;
          min-width: 190px;
          padding: 0 12px;
        }

        .crm-status-score {
          align-items: center;
          background: var(--neutral-50, #f5f6fa);
          border: 1px solid var(--neutral-200, #ebecef);
          border-radius: var(--rounded-6, 6px);
          color: var(--neutral-800, #1f2937);
          display: inline-flex;
          font-size: 13px;
          font-weight: 700;
          height: 46px;
          padding: 0 12px;
          white-space: nowrap;
        }

        .crm-admin-status-tools {
          align-items: center;
          display: flex;
          flex: 0 0 auto;
          gap: 8px;
          margin-left: auto;
        }

        .crm-image-status-field {
          align-items: center;
          display: flex;
          gap: 8px;
        }

        .crm-status-inline-label {
          color: var(--neutral-500, #6b7280);
          font-size: 12px;
          font-weight: 800;
          text-transform: uppercase;
          white-space: nowrap;
        }

        .crm-footer-actions {
          display: flex;
          justify-content: flex-end;
        }

        .crm-tabs {
          border-bottom: 1px solid var(--neutral-200, #ebecef);
          display: flex;
          gap: 18px;
          overflow-x: auto;
          padding: 0 16px;
          white-space: nowrap;
        }

        .crm-tabs button {
          background: transparent;
          border: 0;
          color: var(--neutral-500, #6b7280);
          cursor: pointer;
          font-size: 13px;
          font-weight: 700;
          padding: 14px 0 11px;
          position: relative;
        }

        .crm-tabs button.active {
          color: var(--neutral-800, #1f2937);
        }

        .crm-tab-badge {
          background: var(--neutral-100, #f3f4f6);
          border-radius: 999px;
          color: var(--neutral-600, #4b5563);
          display: inline-flex;
          font-size: 11px;
          font-weight: 700;
          line-height: 1;
          margin-left: 6px;
          padding: 3px 6px;
          vertical-align: middle;
        }

        .crm-tabs button.active .crm-tab-badge {
          background: #e0e7ff;
          color: #487fff;
        }

        .crm-tabs button.active::after {
          background: var(--primary-600, #487fff);
          bottom: 0;
          content: "";
          height: 2px;
          left: 0;
          position: absolute;
          right: 0;
        }

        .crm-timeline {
          display: grid;
          gap: 20px;
          padding: 16px;
        }

        .crm-pagination {
          align-items: center;
          border-top: 1px solid var(--neutral-200, #ebecef);
          color: var(--neutral-600, #4b5563);
          display: flex;
          flex-wrap: wrap;
          font-size: 13px;
          gap: 12px;
          justify-content: space-between;
          padding: 12px 16px;
        }

        .crm-pagination-info {
          color: var(--neutral-500, #6b7280);
          font-size: 12px;
        }

        .crm-pagination-actions {
          align-items: center;
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
        }

        .crm-pagination-btn {
          align-items: center;
          background: #ffffff;
          border: 1px solid var(--neutral-200, #ebecef);
          border-radius: 6px;
          color: var(--neutral-700, #374151);
          cursor: pointer;
          display: inline-flex;
          font-size: 12px;
          font-weight: 500;
          height: 30px;
          justify-content: center;
          min-width: 30px;
          padding: 0 10px;
          transition: all 0.15s ease;
        }

        .crm-pagination-btn:hover:not(:disabled) {
          background: var(--neutral-50, #f9fafb);
          border-color: var(--primary-500, #487fff);
          color: var(--primary-600, #487fff);
        }

        .crm-pagination-btn.active {
          background: var(--primary-600, #487fff);
          border-color: var(--primary-600, #487fff);
          color: #ffffff;
          font-weight: 700;
        }

        .crm-pagination-btn:disabled {
          cursor: not-allowed;
          opacity: 0.45;
        }

        .crm-pagination-ellipsis {
          color: var(--neutral-400, #9ca3af);
          display: inline-flex;
          font-size: 12px;
          justify-content: center;
          min-width: 20px;
          user-select: none;
        }

        .crm-day {
          display: grid;
          gap: 10px;
        }

        .crm-day-title {
          color: var(--neutral-500, #6b7280);
          font-size: 12px;
          font-weight: 800;
          text-transform: uppercase;
        }

        .crm-activity {
          border: 1px solid var(--neutral-200, #ebecef);
          border-radius: var(--rounded-6, 6px);
          display: grid;
          gap: 8px;
          padding: 13px;
        }

        .crm-activity-top {
          align-items: flex-start;
          display: flex;
          gap: 12px;
          justify-content: space-between;
        }

        .crm-activity-title {
          align-items: center;
          color: var(--neutral-800, #1f2937);
          display: flex;
          font-size: 14px;
          font-weight: 800;
          gap: 9px;
        }

        .crm-activity-title svg {
          color: var(--primary-600, #487fff);
        }

        .crm-activity p {
          color: var(--neutral-600, #4b5563);
          margin: 0;
        }

        .crm-muted {
          color: var(--neutral-500, #6b7280);
          font-size: 12px;
        }

        .crm-note-actions {
          display: flex;
          gap: 8px;
        }

        .crm-bottom-grid {
          display: grid;
          gap: 18px;
          grid-template-columns: repeat(3, minmax(0, 1fr));
        }

        .crm-booking-confirmation {
          display: grid;
          gap: 16px;
        }

        .crm-booking-title {
          color: #666666;
          font-size: 15px;
          font-weight: 700;
          margin: 0;
        }

        .crm-booking-card {
          background: #ffffff;
          border: 1px solid #cfd6df;
          border-radius: 3px;
          overflow: hidden;
        }

        .crm-booking-card-head {
          align-items: center;
          background: #673ab7;
          color: #ffffff;
          display: flex;
          font-size: 14px;
          font-weight: 700;
          min-height: 38px;
          padding: 0 8px;
        }

        .crm-booking-grid,
        .crm-applicant-grid {
          display: grid;
          gap: 18px 28px;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          padding: 14px 16px 28px;
        }

        .crm-applicant-grid {
          border-bottom: 1px solid #e3e7ee;
        }

        .crm-booking-field {
          display: grid;
          gap: 5px;
          min-width: 0;
        }

        .crm-booking-field span {
          color: #7b8794;
          font-size: 11px;
          font-weight: 600;
          text-transform: uppercase;
        }

        .crm-booking-field strong {
          color: #4b5563;
          font-size: 15px;
          font-weight: 500;
          min-height: 18px;
          overflow-wrap: anywhere;
        }

        .crm-add-coapplicant {
          align-items: center;
          background: #ffffff;
          border: 0;
          color: #5528d8;
          cursor: pointer;
          display: flex;
          font: inherit;
          font-size: 14px;
          font-weight: 700;
          justify-content: center;
          min-height: 52px;
          width: 100%;
        }

        .crm-empty {
          color: var(--neutral-500, #6b7280);
          padding: 18px;
          text-align: center;
        }

        @media (max-width: 1100px) {
          .crm-action-bar {
            flex-wrap: wrap;
          }

          .crm-main-grid,
          .crm-bottom-grid,
          .crm-header-grid,
          .crm-booking-grid,
          .crm-applicant-grid,
          .crm-overview-grid {
            grid-template-columns: 1fr;
          }

          .crm-header-top {
            flex-direction: column;
          }
        }
      `}</style>

      <div className="crm-details">
        <div className="crm-details-shell">
          <section className="crm-lead-header">
            <div className="crm-header-top">
              <div className="crm-lead-title">
                <h1>{leadName}</h1>
                <p>#{leadId || "-"} | {primaryPhone || "No mobile number"} | {projectInterest}</p>
              </div>
            </div>

            <div className="crm-header-grid">
              {[
                ["Mobile Number", primaryPhone || "-"],
                ["Project Interest", projectInterest],
                ["Source", source],
                ["Assigned Sales User", owner],
                ["Created Date", formatDateTime(createdDate)],
                ["Last Activity", formatDateTime(lastActivity)],
                ["Email", primaryEmail || "-"],
              ].map(([label, value]) => (
                <div className="crm-header-field" key={label}>
                  <div className="crm-label">{label}</div>
                  <div className="crm-value">{value}</div>
                </div>
              ))}
              <div className="crm-header-field crm-score-field">
                <div>
                  <div className="crm-label">Lead Score</div>
                  <div className="crm-muted">Based on current stage</div>
                </div>
                <div className="crm-score-circle" style={{ "--score": leadScoreNumber }}>
                  <strong>{leadScoreNumber}%</strong>
                </div>
              </div>
            </div>

            <div className="crm-action-bar">
              {!isAdminContext && (
                <>
                  <button className="crm-action-btn primary" type="button" onClick={openSalesCallPage}>
                    <FaPhoneAlt /> Call
                  </button>
                  <button className="crm-action-btn" type="button" onClick={openSalesWhatsAppPage}>
                    <FaWhatsapp /> WhatsApp
                  </button>
                </>
              )}
              <button
                className="crm-action-btn"
                type="button"
                onClick={() => {
                  setActiveTab("Activity");
                  setTimeout(() => {
                    noteInputRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
                    noteInputRef.current?.focus();
                  }, 50);
                }}
              >
                <FaRegStickyNote /> Add Note
              </button>
              {!isAdminContext && (
                <>
                  <button
                    className="crm-action-btn"
                    type="button"
                    onClick={openSalesFollowupPage}
                  >
                    <FaClock /> Schedule Follow-up
                  </button>
                  <button
                    className="crm-action-btn"
                    type="button"
                    onClick={() => openSalesSiteVisitPage()}
                  >
                    <FaCalendarAlt /> Schedule Site Visit
                  </button>
                </>
              )}
              <a className="crm-action-btn" href={primaryEmail ? `mailto:${primaryEmail}` : undefined}>
                <FaEnvelope /> Send Email
              </a>
              <div className={isAdminContext ? "crm-admin-status-tools" : "crm-status-control"}>
                <div className="crm-status-control">
                  {isBookedStatusLocked ? (
                    <>
                      <span className="crm-status-readonly">Booked</span>
                      <button
                        className="crm-small-btn primary crm-status-save"
                        type="button"
                        onClick={existingBooking ? openExistingBooking : openBookingFlow}
                      >
                        <FaLock /> {existingBooking ? "View Booking" : "Complete Booking"}
                      </button>
                    </>
                  ) : (
                    <>
                      <label className="crm-status-field">
                        <select
                          className="crm-status-select"
                          disabled={isSavingStatus}
                          value={stageStatusValue}
                          onChange={(event) => handleStatusChange(event.target.value)}
                        >
                          {!stageStatusValue && (
                            <option value="" disabled>
                              Select status
                            </option>
                          )}
                          {statusOptions.map((status) => (
                            <option key={status} value={status}>
                              {status}
                            </option>
                          ))}
                        </select>
                      </label>
                      {isBookedSelectedBeforeBooking ? (
                        <button
                          className="crm-small-btn primary crm-status-save"
                          type="button"
                          onClick={openBookingFlow}
                        >
                          <FaLock /> Book Unit
                        </button>
                      ) : (
                        <button
                          className="crm-small-btn primary crm-status-save"
                          disabled={isSavingStatus || !stageStatusValue || stageStatusValue === persistedLeadStatus}
                          type="button"
                          onClick={() => saveStatus(stageStatusValue)}
                        >
                          <FaSave /> {isSavingStatus ? "Saving..." : "Save"}
                        </button>
                      )}
                    </>
                  )}
                </div>
                {hasBookedStatusWithoutBooking && (
                  <div className="crm-warning-inline">This lead is marked Booked, but no booking record was found.</div>
                )}
              </div>
              <div className="crm-more-wrap">
                <button
                  className="crm-action-btn"
                  type="button"
                  onClick={() => setShowMoreMenu((current) => !current)}
                >
                  <FaEllipsisV /> More
                </button>
                {showMoreMenu && (
                  <div className="crm-more-menu">
                    <button
                      type="button"
                      onClick={() => {
                        setShowMoreMenu(false);
                        reassignLead();
                      }}
                    >
                      <FaExchangeAlt /> Reassign Lead
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowMoreMenu(false);
                        if (isAdminContext) {
                          navigate("/SiteVists", { state: { lead, status: "Conducted" } });
                          return;
                        }
                        openSalesSiteVisitPage("Conducted");
                      }}
                    >
                      <FaCalendarAlt /> Conducted Site visit
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowMoreMenu(false);
                        navigate(isAdminContext ? "/bookings" : "/user/sales/bookings", {
                          state: { lead },
                        });
                      }}
                    >
                      <FaLock /> Bookings
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowMoreMenu(false);
                        alert("Merge Leads workflow is ready to connect.");
                      }}
                    >
                      <FaExchangeAlt /> Merge Leads
                    </button>
                  </div>
                )}
              </div>
            </div>
            {statusMessage && <div className="crm-muted">{statusMessage}</div>}
          </section>

          <section className="crm-overview-grid">
            {overview.map(([label, count]) => (
              <div className="crm-overview-card" key={label}>
                <div className="crm-label">{label}</div>
                <strong>{count}</strong>
              </div>
            ))}
          </section>

          <div className="crm-main-grid">
            <aside className="crm-panel">
              <div className="crm-panel-head">
                <h2>Lead Information</h2>
                <FaUserTie />
              </div>
              <div className="crm-panel-body">
                {[
                  ["Status", persistedLeadStatus],
                  ["Assigned To", owner],
                  ["Source", source],
                  ["Project", projectInterest],
                  ["Configuration", valueOf(lead, ["configration", "configuration"], "-")],
                  ["Budget", valueOf(lead, ["budget", "budgetMax", "budgetMin"], "-")],
                  ["Location", valueOf(lead, ["locationPreferences", "city"], "-")],
                  ["Property Type", valueOf(lead, ["propertyType", "type"], "-")],
                  ["Funding Source", valueOf(lead, ["fundingSource"], "-")],
                  ["Tags", valueOf(lead, ["tags"], "-")],
                ].map(([label, value]) => (
                  <div className="crm-info-row" key={label}>
                    <div className="crm-label">{label}</div>
                    <div className="crm-value">{value}</div>
                  </div>
                ))}
              </div>
            </aside>

            <section className="crm-workspace">
              <div className="crm-panel">
                <div className="crm-panel-head">
                  <h2>{editingNoteId ? "Edit Note" : "Add Note"}</h2>
                  {editingNoteId && (
                    <button
                      className="crm-small-btn"
                      type="button"
                      onClick={() => {
                        setEditingNoteId(null);
                        setNoteDraft("");
                      }}
                    >
                      <FaTimes /> Cancel
                    </button>
                  )}
                </div>
                <div className="crm-panel-body">
                  <div className="crm-note-box">
                    <textarea
                      ref={noteInputRef}
                      value={noteDraft}
                      onChange={(event) => setNoteDraft(event.target.value)}
                      placeholder="Add note for lead. Use @name to mention a user."
                    />
                    <div className="crm-form-actions">
                      <button className="crm-small-btn primary crm-note-save" disabled={isSavingNote} type="button" onClick={saveNote}>
                        <FaSave /> {isSavingNote ? "Saving..." : "Save Note"}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="crm-panel">
                <div className="crm-tabs">
                  {tabs.map((tab) => {
                    const count = tabCounts[tab] ?? 0;
                    return (
                      <button
                        className={activeTab === tab ? "active" : ""}
                        key={tab}
                        type="button"
                        onClick={() => setActiveTab(tab)}
                      >
                        {tab}
                        {count > 0 && <span className="crm-tab-badge">{count}</span>}
                      </button>
                    );
                  })}
                </div>

                <div className="crm-timeline">
                  {Object.keys(groupedActivities).length === 0 ? (
                    <div className="crm-empty">No records found for {activeTab}.</div>
                  ) : (
                    Object.entries(groupedActivities).map(([day, dayActivities]) => (
                      <div className="crm-day" key={day}>
                        <div className="crm-day-title">{day}</div>
                        {dayActivities.map((activity) => (
                          <article className="crm-activity" key={activity.id}>
                            <div className="crm-activity-top">
                              <div>
                                <div className="crm-activity-title">
                                  {activity.icon}
                                  {activity.title}
                                </div>
                                <p>{activity.description}</p>
                              </div>
                              {activity.type === "Notes" && activity.source && activity.source.note && (
                                <div className="crm-note-actions">
                                  <button className="crm-small-btn" type="button" onClick={() => togglePinNote(activity.source)}>
                                    <FaStar /> {activity.source.pinned ? "Unpin" : "Pin"}
                                  </button>
                                  <button className="crm-small-btn" type="button" onClick={() => editNote(activity.source)}>
                                    <FaEdit /> Edit
                                  </button>
                                  <button className="crm-small-btn danger" type="button" onClick={() => deleteNote(activity.source)}>
                                    <FaTrash /> Delete
                                  </button>
                                </div>
                              )}
                              {activity.type === "Follow-ups" && activity.source && activity.source.dueAt && (
                                <div className="crm-note-actions">
                                  {activity.source.status !== "Completed" && activity.source.status !== "Done" && (
                                    <button className="crm-small-btn" type="button" onClick={() => updateFollowupStatus(activity.source, "Done")}>
                                      <FaCheckCircle /> Mark Done
                                    </button>
                                  )}
                                  <button className="crm-small-btn" type="button" onClick={() => updateFollowupStatus(activity.source, "Rescheduled")}>
                                    <FaClock /> Reschedule
                                  </button>
                                </div>
                              )}
                            </div>
                            <div className="crm-muted">
                              {activity.meta} | {formatDateTime(activity.createdAt)}
                            </div>
                          </article>
                        ))}
                      </div>
                    ))
                  )}
                </div>

                {filteredActivities.length > ACTIVITY_PAGE_SIZE && (
                  <div className="crm-pagination">
                    <div className="crm-pagination-info">
                      Showing <strong>{(currentActivityPage - 1) * ACTIVITY_PAGE_SIZE + 1}</strong> to{" "}
                      <strong>{Math.min(currentActivityPage * ACTIVITY_PAGE_SIZE, filteredActivities.length)}</strong> of{" "}
                      <strong>{filteredActivities.length}</strong> records
                    </div>
                    <div className="crm-pagination-actions">
                      <button
                        className="crm-pagination-btn"
                        type="button"
                        disabled={currentActivityPage === 1}
                        onClick={() => setActivityPage((prev) => Math.max(1, prev - 1))}
                      >
                        Previous
                      </button>
                      {getActivityPageNumbers(currentActivityPage, totalActivityPages).map((item, idx) =>
                        item === "..." ? (
                          <span key={`ellipsis-${idx}`} className="crm-pagination-ellipsis">
                            ...
                          </span>
                        ) : (
                          <button
                            key={item}
                            className={`crm-pagination-btn ${item === currentActivityPage ? "active" : ""}`}
                            type="button"
                            onClick={() => setActivityPage(item)}
                          >
                            {item}
                          </button>
                        )
                      )}
                      <button
                        className="crm-pagination-btn"
                        type="button"
                        disabled={currentActivityPage >= totalActivityPages}
                        onClick={() => setActivityPage((prev) => Math.min(totalActivityPages, prev + 1))}
                      >
                        Next
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </section>
          </div>

          {latestBooking && (
            <section className="crm-booking-confirmation">
              <h2 className="crm-booking-title">Booking Confirmation</h2>

              <div className="crm-booking-card">
                <div className="crm-booking-card-head">Unit Details</div>
                <div className="crm-booking-grid">
                  {bookingUnitFields.map(([label, value]) => (
                    <div className="crm-booking-field" key={label}>
                      <span>{label}</span>
                      <strong>{value || "-"}</strong>
                    </div>
                  ))}
                </div>
              </div>

              <div className="crm-booking-card">
                <div className="crm-booking-card-head">Applicant Details</div>
                <div className="crm-applicant-grid">
                  {bookingApplicantFields.map(([label, value]) => (
                    <div className="crm-booking-field" key={label}>
                      <span>{label}</span>
                      <strong>{value || "-"}</strong>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          )}

          <section className="crm-bottom-grid">
            <div className="crm-panel">
              <div className="crm-panel-head">
                <h2>Follow-ups</h2>
                <span className="crm-muted">{upcomingFollowups.length} upcoming, {overdueFollowups.length} overdue</span>
              </div>
              <div className="crm-panel-body">
                {followups.length === 0 ? (
                  <div className="crm-empty">No follow-ups scheduled.</div>
                ) : (
                  followups.map((item) => (
                    <div className="crm-list-row" key={item.id}>
                      <div className="crm-value">{item.title}</div>
                      <div className="crm-muted">{formatDateTime(item.dueAt)} | {item.status}</div>
                      <div className="crm-action-bar">
                        <button className="crm-small-btn" type="button" onClick={() => updateFollowupStatus(item, "Done")}>Mark Done</button>
                        <button className="crm-small-btn" type="button" onClick={() => updateFollowupStatus(item, "Rescheduled")}>Reschedule</button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="crm-panel">
              <div className="crm-panel-head">
                <h2>Site Visits</h2>
                <span className="crm-muted">{scheduledVisits.length} scheduled, {completedVisits.length} completed, {cancelledVisits.length} cancelled</span>
              </div>
              <div className="crm-panel-body">
                {visits.length === 0 ? (
                  <div className="crm-empty">No site visits found.</div>
                ) : (
                  visits.map((visit) => (
                    <div className="crm-list-row" key={visit.id}>
                      <div className="crm-value">{displayValue(visit.project || projectInterest)}</div>
                      <div className="crm-muted">{formatDateTime(visit.scheduledOn)} | {visit.status}</div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="crm-panel">
              <div className="crm-panel-head">
                <h2>Bookings & Audit</h2>
                <FaHistory />
              </div>
              <div className="crm-panel-body">
                {bookings.length === 0 ? (
                  <div className="crm-empty">No bookings found.</div>
                ) : (
                  bookings.map((booking) => (
                    <div className="crm-list-row" key={booking.id}>
                      <div className="crm-value">{displayValue(booking.projectDetails || booking.customerName, "Booking")}</div>
                      <div className="crm-muted">
                        {formatDateOnly(booking.bookedOn || booking.createdAt)} | Sold Price {formatMoney(valueOf(booking, ["soldPrice", "totalPrice", "agreementValue"], ""))} | {booking.stage || "-"}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </section>

          {!embedded && (
            <div className="crm-footer-actions">
              <button
                className="crm-small-btn crm-back-btn"
                type="button"
                onClick={() => navigate(detailsBackPath)}
              >
                <FaArrowLeft /> Back
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default UserDetails;
