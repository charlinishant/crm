CREATE TABLE `ScheduleVisit` (
  `id` INTEGER NOT NULL AUTO_INCREMENT,
  `leadId` INTEGER NOT NULL,
  `project` VARCHAR(191) NULL,
  `status` VARCHAR(191) NOT NULL DEFAULT 'Scheduled',
  `meetingPoint` VARCHAR(191) NULL,
  `salesExecutive` VARCHAR(191) NULL,
  `note` TEXT NULL,
  `initiatedBy` VARCHAR(191) NULL,
  `scheduledOn` DATETIME(3) NULL,
  `conductedOn` DATETIME(3) NULL,
  `conductedBy` VARCHAR(191) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  UNIQUE INDEX `ScheduleVisit_leadId_key`(`leadId`),
  INDEX `ScheduleVisit_status_idx`(`status`),
  INDEX `ScheduleVisit_scheduledOn_idx`(`scheduledOn`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `ScheduleVisit`
  ADD CONSTRAINT `ScheduleVisit_leadId_fkey`
  FOREIGN KEY (`leadId`) REFERENCES `Lead`(`id`)
  ON DELETE RESTRICT ON UPDATE CASCADE;

INSERT INTO `ScheduleVisit` (
  `leadId`,
  `project`,
  `status`,
  `meetingPoint`,
  `salesExecutive`,
  `note`,
  `initiatedBy`,
  `scheduledOn`,
  `conductedOn`,
  `conductedBy`,
  `createdAt`,
  `updatedAt`
)
SELECT
  `id`,
  COALESCE(`siteVisitProject`, `conductSiteVisit`, `interestedProjects`, `propertyType`),
  COALESCE(`siteVisitStatus`, `visitStatus`, `conductSiteStatus`, 'Scheduled'),
  COALESCE(`siteVisitLocation`, `meetingPoint`, `locationPreferences`),
  `siteVisitExecutive`,
  `siteVisitNote`,
  `siteVisitInitiatedBy`,
  COALESCE(`conductSiteDate`, `siteVisitDate`),
  `siteVisitConductedOn`,
  `siteVisitExecutive`,
  CURRENT_TIMESTAMP(3),
  CURRENT_TIMESTAMP(3)
FROM `Lead`
WHERE
  `siteVisitStatus` IS NOT NULL
  OR `visitStatus` IS NOT NULL
  OR `conductSiteStatus` IS NOT NULL
  OR `siteVisitProject` IS NOT NULL
  OR `siteVisitLocation` IS NOT NULL
  OR `siteVisitNote` IS NOT NULL
  OR `conductSiteVisit` IS NOT NULL
  OR `conductSiteDate` IS NOT NULL;
