-- Prevent multiple inventory rows from claiming the same unit group, floor, and unit position.
-- Existing duplicates are retired from generated inventory by clearing their unitIndex before the unique index is added.

UPDATE `UnitModel` duplicate
JOIN (
  SELECT
    `unitId`,
    `floor`,
    `unitIndex`,
    MIN(`id`) AS `keepId`
  FROM `UnitModel`
  WHERE `floor` IS NOT NULL
    AND `unitIndex` IS NOT NULL
  GROUP BY `unitId`, `floor`, `unitIndex`
  HAVING COUNT(*) > 1
) keeper
  ON keeper.`unitId` = duplicate.`unitId`
  AND keeper.`floor` = duplicate.`floor`
  AND keeper.`unitIndex` = duplicate.`unitIndex`
  AND duplicate.`id` <> keeper.`keepId`
SET
  duplicate.`unitIndex` = NULL,
  duplicate.`name` = CONCAT(duplicate.`name`, '-retired-', duplicate.`id`);

CREATE UNIQUE INDEX `UnitModel_unitId_floor_unitIndex_key`
  ON `UnitModel`(`unitId`, `floor`, `unitIndex`);
