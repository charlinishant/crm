-- Enforce Project -> Tower -> FloorPlan -> Unit hierarchy.
-- This migration intentionally fails on existing NULL parent IDs.
-- Clean or explicitly remap orphan rows before applying; never silently attach them.

ALTER TABLE `FloorPlan` DROP FOREIGN KEY `FloorPlan_projectId_fkey`;
ALTER TABLE `FloorPlan` DROP FOREIGN KEY `FloorPlan_towerId_fkey`;
ALTER TABLE `Unit` DROP FOREIGN KEY `Unit_projectId_fkey`;
ALTER TABLE `Unit` DROP FOREIGN KEY `Unit_towerId_fkey`;
ALTER TABLE `Unit` DROP FOREIGN KEY `Unit_floorId_fkey`;

ALTER TABLE `FloorPlan`
  MODIFY `projectId` INTEGER NOT NULL,
  MODIFY `towerId` INTEGER NOT NULL;

ALTER TABLE `Unit`
  MODIFY `projectId` INTEGER NOT NULL,
  MODIFY `towerId` INTEGER NOT NULL,
  MODIFY `floorId` INTEGER NOT NULL;

ALTER TABLE `FloorPlan`
  ADD CONSTRAINT `FloorPlan_projectId_fkey`
  FOREIGN KEY (`projectId`) REFERENCES `Project`(`id`)
  ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE `FloorPlan`
  ADD CONSTRAINT `FloorPlan_towerId_fkey`
  FOREIGN KEY (`towerId`) REFERENCES `Tower`(`id`)
  ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE `Unit`
  ADD CONSTRAINT `Unit_projectId_fkey`
  FOREIGN KEY (`projectId`) REFERENCES `Project`(`id`)
  ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE `Unit`
  ADD CONSTRAINT `Unit_towerId_fkey`
  FOREIGN KEY (`towerId`) REFERENCES `Tower`(`id`)
  ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE `Unit`
  ADD CONSTRAINT `Unit_floorId_fkey`
  FOREIGN KEY (`floorId`) REFERENCES `FloorPlan`(`id`)
  ON DELETE RESTRICT ON UPDATE CASCADE;
