ALTER TABLE `UnitModel`
  ADD COLUMN `heldBy` VARCHAR(191) NULL,
  ADD COLUMN `heldUntil` DATETIME(3) NULL;

CREATE INDEX `UnitModel_heldBy_idx` ON `UnitModel`(`heldBy`);
CREATE INDEX `UnitModel_heldUntil_idx` ON `UnitModel`(`heldUntil`);

ALTER TABLE `Booking`
  ADD COLUMN `activeUnitItemId` INTEGER NULL,
  ADD COLUMN `idempotencyKey` VARCHAR(191) NULL;

UPDATE `Booking` booking
SET booking.`activeUnitItemId` = booking.`unitItemId`
WHERE booking.`unitItemId` IS NOT NULL
  AND LOWER(COALESCE(booking.`stage`, '')) IN ('confirmed', 'held', 'booked', 'registered')
  AND booking.`id` = (
    SELECT latest.`id`
    FROM (
      SELECT MAX(activeBooking.`id`) AS `id`
      FROM `Booking` activeBooking
      WHERE activeBooking.`unitItemId` = booking.`unitItemId`
        AND LOWER(COALESCE(activeBooking.`stage`, '')) IN ('confirmed', 'held', 'booked', 'registered')
    ) latest
  );

ALTER TABLE `Booking` DROP FOREIGN KEY `Booking_unitItemId_fkey`;
ALTER TABLE `Booking` DROP INDEX `Booking_unitItemId_key`;
CREATE INDEX `Booking_unitItemId_idx` ON `Booking`(`unitItemId`);
ALTER TABLE `Booking`
  ADD CONSTRAINT `Booking_unitItemId_fkey`
  FOREIGN KEY (`unitItemId`) REFERENCES `UnitModel`(`id`)
  ON DELETE SET NULL ON UPDATE CASCADE;

CREATE UNIQUE INDEX `Booking_activeUnitItemId_key` ON `Booking`(`activeUnitItemId`);
CREATE UNIQUE INDEX `Booking_idempotencyKey_key` ON `Booking`(`idempotencyKey`);
