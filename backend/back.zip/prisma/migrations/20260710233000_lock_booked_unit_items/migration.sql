ALTER TABLE `UnitModel`
  ADD COLUMN `status` VARCHAR(191) NOT NULL DEFAULT 'available';

ALTER TABLE `Booking`
  ADD COLUMN `unitItemId` INTEGER NULL;

UPDATE `UnitModel` unitItem
INNER JOIN `Booking` booking ON booking.`unitId` = unitItem.`id`
SET unitItem.`status` = 'booked'
WHERE LOWER(COALESCE(booking.`stage`, '')) = 'booked';

CREATE INDEX `UnitModel_status_idx` ON `UnitModel`(`status`);
CREATE UNIQUE INDEX `Booking_unitItemId_key` ON `Booking`(`unitItemId`);

ALTER TABLE `Booking`
  ADD CONSTRAINT `Booking_unitItemId_fkey`
  FOREIGN KEY (`unitItemId`) REFERENCES `UnitModel`(`id`)
  ON DELETE SET NULL ON UPDATE CASCADE;
