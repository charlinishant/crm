UPDATE `Tower`
SET `skippedFloors` = '[]'
WHERE `skippedFloors` IS NULL OR TRIM(`skippedFloors`) = '';

UPDATE `FloorPlan`
SET `skippedFloors` = '[]'
WHERE `skippedFloors` IS NULL OR TRIM(`skippedFloors`) = '';

ALTER TABLE `Tower`
  MODIFY COLUMN `skippedFloors` VARCHAR(191) NULL DEFAULT '[]';

ALTER TABLE `FloorPlan`
  MODIFY COLUMN `skippedFloors` VARCHAR(191) NULL DEFAULT '[]';
