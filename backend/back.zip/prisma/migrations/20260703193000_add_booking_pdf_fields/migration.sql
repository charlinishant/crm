ALTER TABLE `Booking`
  ADD COLUMN `unitName` VARCHAR(191) NULL,
  ADD COLUMN `tower` VARCHAR(191) NULL,
  ADD COLUMN `area` DOUBLE NULL,
  ADD COLUMN `agreementValue` DOUBLE NULL,
  ADD COLUMN `bookingNumber` VARCHAR(191) NULL,
  ADD COLUMN `bookingPdfData` LONGTEXT NULL,
  ADD COLUMN `bookingPdfFileName` VARCHAR(191) NULL,
  ADD COLUMN `bookingPdfGeneratedAt` DATETIME(3) NULL;

CREATE UNIQUE INDEX `Booking_bookingNumber_key` ON `Booking`(`bookingNumber`);
