UPDATE `UnitModel`
SET `status` = CASE LOWER(REPLACE(COALESCE(`status`, 'available'), ' ', '_'))
  WHEN 'held' THEN 'Held'
  WHEN 'hold' THEN 'Held'
  WHEN 'blocked' THEN 'Blocked'
  WHEN 'block' THEN 'Blocked'
  WHEN 'booked' THEN 'Booked'
  WHEN 'sold' THEN 'Booked'
  WHEN 'unavailable' THEN 'Booked'
  WHEN 'registered' THEN 'Registered'
  WHEN 'possession_given' THEN 'Possession_Given'
  WHEN 'possession-given' THEN 'Possession_Given'
  WHEN 'cancelled' THEN 'Cancelled'
  WHEN 'canceled' THEN 'Cancelled'
  WHEN 'refuge' THEN 'Refuge'
  WHEN 'investor' THEN 'Investor'
  ELSE 'Available'
END;

ALTER TABLE `UnitModel`
  MODIFY COLUMN `status` ENUM(
    'Available',
    'Held',
    'Blocked',
    'Booked',
    'Registered',
    'Possession_Given',
    'Cancelled',
    'Refuge',
    'Investor'
  ) NOT NULL DEFAULT 'Available';
