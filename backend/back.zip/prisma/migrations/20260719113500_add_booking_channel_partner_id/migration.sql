ALTER TABLE `Booking` ADD COLUMN `channelPartnerId` INTEGER NULL;
