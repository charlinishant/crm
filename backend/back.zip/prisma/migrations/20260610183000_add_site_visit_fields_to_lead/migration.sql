ALTER TABLE `Lead`
  ADD COLUMN `siteVisitProject` VARCHAR(191) NULL,
  ADD COLUMN `siteVisitStatus` VARCHAR(191) NULL DEFAULT 'Scheduled',
  ADD COLUMN `visitStatus` VARCHAR(191) NULL DEFAULT 'Scheduled',
  ADD COLUMN `conductSiteStatus` VARCHAR(191) NULL DEFAULT 'Scheduled',
  ADD COLUMN `siteVisitLocation` VARCHAR(191) NULL,
  ADD COLUMN `meetingPoint` VARCHAR(191) NULL,
  ADD COLUMN `siteVisitExecutive` VARCHAR(191) NULL,
  ADD COLUMN `siteVisitNote` TEXT NULL,
  ADD COLUMN `siteVisitInitiatedBy` VARCHAR(191) NULL,
  ADD COLUMN `siteVisitDate` DATETIME(3) NULL,
  ADD COLUMN `siteVisitConductedOn` DATETIME(3) NULL;
