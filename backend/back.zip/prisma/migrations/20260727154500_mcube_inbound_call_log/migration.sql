ALTER TABLE `CallLog` MODIFY `leadId` INTEGER NULL;

ALTER TABLE `CallLog`
  ADD COLUMN `direction` VARCHAR(191) NOT NULL DEFAULT 'outbound',
  ADD COLUMN `callerNumber` VARCHAR(191) NULL,
  ADD COLUMN `customerNumber` VARCHAR(191) NULL,
  ADD COLUMN `agentNumber` VARCHAR(191) NULL,
  ADD COLUMN `agentExtension` VARCHAR(191) NULL,
  ADD COLUMN `virtualNumber` VARCHAR(191) NULL,
  ADD COLUMN `campaignName` VARCHAR(191) NULL,
  ADD COLUMN `queueName` VARCHAR(191) NULL,
  ADD COLUMN `providerAgentName` VARCHAR(191) NULL,
  ADD COLUMN `providerStatus` VARCHAR(191) NULL,
  ADD COLUMN `answeredAt` DATETIME(3) NULL,
  ADD COLUMN `answerDelay` INTEGER NULL,
  ADD COLUMN `disconnectedBy` VARCHAR(191) NULL,
  ADD COLUMN `followUpRequired` BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN `failureReason` TEXT NULL,
  ADD COLUMN `rawPayload` JSON NULL;

UPDATE `CallLog`
SET `direction` = CASE
  WHEN LOWER(COALESCE(`notes`, '')) LIKE '%inbound%' THEN 'inbound'
  ELSE 'outbound'
END
WHERE `direction` IS NULL OR `direction` = 'outbound';

UPDATE `CallLog`
SET
  `callerNumber` = CASE WHEN `direction` = 'inbound' THEN COALESCE(`leadPhone`, `phone`) ELSE `callerNumber` END,
  `customerNumber` = COALESCE(`leadPhone`, `phone`),
  `agentNumber` = COALESCE(`agentPhone`, `agentNumber`);

CREATE INDEX `CallLog_direction_idx` ON `CallLog`(`direction`);
CREATE INDEX `CallLog_callerNumber_idx` ON `CallLog`(`callerNumber`);
CREATE INDEX `CallLog_providerCallId_idx` ON `CallLog`(`providerCallId`);
CREATE INDEX `CallLog_provider_providerCallId_idx` ON `CallLog`(`provider`, `providerCallId`);
CREATE INDEX `CallLog_startedAt_idx` ON `CallLog`(`startedAt`);
