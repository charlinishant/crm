CREATE TABLE `FloorPlanSlot` (
  `id` INTEGER NOT NULL AUTO_INCREMENT,
  `floorPlanId` INTEGER NOT NULL,
  `towerId` INTEGER NOT NULL,
  `floor` INTEGER NOT NULL,
  `unitPosition` VARCHAR(191) NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  UNIQUE INDEX `FloorPlanSlot_towerId_floor_unitPosition_key`(`towerId`, `floor`, `unitPosition`),
  INDEX `FloorPlanSlot_floorPlanId_idx`(`floorPlanId`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `FloorPlanSlot`
  ADD CONSTRAINT `FloorPlanSlot_floorPlanId_fkey`
  FOREIGN KEY (`floorPlanId`) REFERENCES `FloorPlan`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `FloorPlanSlot`
  ADD CONSTRAINT `FloorPlanSlot_towerId_fkey`
  FOREIGN KEY (`towerId`) REFERENCES `Tower`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
