-- AlterTable PaymentSchedule to ensure multiple payment milestones per booking
CREATE INDEX `PaymentSchedule_bookingId_idx` ON `PaymentSchedule`(`bookingId`);
DROP INDEX `PaymentSchedule_bookingId_key` ON `PaymentSchedule`;
