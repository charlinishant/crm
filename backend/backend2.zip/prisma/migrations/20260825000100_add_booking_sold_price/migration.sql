ALTER TABLE `Booking` ADD COLUMN `soldPrice` DOUBLE NULL;

UPDATE `Booking`
SET `soldPrice` = `totalPrice`
WHERE `soldPrice` IS NULL
  AND `totalPrice` IS NOT NULL;
