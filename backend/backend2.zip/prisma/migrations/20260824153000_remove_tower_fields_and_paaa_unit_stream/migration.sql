UPDATE `FloorPlan`
SET `unitStream` = 'Sale Unit'
WHERE `unitStream` IN ('PAAA Member Unit', 'PAA Member Unit');

UPDATE `UnitModel`
SET `name` = CONCAT(CAST(`floor` AS CHAR), LPAD(CAST(`unitIndex` AS CHAR), 2, '0'))
WHERE `floor` IS NOT NULL
  AND `unitIndex` IS NOT NULL;

ALTER TABLE `Tower`
  DROP COLUMN `wingCode`,
  DROP COLUMN `floorNumberingConvention`,
  DROP COLUMN `skippedFloors`;
