ALTER TABLE `FloorPlan`
  ADD COLUMN `floorRiseEnabled` BOOLEAN NOT NULL DEFAULT false;

UPDATE `FloorPlan`
SET `floorRiseEnabled` = true
WHERE `floorRisePerSqft` IS NOT NULL
  AND `floorRisePerSqft` >= 0
  AND `baseFloorForFloorRise` IS NOT NULL
  AND `baseFloorForFloorRise` >= 1;

ALTER TABLE `Booking`
  ADD COLUMN `floorRiseEnabled` BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN `floorRisePerSqft` DOUBLE NULL,
  ADD COLUMN `baseFloorForFloorRise` INTEGER NULL,
  ADD COLUMN `floorNumber` INTEGER NULL,
  ADD COLUMN `riseSteps` INTEGER NULL,
  ADD COLUMN `floorRiseCalculatedAmount` DOUBLE NULL,
  ADD COLUMN `calculatedUnitPrice` DOUBLE NULL,
  ADD COLUMN `priceSnapshot` JSON NULL,
  ADD COLUMN `parkingRequired` BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN `carParkingSlots` INTEGER NULL,
  ADD COLUMN `parkingType` VARCHAR(191) NULL,
  ADD COLUMN `parkingSlotNumber` VARCHAR(191) NULL,
  ADD COLUMN `twoWheelerSlots` INTEGER NULL,
  ADD COLUMN `basementStoreroomArea` DOUBLE NULL,
  ADD COLUMN `parkingCharges` DOUBLE NULL DEFAULT 0,
  ADD COLUMN `gstPercent` DOUBLE NULL,
  ADD COLUMN `stampDutyPercent` DOUBLE NULL,
  ADD COLUMN `registrationAmount` DOUBLE NULL,
  ADD COLUMN `legalDocumentationCharges` DOUBLE NULL,
  ADD COLUMN `infrastructureDevelopmentCharges` DOUBLE NULL,
  ADD COLUMN `societyFormationCharges` DOUBLE NULL,
  ADD COLUMN `clubMembershipCharges` DOUBLE NULL,
  ADD COLUMN `maintenanceAdvanceMonths` INTEGER NULL,
  ADD COLUMN `maintenanceRatePerSqftPerMonth` DOUBLE NULL,
  ADD COLUMN `sinkingFundCorpus` DOUBLE NULL,
  ADD COLUMN `customOtherCharges` JSON NULL;

CREATE TABLE `BookingCharge` (
  `id` INTEGER NOT NULL AUTO_INCREMENT,
  `bookingId` INTEGER NOT NULL,
  `code` VARCHAR(191) NULL,
  `name` VARCHAR(191) NOT NULL,
  `chargeType` VARCHAR(191) NOT NULL,
  `rate` DOUBLE NULL,
  `amount` DOUBLE NOT NULL,
  `taxable` BOOLEAN NOT NULL DEFAULT false,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  INDEX `BookingCharge_bookingId_idx`(`bookingId`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `BookingCharge`
  ADD CONSTRAINT `BookingCharge_bookingId_fkey`
  FOREIGN KEY (`bookingId`) REFERENCES `Booking`(`id`)
  ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `CostSheet`
  DROP INDEX `CostSheet_bookingId_key`,
  ADD COLUMN `sortOrder` INTEGER NULL,
  ADD INDEX `CostSheet_bookingId_idx`(`bookingId`);

ALTER TABLE `PaymentSchedule`
  DROP INDEX `PaymentSchedule_bookingId_key`,
  ADD COLUMN `sortOrder` INTEGER NULL,
  ADD INDEX `PaymentSchedule_bookingId_idx`(`bookingId`);
