ALTER TABLE `Booking`
  ADD COLUMN `bookingName` VARCHAR(191) NULL,
  ADD COLUMN `projectId` INTEGER NULL,
  ADD COLUMN `towerId` INTEGER NULL,
  ADD COLUMN `floorPlanId` INTEGER NULL,
  ADD COLUMN `bookingDate` DATETIME(3) NULL,
  ADD COLUMN `closingRate` DOUBLE NULL,
  ADD COLUMN `totalFlatPrice` DOUBLE NULL,
  ADD COLUMN `parkingAmount` DOUBLE NULL DEFAULT 0,
  ADD COLUMN `gstAmount` DOUBLE NULL,
  ADD COLUMN `stampDutyAmount` DOUBLE NULL,
  ADD COLUMN `registrationCharges` DOUBLE NULL,
  ADD COLUMN `legalCharges` DOUBLE NULL,
  ADD COLUMN `otherExpenseTotal` DOUBLE NULL DEFAULT 0,
  ADD COLUMN `totalTaxes` DOUBLE NULL DEFAULT 0,
  ADD COLUMN `totalAllInclusiveCost` DOUBLE NULL DEFAULT 0,
  ADD COLUMN `channelPartnerName` VARCHAR(191) NULL,
  ADD COLUMN `channelPartnerReraId` VARCHAR(191) NULL;

CREATE TABLE `BookingExpense` (
  `id` INTEGER NOT NULL AUTO_INCREMENT,
  `bookingId` INTEGER NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `amount` DOUBLE NOT NULL,
  `sortOrder` INTEGER NOT NULL DEFAULT 0,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,

  INDEX `BookingExpense_bookingId_idx`(`bookingId`),
  PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `BookingExpense`
  ADD CONSTRAINT `BookingExpense_bookingId_fkey`
  FOREIGN KEY (`bookingId`) REFERENCES `Booking`(`id`)
  ON DELETE CASCADE ON UPDATE CASCADE;
