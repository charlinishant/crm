const prisma = require("../lib/prisma")
const { UNIT_STATUS, normalizeUnitStatus } = require("../services/unitStatus.service")
const { calculateUnitPrice } = require("../utils/unitPricing")

const toNumberOrNull = (value) => {
    if (value === "" || value === null || value === undefined) return null
    const number = Number(value)
    return Number.isNaN(number) ? null : number
}

const toIntOrNull = (value) => {
    const number = toNumberOrNull(value)
    return number === null ? null : Math.trunc(number)
}

const toBoolean = (value) => {
    if (typeof value === "boolean") return value
    if (value === "true" || value === "1" || value === 1) return true
    return false
}

const toDateOrNull = (value) => {
    if (!value) return null
    const date = new Date(value)
    return Number.isNaN(date.getTime()) ? null : date
}

const toArray = (value) => {
    if (Array.isArray(value)) return value
    if (!value) return []
    if (typeof value === "string") {
        const trimmed = value.trim()
        if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
            try {
                const parsed = JSON.parse(trimmed)
                return Array.isArray(parsed) ? parsed : []
            } catch {
                return []
            }
        }
    }
    return String(value)
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean)
}

const parseJsonArray = (value) => {
    if (Array.isArray(value)) return value
    if (value === null || value === undefined || value === "") return []

    if (typeof value === "string") {
        const trimmed = value.trim()
        if (!trimmed) return []
        if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
            try {
                const parsed = JSON.parse(trimmed)
                return Array.isArray(parsed) ? parsed : []
            } catch {
                return []
            }
        }

        return trimmed.split(",").map((item) => item.trim())
    }

    return [value]
}

const normalizeSkippedFloors = (value, from, to) => {
    const values = parseJsonArray(value)
    if (!values.length) return { floors: [], error: null }
    if (!Number.isInteger(from) || !Number.isInteger(to) || from > to) {
        return { floors: [], error: "Select a valid applicable floor range before entering skipped floors." }
    }

    const normalized = []
    for (const item of values) {
        const text = String(item).trim()
        if (!/^\d+$/.test(text)) {
            return { floors: [], error: `Skipped floors must contain unique whole floor numbers between ${from} and ${to}.` }
        }

        const floor = Number(text)
        if (!Number.isInteger(floor) || floor < from || floor > to) {
            return { floors: [], error: `Skipped floors must contain unique whole floor numbers between ${from} and ${to}.` }
        }

        normalized.push(floor)
    }

    return { floors: Array.from(new Set(normalized)).sort((a, b) => a - b), error: null }
}

const isPublishedStatus = (status) => String(status || "").toLowerCase() === "published"
const ALLOWED_UNIT_STREAMS = new Set(["Sale Unit", "Rehab Unit", "Investor"])
const COMMERCIAL_TYPES = new Set(["Commercial", "Retail", "Office"])
const COMMERCIAL_CATEGORIES = new Set(["Shop", "Showroom", "Office Unit"])
const RESIDENTIAL_CATEGORIES = new Set(["Flat", "Penthouse", "Duplex", "Row House", "Villa", "Studio"])
const normalizeUnitStream = (value) => {
    const unitStream = String(value || "Sale Unit").trim() || "Sale Unit"
    return unitStream
}

const getAreaForBasis = (data, basis) => {
    if (basis === "On Saleable") return data.saleable
    if (basis === "On Built-up") return data.builtupArea
    return data.carpet
}

const roundMoney = (value) => Number((Number(value) || 0).toFixed(2))

const getFloorPlanErrorMessage = (error, fallback = "Something went wrong") => {
    if (!error) return fallback

    if (error.code === "P2002") {
        return "Another floor plan already claims one of these tower / floor / unit-position slots"
    }

    if (error.meta?.cause) return error.meta.cause
    if (error.meta?.field_name) return `${error.meta.field_name} is invalid`
    if (error.code) return `${error.code}: ${error.message || fallback}`
    if (error.message) return error.message

    return fallback
}

const validateFloorPlan = (data) => {
    const validationErrors = {}
    if (!data.projectId) {
        return "Project is required for every floor plan"
    }

    if (!data.towerId) {
        return "Tower is required for every floor plan"
    }

    if (!parseUnitPositions(data.unitPosition).length) {
        return "Enter at least one valid Unit Position, for example 01 or 01, 02, 03"
    }

    if (data.applicableFloorFrom === null || data.applicableFloorTo === null) {
        return "Applicable Floor From and Applicable Floor To are required"
    }

    if (data.validationError) {
        return data.validationError
    }

    if (data.baseRate !== null && data.baseRate < 0) {
        return "Base Rate must be zero or more"
    }

    if (data.floorRiseEnabled) {
        if (data.floorRisePerSqft === null || data.floorRisePerSqft < 0) {
            validationErrors.floorRisePerSqft = "Floor Rise / Sqft must be zero or more"
        }
        if (data.baseFloorForFloorRise === null) {
            validationErrors.baseFloorForFloorRise = "Base Floor for Floor Rise is required"
        }
    } else if (data.floorRisePerSqft !== null || data.baseFloorForFloorRise !== null) {
        validationErrors.floorRiseEnabled = "Floor-rise values must be empty when Floor Rise is No"
    }

    if (data.baseFloorForFloorRise !== null && data.baseFloorForFloorRise < 1) {
        validationErrors.baseFloorForFloorRise = "Base Floor for Floor Rise must be at least 1"
    }

    if (
        data.applicableFloorFrom !== null &&
        data.applicableFloorTo !== null &&
        data.applicableFloorFrom > data.applicableFloorTo
    ) {
        return "Applicable Floor From must be less than or equal to Applicable Floor To"
    }

    if (data.applicableFloorFrom !== null && data.applicableFloorFrom < 1) {
        return "Applicable Floor From must be at least 1"
    }

    if (data.applicableFloorTo !== null && data.applicableFloorTo < 1) {
        return "Applicable Floor To must be at least 1"
    }

    if (
        data.baseFloorForFloorRise !== null &&
        data.applicableFloorFrom !== null &&
        data.baseFloorForFloorRise < data.applicableFloorFrom
    ) {
        validationErrors.baseFloorForFloorRise = "Base Floor for Floor Rise cannot be before Applicable Floor From"
    }

    if (
        data.baseFloorForFloorRise !== null &&
        data.applicableFloorTo !== null &&
        data.baseFloorForFloorRise > data.applicableFloorTo
    ) {
        validationErrors.baseFloorForFloorRise = "Base Floor for Floor Rise cannot exceed Applicable Floor To"
    }

    if (
        data.baseFloorForFloorRise !== null &&
        parseSkippedFloorSet(data.skippedFloors).has(data.baseFloorForFloorRise)
    ) {
        validationErrors.baseFloorForFloorRise = "Base floor cannot be a skipped floor"
    }

    if (
        data.carpet !== null &&
        data.builtupArea !== null &&
        data.saleable !== null &&
        !(data.carpet < data.builtupArea && data.builtupArea < data.saleable)
    ) {
        return "RERA Carpet must be less than Built-up Area and Built-up Area must be less than Saleable Area"
    }

    if (
        isPublishedStatus(data.status) &&
        (!Array.isArray(data.floorPlanImages) || data.floorPlanImages.length === 0)
    ) {
        return "Floor Plan Image is required before publishing a floor plan"
    }

    if (Object.keys(validationErrors).length) {
        const error = new Error("Validation failed")
        error.statusCode = 400
        error.validationErrors = validationErrors
        throw error
    }

    return null
}

const validateFloorPlanTowerBounds = async (data) => {
    const tower = await prisma.tower.findUnique({
        where: { id: data.towerId },
        select: {
            id: true,
            projectId: true,
            totalFloor: true,
        },
    })

    if (!tower) {
        return "Selected tower was not found"
    }

    if (Number(tower.projectId) !== Number(data.projectId)) {
        return "Selected tower must belong to the selected project"
    }

    const totalFloors = Number(tower.totalFloor) || 0
    if (totalFloors < 1) {
        return "Selected tower must have Total Floors set to at least 1 before adding floor plans"
    }

    if (data.applicableFloorTo !== null && data.applicableFloorTo > totalFloors) {
        return `Applicable Floor To cannot exceed this tower's Total Floors (${totalFloors})`
    }

    return null
}

const applyDerivedFloorPlanFields = async (data) => {
    const inheritedData = {
        ...data,
        skippedFloors: data.skippedFloors || "[]",
    }

    return {
        ...inheritedData,
        totalUnitsOfPlan: getClaimedSlots(inheritedData).length,
        unitNumbers: getClaimedSlots(inheritedData)
            .map((slot) => buildGeneratedUnitNumber(slot.floor, slot.unitPosition))
            .filter(Boolean)
            .join(", ") || null,
    }
}

const parseSkippedFloorSet = (value) =>
    new Set(parseJsonArray(value).map((item) => Number(item)).filter((item) => Number.isInteger(item)))

const getClaimedFloors = (data) => {
    const from = Number(data.applicableFloorFrom)
    const to = Number(data.applicableFloorTo)

    if (!Number.isInteger(from) || !Number.isInteger(to) || from > to || !data.unitPosition) {
        return []
    }

    const skippedFloors = parseSkippedFloorSet(data.skippedFloors)
    const floors = []

    for (let floor = from; floor <= to; floor += 1) {
        if (!skippedFloors.has(floor)) {
            floors.push(floor)
        }
    }

    return floors
}

const parseUnitPositions = (value) =>
    Array.from(new Set(String(value || "")
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean)
        .map((item) => {
            const position = Number(item)
            if (!Number.isInteger(position) || position < 1 || position > 99) return ""
            return String(position).padStart(2, "0")
        })
        .filter(Boolean)))

const getClaimedSlots = (data) => {
    const positions = parseUnitPositions(data.unitPosition)
    if (!positions.length) return []

    return getClaimedFloors(data).flatMap((floor) =>
        positions.map((unitPosition) => ({
            floor,
            unitPosition,
        }))
    )
}

const validateFloorPlanSlotClaims = async (data, excludeFloorPlanId = null) => {
    const claimedSlots = new Set(
        getClaimedSlots(data).map((slot) => `${slot.floor}:${slot.unitPosition}`)
    )
    if (!claimedSlots.size) return null

    const conflictingPlans = await prisma.floorPlan.findMany({
        where: {
            towerId: data.towerId,
            unitPosition: { not: null },
            ...(excludeFloorPlanId ? { id: { not: excludeFloorPlanId } } : {}),
            applicableFloorFrom: { lte: data.applicableFloorTo },
            applicableFloorTo: { gte: data.applicableFloorFrom },
        },
        select: {
            id: true,
            name: true,
            applicableFloorFrom: true,
            applicableFloorTo: true,
            skippedFloors: true,
            unitPosition: true,
        },
    })

    for (const plan of conflictingPlans) {
        const overlapSlot = getClaimedSlots(plan).find((slot) =>
            claimedSlots.has(`${slot.floor}:${slot.unitPosition}`)
        )
        if (overlapSlot) {
            const planName = plan.name || `Floor Plan #${plan.id}`
            return `${planName} already claims floor ${overlapSlot.floor}, unit position ${overlapSlot.unitPosition} in this tower.`
        }
    }

    return null
}

const replaceFloorPlanSlotClaims = async (tx, floorPlan) => {
    await tx.floorPlanSlot.deleteMany({
        where: { floorPlanId: floorPlan.id },
    })

    const slots = getClaimedSlots(floorPlan)
    if (!slots.length) return

    await tx.floorPlanSlot.createMany({
        data: slots.map((slot) => ({
            floorPlanId: floorPlan.id,
            towerId: floorPlan.towerId,
            floor: slot.floor,
            unitPosition: slot.unitPosition,
        })),
    })
}

const normalizeFloorPlanPayload = (body) => {
    const autoCalc = body.autoCalc === undefined ? true : toBoolean(body.autoCalc)
    const data = {
        name: String(body.name || "").trim(),
        projectId: toIntOrNull(body.projectId),
        towerId: toIntOrNull(body.towerId),
        configurationLabel: body.configurationLabel || null,
        status: body.status || "Draft",
        unitStream: normalizeUnitStream(body.unitStream),
        reraReference: null,
        reraNumber: null,
        reraDate: null,
        possessionDate: toDateOrNull(body.possessionDate),
        type: body.type || null,
        category: body.category || null,
        bedrooms: toIntOrNull(body.bedrooms),
        bathrooms: toNumberOrNull(body.bathrooms),
        balconies: toIntOrNull(body.balconies),
        kitchenType: body.kitchenType || null,
        additionalRooms: toArray(body.additionalRooms),
        applicableFloorFrom: toIntOrNull(body.applicableFloorFrom),
        applicableFloorTo: toIntOrNull(body.applicableFloorTo),
        unitPosition: parseUnitPositions(body.unitPosition).join(", ") || null,
        skippedFloors: null,
        unitNumbers: body.unitNumbers || null,
        totalUnitsOfPlan: null,
        facing: body.facing || null,
        cornerUnit: toBoolean(body.cornerUnit),
        view: toArray(body.view),
        autoCalc,
        measure: body.measure || "sqft",
        carpet: toNumberOrNull(body.carpet),
        builtupArea: toNumberOrNull(body.builtupArea),
        loading: toNumberOrNull(body.loading),
        loadingBasis: body.loadingBasis || "On Carpet",
        balconyArea: toNumberOrNull(body.balconyArea),
        enclosedBalconyUtility: toNumberOrNull(body.enclosedBalconyUtility),
        terraceArea: toNumberOrNull(body.terraceArea),
        flowerBedPocketTerrace: toNumberOrNull(body.flowerBedPocketTerrace),
        serviceSlabAcLedge: toNumberOrNull(body.serviceSlabAcLedge),
        refugeAreaShare: toNumberOrNull(body.refugeAreaShare),
        rateBasis: body.rateBasis || "On Carpet",
        baseRate: toNumberOrNull(body.baseRate),
        floorRiseEnabled: toBoolean(body.floorRiseEnabled),
        floorRisePerSqft: toBoolean(body.floorRiseEnabled) ? toNumberOrNull(body.floorRisePerSqft) : null,
        baseFloorForFloorRise: toBoolean(body.floorRiseEnabled) ? toIntOrNull(body.baseFloorForFloorRise) : null,
        cornerPlcPercent: toNumberOrNull(body.cornerPlcPercent),
        viewPlcPercent: toNumberOrNull(body.viewPlcPercent),
        facingPlcPercent: toNumberOrNull(body.facingPlcPercent),
        floorPlanImages: toArray(body.floorPlanImages),
        brochurePageReference: body.brochurePageReference || null,
        walkthrough3dLink: body.walkthrough3dLink || null,
        paymentPlan: body.paymentPlan || null,
        allotmentLetterTemplate: body.allotmentLetterTemplate || null,
        agreementTemplate: body.agreementTemplate || null,
    }

    if (autoCalc && data.loading !== null) {
        const basisArea = data.loadingBasis === "On Built-up" ? data.builtupArea : data.carpet
        if (basisArea !== null) {
            data.saleable = Number((basisArea * (1 + data.loading / 100)).toFixed(2))
        } else {
            data.saleable = toNumberOrNull(body.saleable)
        }
    } else {
        data.saleable = toNumberOrNull(body.saleable)
    }

    const rateArea = getAreaForBasis(data, data.rateBasis)
    if (data.baseRate !== null && rateArea !== null) {
        data.basePrice = roundMoney(data.baseRate * rateArea)
    } else {
        data.basePrice = 0
    }

    data.coverArea = data.builtupArea
    const skippedFloors = normalizeSkippedFloors(
        body.skippedFloors,
        data.applicableFloorFrom,
        data.applicableFloorTo
    )
    if (skippedFloors.error) {
        data.validationError = skippedFloors.error
    }
    if (!data.validationError && !ALLOWED_UNIT_STREAMS.has(data.unitStream)) {
        data.validationError = "Select a valid Unit Stream."
    }
    const isCommercialType = COMMERCIAL_TYPES.has(data.type)
    if (isCommercialType) {
        if (data.category && !COMMERCIAL_CATEGORIES.has(data.category)) {
            data.validationError = "Select a valid commercial category."
        }
        data.bedrooms = null
        data.bathrooms = null
        data.balconies = null
        data.kitchenType = null
        data.balconyArea = null
    } else if (data.category && !RESIDENTIAL_CATEGORIES.has(data.category) && !COMMERCIAL_CATEGORIES.has(data.category)) {
        data.validationError = "Select a valid unit category."
    }
    data.skippedFloors = JSON.stringify(skippedFloors.floors)
    data.totalUnitsOfPlan = getClaimedSlots(data).length

    return data
}

const buildFloorPlanMutationData = (data, { allowDisconnect = false } = {}) => {
    const { projectId, towerId, validationError, ...payload } = data

    payload.project = { connect: { id: projectId } }

    payload.tower = { connect: { id: towerId } }

    return payload
}

const getUnitPricingForFloor = (floorPlan, floor) => {
    const pricing = calculateUnitPrice({ floorPlan, floorNumber: floor })

    return {
        baseRate: pricing.baseRate,
        basePrice: pricing.finalPrice,
        pricing,
    }
}

const buildGeneratedUnitNumber = (floor, unitPosition) => {
    if (!Number.isInteger(Number(floor)) || !unitPosition) return ""

    return `${Number(floor)}${String(unitPosition).padStart(2, "0")}`
}

const formatFloorPlanResponse = (floorPlan) => {
    if (!floorPlan || typeof floorPlan !== "object") return floorPlan
    const skippedFloors = parseJsonArray(floorPlan.skippedFloors)
        .map((item) => Number(item))
        .filter((item) => Number.isInteger(item))
        .sort((a, b) => a - b)

    return {
        ...floorPlan,
        unitStream: ALLOWED_UNIT_STREAMS.has(floorPlan.unitStream) ? floorPlan.unitStream : "Sale Unit",
        skippedFloors,
        eligibleFloorCount: getClaimedFloors({ ...floorPlan, skippedFloors }).length,
        totalUnitsOfPlan: getClaimedSlots({ ...floorPlan, skippedFloors }).length,
    }
}

const createUnitsFromFloorPlanTemplate = async (tx, floorPlan) => {
    const generatedUnits = getClaimedSlots(floorPlan)
        .map((slot) => ({
            name: buildGeneratedUnitNumber(slot.floor, slot.unitPosition),
            floor: slot.floor,
            unitIndex: Number(slot.unitPosition),
        }))
        .filter((unit) => unit.name)

    if (!generatedUnits.length) return null

    const existingUnits = await tx.unitModel.findMany({
        where: {
            name: { in: generatedUnits.map((unit) => unit.name) },
            unit: { is: { towerId: floorPlan.towerId } },
        },
        select: {
            name: true,
            unit: {
                select: {
                    floorId: true,
                    floor: {
                        select: {
                            name: true,
                        },
                    },
                },
            },
        },
    })
    const conflictingUnit = existingUnits.find((unit) => Number(unit.unit?.floorId) !== Number(floorPlan.id))
    if (conflictingUnit) {
        const error = new Error(
            `${conflictingUnit.name} already exists in this tower from ${conflictingUnit.unit?.floor?.name || "another floor plan"}.`
        )
        error.statusCode = 409
        throw error
    }

    const existingNames = new Set(existingUnits.map((unit) => unit.name))
    const unitsToCreate = generatedUnits.filter((unit) => !existingNames.has(unit.name))

    if (!unitsToCreate.length) {
        return tx.unit.findFirst({
            where: { floorId: floorPlan.id },
            orderBy: { id: "desc" },
        })
    }

    return tx.unit.create({
        data: {
            projectId: floorPlan.projectId,
            towerId: floorPlan.towerId,
            floorId: floorPlan.id,
            type: floorPlan.type,
            category: floorPlan.category,
            bedrooms: floorPlan.bedrooms,
            bathrooms: floorPlan.bathrooms === null || floorPlan.bathrooms === undefined ? null : Math.trunc(floorPlan.bathrooms),
            measure: floorPlan.measure,
            carpet: floorPlan.carpet,
            saleable: floorPlan.saleable,
            loading: floorPlan.loading,
            description: floorPlan.configurationLabel || floorPlan.name || "",
            unitList: {
                create: unitsToCreate.map((unit) => {
                    const pricing = getUnitPricingForFloor(floorPlan, unit.floor)

                    return {
                        name: unit.name,
                        floor: unit.floor,
                        unitIndex: unit.unitIndex,
                        baseRate: pricing.baseRate,
                        basePrice: pricing.basePrice,
                        propertyPurpose: floorPlan.unitStream || "Sale Unit",
                        status: "Available",
                    }
                }),
            },
        },
    })
}

const getGeneratedUnitNamesForFloorPlan = async (tx, floorPlan) => {
    return new Set(
        getClaimedSlots(floorPlan)
            .map((slot) => buildGeneratedUnitNumber(slot.floor, slot.unitPosition))
            .filter(Boolean)
    )
}

const removeUnitsNoLongerClaimed = async (tx, floorPlan) => {
    const expectedNames = await getGeneratedUnitNamesForFloorPlan(tx, floorPlan)
    const unitGroups = await tx.unit.findMany({
        where: { floorId: floorPlan.id },
        select: {
            id: true,
            _count: { select: { bookings: true } },
            unitList: {
                select: {
                    id: true,
                    name: true,
                    floor: true,
                    status: true,
                    _count: { select: { bookings: true } },
                },
            },
        },
    })

    const removableUnitIds = []

    for (const group of unitGroups) {
        for (const unit of group.unitList || []) {
            if (expectedNames.has(unit.name)) continue

            const isProtected =
                group._count.bookings > 0 ||
                unit._count.bookings > 0 ||
                normalizeUnitStatus(unit.status) !== UNIT_STATUS.Available

            if (isProtected) {
                const error = new Error(
                    `Floor ${unit.floor || unit.name || unit.id} cannot be skipped because ${unit.name || "this unit"} is linked to an active booking or protected inventory status. Resolve it before updating this floor plan.`
                )
                error.statusCode = 409
                throw error
            }

            removableUnitIds.push(unit.id)
        }
    }

    if (removableUnitIds.length) {
        await tx.unitModel.deleteMany({
            where: { id: { in: removableUnitIds } },
        })
    }

    const refreshedGroups = await tx.unit.findMany({
        where: { floorId: floorPlan.id },
        select: {
            id: true,
            _count: { select: { unitList: true, bookings: true } },
        },
    })

    const emptyGroupIds = refreshedGroups
        .filter((group) => group._count.unitList === 0 && group._count.bookings === 0)
        .map((group) => group.id)

    if (emptyGroupIds.length) {
        await tx.unit.deleteMany({
            where: { id: { in: emptyGroupIds } },
        })
    }
}

const refreshGeneratedUnitPricing = async (tx, floorPlan) => {
    const recalculableStatuses = new Set([UNIT_STATUS.Available, UNIT_STATUS.Held, UNIT_STATUS.Blocked])
    const unitGroups = await tx.unit.findMany({
        where: { floorId: floorPlan.id },
        include: {
            unitList: true,
        },
    })

    await Promise.all(
        unitGroups.flatMap((group) =>
            group.unitList.map((unit) => {
                if (!recalculableStatuses.has(normalizeUnitStatus(unit.status))) return null
                const pricing = getUnitPricingForFloor(floorPlan, unit.floor)

                return tx.unitModel.update({
                    where: { id: unit.id },
                    data: {
                        baseRate: pricing.baseRate,
                        basePrice: pricing.basePrice,
                    },
                })
            }).filter(Boolean)
        )
    )
}


exports.createFloor = async (req, res)=>{
    try {
        const data = normalizeFloorPlanPayload(req.body)
        const validationError = validateFloorPlan(data)
        if (validationError) {
            return res.status(400).json({ message: validationError })
        }
        const towerValidationError = await validateFloorPlanTowerBounds(data)
        if (towerValidationError) {
            return res.status(400).json({ message: towerValidationError })
        }

        const inheritedData = await applyDerivedFloorPlanFields(data)
        const slotValidationError = await validateFloorPlanSlotClaims(inheritedData)
        if (slotValidationError) {
            return res.status(400).json({ message: slotValidationError })
        }

        const { record, generatedUnitGroup } = await prisma.$transaction(async (tx) => {
            const record = await tx.floorPlan.create({
                data: buildFloorPlanMutationData(inheritedData),
            })
            await replaceFloorPlanSlotClaims(tx, record)
            const generatedUnitGroup = await createUnitsFromFloorPlanTemplate(tx, record)

            return { record, generatedUnitGroup }
        })

        res.status(201).json({
            "id":record.id,
            "unitGroupId": generatedUnitGroup?.id || null,
            "unitCount": getClaimedSlots(record).length,
            "message":"floor plan created successfully"
        })

    } catch (error) {
        console.log(error);
        if (error.statusCode) {
            return res.status(error.statusCode).json({
                success: false,
                message: error.message,
                ...(error.validationErrors ? { errors: error.validationErrors } : {}),
            })
        }

        res.status(500).json({
            message: getFloorPlanErrorMessage(error, "Failed to create floor plan"),
        })
    }
}

exports.getFloor  = async (req, res)=>{
    try{
        const {id}  = req.params

        if(id){
            const result = await prisma.floorPlan.findUnique({where:{id:Number(id)}})
            if(!result)
                res.status(200).json("Floor plan not found")
            else{
                res.status(200).json(formatFloorPlanResponse(result))
            }
        }
        else{
            let conditions = {}
            const page = parseInt(req.query.page) || 1
            const limit = parseInt(req.query.limit) || 10
            
            const skip = (page-1)*limit

            const totalItems = await prisma.floorPlan.count({where:conditions})

            const result = await prisma.floorPlan.findMany({
                where:conditions,
                skip:skip,
                take:limit,
                select:{
                    id:true,
                    name:true,
                    project:{
                        select:{
                            id:true,
                            name:true
                        }
                    },
                    tower:{
                        select:{
                            id:true,
                            name:true
                        }
                    },
                    configurationLabel:true,
                    status:true,
                    unitStream:true,
                    type:true,
                    category:true,
                    bedrooms:true,
                    bathrooms:true,
                    balconies:true,
                    carpet:true,
                    builtupArea:true,
                    saleable:true,
                    loading:true,
                    loadingBasis:true,
                    rateBasis:true,
                    measure:true,
                    baseRate:true,
                    basePrice:true,
                    floorRiseEnabled:true,
                    floorRisePerSqft:true,
                    baseFloorForFloorRise:true,
                    applicableFloorFrom:true,
                    applicableFloorTo:true,
                    unitPosition:true,
                    skippedFloors:true,
                    unitNumbers:true,
                    totalUnitsOfPlan:true,
                }
            })

            let context = {
                page:page,
                limit:limit,
                totalItems:totalItems,
                data:result.map(formatFloorPlanResponse)
            }
            res.status(200).json(context)
        }
    }
    catch(error){
        console.log(error);
        res.status(500).json({
            message: getFloorPlanErrorMessage(error, "Failed to load floor plan"),
        })
    }
}

exports.updateFloor = async (req, res)=>{
    try {
        const data = normalizeFloorPlanPayload(req.body)
        const validationError = validateFloorPlan(data)
        if (validationError) {
            return res.status(400).json({ message: validationError })
        }
        const towerValidationError = await validateFloorPlanTowerBounds(data)
        if (towerValidationError) {
            return res.status(400).json({ message: towerValidationError })
        }
        const id = req.params.id
        if(!id) {
            return res.status(400).json("ID is required")
        }

        const record = await prisma.floorPlan.findUnique({
            where:{id:parseInt(id)},
            include:{ _count:{ select:{ units:true } } },
        })
        if(!record) {
            return res.status(400).json("Floor plan not found")
        }

        const inheritedData = await applyDerivedFloorPlanFields(data)
        const slotValidationError = await validateFloorPlanSlotClaims(inheritedData, record.id)
        if (slotValidationError) {
            return res.status(400).json({ message: slotValidationError })
        }

        const result = await prisma.$transaction(async (tx) => {
            await tx.floorPlanSlot.deleteMany({
                where: { floorPlanId: record.id },
            })

            const updated = await tx.floorPlan.update({
                where:{id:parseInt(record.id)},
                data: buildFloorPlanMutationData(inheritedData)
            })
            await replaceFloorPlanSlotClaims(tx, updated)
            await removeUnitsNoLongerClaimed(tx, updated)
            await createUnitsFromFloorPlanTemplate(tx, updated)
            await refreshGeneratedUnitPricing(tx, updated)

            return updated
        })

        res.status(200).json(formatFloorPlanResponse(result))
    } catch (error) {
        console.log(error);
        if (error.statusCode) {
            return res.status(error.statusCode).json({
                success: false,
                message: error.message,
                ...(error.validationErrors ? { errors: error.validationErrors } : {}),
            })
        }
        res.status(500).json({
            message: getFloorPlanErrorMessage(error, "Failed to update floor plan"),
        })
    }
}

exports.deleteFloor = async (req, res)=>{
    try {
        const id = req.params.id
        if(!id)
            res.status(400).json("ID is required")    

        const record = await prisma.floorPlan.findUnique({
            where:{id:parseInt(id)},
            include:{
                units:{
                    select:{
                        id:true,
                        _count:{ select:{ bookings:true } },
                        unitList:{
                            select:{
                                id:true,
                                name:true,
                                status:true,
                                _count:{ select:{ bookings:true } },
                            },
                        },
                    },
                },
            },
        })
        if(!record) {
            return res.status(400).json("Floor plan not found")
        }

        const unitGroups = record.units || []
        const unitGroupWithBookings = unitGroups.find((unitGroup) => unitGroup._count.bookings > 0)
        const generatedUnits = unitGroups.flatMap((unitGroup) => unitGroup.unitList || [])
        const unitWithBookings = generatedUnits.find((unit) => unit._count.bookings > 0)

        if (unitGroupWithBookings || unitWithBookings) {
            return res.status(409).json({
                message: "Cannot delete floor plan because booking history exists under it.",
            })
        }

        const nonAvailableUnit = generatedUnits.find(
            (unit) => normalizeUnitStatus(unit.status) !== UNIT_STATUS.Available
        )
        if (nonAvailableUnit) {
            return res.status(409).json({
                message: `Cannot delete floor plan because unit ${nonAvailableUnit.name || nonAvailableUnit.id} is ${normalizeUnitStatus(nonAvailableUnit.status)}. Only Available generated units can be deleted first.`,
            })
        }

        if (unitGroups.length > 0) {
            return res.status(409).json({
                message: "Cannot delete floor plan because generated units exist under it. Delete Available units first.",
            })
        }

        const data = await prisma.floorPlan.delete({where:{id:record.id}})

        res.status(200).json("Floor plan deleted successfully")
        
    } catch (error) {
        console.log(error);
        res.status(500).json("Something went wrong")
    }
}

exports.listFloor = async (req, res)=>{
    const towerId =  req.query.towerId || null
    if(towerId)
    {
        const record = await prisma.floorPlan.findMany({
            where:{towerId:parseInt(towerId)},
        select:{
            id:true,
            name:true
    }})
        res.status(200).json(record)
    }
    else{
        const record = await prisma.floorPlan.findMany({select:{
            id:true,
            name:true
        }})
        res.status(200).json(record)
    }   
}
