const ExcelJS = require('exceljs');

const generateCostSheetExcel = async (bookingData) => {
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Cost Sheet & Payment Schedule');

  // Basic styling setup
  sheet.properties.defaultRowHeight = 20;

  // Set column widths
  sheet.getColumn(1).width = 4;   // A
  sheet.getColumn(2).width = 25;  // B
  sheet.getColumn(3).width = 10;  // C
  sheet.getColumn(4).width = 15;  // D
  sheet.getColumn(5).width = 2;   // E (Spacer)
  sheet.getColumn(6).width = 35;  // F (Milestone)
  sheet.getColumn(7).width = 8;   // G (Net %)
  sheet.getColumn(8).width = 10;  // H (Due)
  sheet.getColumn(9).width = 8;   // I (Cuml. %)
  sheet.getColumn(10).width = 15; // J (Amount)
  sheet.getColumn(11).width = 12; // K (TDS)
  sheet.getColumn(12).width = 12; // L (GST)

  const projectName = bookingData.project?.name || bookingData.projectDetails || "PROJECT NAME";
  const projectAddress = bookingData.project?.address || bookingData.project?.street || "Project Address";
  const unitNo = bookingData.unit?.unitNo || bookingData.unit?.name || (bookingData.unitId ? `Unit #${bookingData.unitId}` : "N/A");
  
  const carpetArea = bookingData.carpetArea || bookingData.unit?.carpet || 0;
  const flatRate = bookingData.baseRate || bookingData.closingRate || 0;
  
  // Define Borders
  const thinBorder = {
    top: { style: 'thin' },
    left: { style: 'thin' },
    bottom: { style: 'thin' },
    right: { style: 'thin' }
  };

  const headerFill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFFFE699' } // Light Yellow
  };

  const subHeaderFill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFD9EAD3' } // Light Green
  };

  // Row 1: Project Name
  sheet.mergeCells('A1:L1');
  const titleRow = sheet.getCell('A1');
  titleRow.value = `Project Name: "${projectName.toUpperCase()}"`;
  titleRow.font = { name: 'Times New Roman', size: 18, bold: true };
  titleRow.alignment = { horizontal: 'center', vertical: 'middle' };
  titleRow.fill = headerFill;
  titleRow.border = thinBorder;

  // Row 2: Address
  sheet.mergeCells('A2:L2');
  const addrRow = sheet.getCell('A2');
  addrRow.value = projectAddress;
  addrRow.font = { name: 'Times New Roman', size: 11 };
  addrRow.alignment = { horizontal: 'center', vertical: 'middle' };
  addrRow.border = thinBorder;

  // Row 3: EOI
  sheet.mergeCells('F3:L3');
  const eoiRow = sheet.getCell('F3');
  eoiRow.value = 'Expression of Interest in Proposed Self-Redevelopment';
  eoiRow.font = { name: 'Times New Roman', size: 10 };
  eoiRow.alignment = { horizontal: 'center', vertical: 'middle' };
  eoiRow.border = thinBorder;

  // Row 4: Top headers
  sheet.getCell('A4').value = 1;
  sheet.getCell('B4').value = 'Available Shop/Flat';
  sheet.mergeCells('C4:D4');
  sheet.getCell('C4').value = unitNo;
  
  sheet.mergeCells('F4:L4');
  const psHeader = sheet.getCell('F4');
  psHeader.value = `Payment Schedule For : ${unitNo}`;
  psHeader.font = { name: 'Times New Roman', size: 12, bold: true };
  psHeader.alignment = { horizontal: 'center', vertical: 'middle' };
  psHeader.fill = subHeaderFill;
  psHeader.border = thinBorder;
  
  [sheet.getCell('A4'), sheet.getCell('B4'), sheet.getCell('C4')].forEach(c => {
    c.font = { bold: true };
    c.border = thinBorder;
  });

  // Row 5
  sheet.getCell('A5').value = 2;
  sheet.getCell('B5').value = 'Configuration';
  sheet.mergeCells('C5:D5');
  sheet.getCell('C5').value = bookingData.unit?.type || '2 BHK';
  
  sheet.getCell('F5').value = 'Milestone';
  sheet.getCell('G5').value = 'Net';
  sheet.getCell('H5').value = 'Tentative';
  sheet.getCell('I5').value = 'Cuml.';
  sheet.getCell('J5').value = 'Amount';
  sheet.getCell('K5').value = 'TDS';
  sheet.getCell('L5').value = 'GST 5%';
  
  [sheet.getCell('A5'), sheet.getCell('B5'), sheet.getCell('C5')].forEach(c => {
    c.font = { bold: true };
    c.border = thinBorder;
  });

  ['F5','G5','H5','I5','J5','K5','L5'].forEach(col => {
    const c = sheet.getCell(col);
    c.font = { bold: true, name: 'Times New Roman' };
    c.fill = headerFill;
    c.border = thinBorder;
    c.alignment = { horizontal: 'center', vertical: 'middle' };
  });

  // Left Block Setup
  sheet.getCell('C6').value = 'Unit';
  sheet.getCell('D6').value = 'Amount';
  sheet.getCell('C6').border = thinBorder; sheet.getCell('C6').font = { bold: true };
  sheet.getCell('D6').border = thinBorder; sheet.getCell('D6').font = { bold: true };

  // Flat Area
  sheet.getCell('A7').value = 'A';
  sheet.getCell('B7').value = 'Flat Area';
  sheet.getCell('C7').value = 'SFt.';
  sheet.getCell('D7').value = carpetArea;
  // Flat Rate
  sheet.getCell('A8').value = 'B';
  sheet.getCell('B8').value = 'Flat Rate';
  sheet.getCell('C8').value = '/SFt.';
  sheet.getCell('D8').value = flatRate;

  // Flat Cost (Formula)
  sheet.getCell('A10').value = 'C';
  sheet.getCell('B10').value = 'Flat Cost';
  sheet.getCell('C10').value = 'Rs.';
  sheet.getCell('D10').value = { formula: 'D7*D8', result: carpetArea * flatRate };
  sheet.getCell('B10').font = { bold: true };
  sheet.getCell('D10').font = { bold: true };

  // Parking
  sheet.getCell('A12').value = 'D';
  sheet.getCell('B12').value = 'No. of Parking';
  sheet.getCell('C12').value = 'No';
  sheet.getCell('D12').value = bookingData.carParkingSlots || 0;
  sheet.getCell('B13').value = 'Parking Cost';
  sheet.getCell('C13').value = 'Rs.';
  sheet.getCell('D13').value = bookingData.parkingAmount || 0;

  // Total Flat Cost
  sheet.getCell('A15').value = 'E';
  sheet.getCell('B15').value = 'Total Flat Cost';
  sheet.getCell('C15').value = 'Rs.';
  sheet.getCell('D15').value = { formula: 'D10+D13', result: (carpetArea * flatRate) + (bookingData.parkingAmount || 0) };
  sheet.getCell('B15').font = { bold: true };
  sheet.getCell('D15').font = { bold: true };

  // Apply borders to Left Block
  for(let r=7; r<=15; r++) {
    for(let c=1; c<=4; c++) {
      if(sheet.getCell(r, c).value !== null) {
        sheet.getCell(r, c).border = thinBorder;
      }
    }
  }

  // Other Cost Block
  sheet.mergeCells('A17:D17');
  sheet.getCell('A17').value = 'Other Cost';
  sheet.getCell('A17').font = { bold: true };
  sheet.getCell('A17').border = thinBorder;

  sheet.getCell('A18').value = 1;
  sheet.getCell('B18').value = 'GST @ 5 %';
  sheet.getCell('C18').value = 'Rs.';
  sheet.getCell('D18').value = { formula: 'D15*0.05', result: ((carpetArea * flatRate) + (bookingData.parkingAmount || 0)) * 0.05 };

  sheet.getCell('A19').value = 2;
  sheet.getCell('B19').value = 'Stamp Duty 6%';
  sheet.getCell('C19').value = 'Rs.';
  sheet.getCell('D19').value = { formula: 'D15*0.06', result: ((carpetArea * flatRate) + (bookingData.parkingAmount || 0)) * 0.06 };

  sheet.getCell('A20').value = 3;
  sheet.getCell('B20').value = 'Registration Charges';
  sheet.getCell('C20').value = 'Rs.';
  sheet.getCell('D20').value = bookingData.registrationAmount || 30000;

  sheet.getCell('A21').value = 'F';
  sheet.getCell('B21').value = 'Sub Total';
  sheet.getCell('C21').value = 'Rs.';
  sheet.getCell('D21').value = { formula: 'SUM(D18:D20)' };
  sheet.getCell('B21').font = { bold: true };
  sheet.getCell('D21').font = { bold: true };

  for(let r=18; r<=21; r++) {
    for(let c=1; c<=4; c++) {
      sheet.getCell(r, c).border = thinBorder;
    }
  }

  // Grand Total
  sheet.getCell('A23').value = 'G';
  sheet.getCell('B23').value = 'TOTAL ( E + F )';
  sheet.getCell('C23').value = 'Rs.';
  sheet.getCell('D23').value = { formula: 'D15+D21' };
  
  for(let c=1; c<=4; c++) {
    const cell = sheet.getCell(23, c);
    cell.fill = headerFill;
    cell.font = { bold: true };
    cell.border = thinBorder;
  }

  // Signatory Block
  sheet.mergeCells('B25:D25');
  sheet.getCell('B25').value = `For ${projectName}`;
  sheet.getCell('B25').font = { bold: true };
  sheet.getCell('B25').alignment = { horizontal: 'center' };

  sheet.mergeCells('B29:D29');
  sheet.getCell('B29').value = 'Authorised Signatory';
  sheet.getCell('B29').font = { bold: true };
  sheet.getCell('B29').alignment = { horizontal: 'center' };

  sheet.mergeCells('A31:D31');
  sheet.getCell('A31').value = 'I/We hear by accept and confirm the terms';
  sheet.getCell('A31').font = { bold: true };

  sheet.getCell('A32').value = 'Name';
  sheet.getCell('A32').font = { bold: true };
  sheet.mergeCells('B32:D32');
  const customerName = bookingData.customerName || (bookingData.lead ? `${bookingData.lead.firstName} ${bookingData.lead.lastName}` : '');
  sheet.getCell('B32').value = customerName;
  sheet.getCell('B32').font = { bold: true };
  sheet.getCell('B32').alignment = { horizontal: 'center' };

  sheet.getCell('A33').value = 'Sign';
  sheet.getCell('A33').font = { bold: true };
  sheet.getCell('C33').value = 'Date';
  sheet.getCell('C33').font = { bold: true };
  sheet.getCell('D33').value = new Date().toLocaleDateString('en-IN');
  
  for(let r=31; r<=33; r++) {
    for(let c=1; c<=4; c++) {
      sheet.getCell(r, c).border = thinBorder;
    }
  }

  // Right Block: Payment Schedule (Rows 6+)
  let row = 6;
  const paymentSchedule = bookingData.paymentSchedule || [
    { name: 'EOI', value: 10 },
    { name: 'On Registration of Sales Agreement', value: 20 },
    { name: 'On Completion of Plinth', value: 15 },
    { name: 'On Slab wise upto 14th Floor (due as per slab)***', value: 25 },
    { name: 'On Execution of Internal Amenities of Flat', value: 10 },
    { name: 'On Execution of External Amenities of Flat', value: 10 },
    { name: 'On Execution of Lift & Paint', value: 5 },
    { name: 'Before handing over or on receipt of OC', value: 5 },
  ];

  let cumlPercent = 0;
  const scheduleStartRow = row;
  
  for (const milestone of paymentSchedule) {
    const pValue = milestone.value || 0;
    cumlPercent += pValue;
    
    sheet.getCell(`F${row}`).value = milestone.name;
    sheet.getCell(`G${row}`).value = `${pValue}%`;
    sheet.getCell(`H${row}`).value = (row === 6) ? 'Due' : ''; // Just mock tentative due for first row
    sheet.getCell(`I${row}`).value = `${cumlPercent}%`;
    
    // Amount Formula
    sheet.getCell(`J${row}`).value = { formula: `D15*${pValue}/100` };
    
    // TDS = Amount * 1% (if > 50L) -> usually flat 1% of amount
    sheet.getCell(`K${row}`).value = { formula: `IF(D15>=5000000, J${row}*0.01, 0)` };
    
    // GST = Amount * 5%
    sheet.getCell(`L${row}`).value = { formula: `J${row}*0.05` };

    for(let c=6; c<=12; c++) {
      sheet.getCell(row, c).border = thinBorder;
    }
    row++;
  }
  
  // Fill empty rows until row 22 to match layout height
  const scheduleEndRow = row - 1;
  while(row <= 22) {
    for(let c=6; c<=12; c++) {
      sheet.getCell(row, c).border = thinBorder;
    }
    row++;
  }

  // Right Block Totals (Row 23)
  sheet.mergeCells('F23:H23');
  sheet.getCell('F23').value = 'Total';
  sheet.getCell('I23').value = '100%';
  sheet.getCell('J23').value = { formula: `SUM(J${scheduleStartRow}:J${scheduleEndRow})` };
  sheet.getCell('K23').value = { formula: `SUM(K${scheduleStartRow}:K${scheduleEndRow})` };
  sheet.getCell('L23').value = { formula: `SUM(L${scheduleStartRow}:L${scheduleEndRow})` };

  for(let c=6; c<=12; c++) {
    const cell = sheet.getCell(23, c);
    cell.fill = headerFill;
    cell.font = { bold: true };
    cell.border = thinBorder;
  }

  // Footer notes for the payment schedule
  sheet.mergeCells('F24:L25');
  const footerNoteCell = sheet.getCell('F24');
  footerNoteCell.value = 'GST & Stamp Duty is as per the prevailing Govt. Norms.\nSociety Development charges shall be applicable at the time of possessions as decided by society proportionate to all.';
  footerNoteCell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
  footerNoteCell.font = { size: 9 };
  footerNoteCell.border = thinBorder;

  // Global Bottom Note
  sheet.mergeCells('A35:L35');
  const globalNote = sheet.getCell('A35');
  globalNote.value = 'NOTE: Committee Reserve the rights to change the price, configuration if not booked (rates are for 7 days).';
  globalNote.alignment = { horizontal: 'center' };
  globalNote.font = { size: 9 };

  // Formatting numbers for columns J, K, L and D
  const currencyCols = ['D', 'J', 'K', 'L'];
  currencyCols.forEach(col => {
    for(let r=6; r<=30; r++) {
      const cell = sheet.getCell(`${col}${r}`);
      if (cell.value) {
        cell.numFmt = '#,##0.00';
      }
    }
  });

  return workbook;
};

module.exports = {
  generateCostSheetExcel
};
